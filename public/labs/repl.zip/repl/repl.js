// REPL — wires the CodeMirror editor adapter to the DSL parser, scheduler,
// and voices. Owns: hot-reload (Cmd-Enter), Esc-to-stop, status line, share
// button, example loader, and URL-hash patch persistence.
//
// The editor is a CodeMirror 6 EditorView mounted into #editor by
// repl-editor.js (createReplEditor). All reads/writes go through the
// editorAPI adapter; this file never touches contentDOM directly.

(function () {
  'use strict';

  const VIDEO_DEBUG_STORAGE_KEY = 'replDebugVideo';

  function parseDebugBool(value) {
    const v = String(value == null ? '' : value).trim().toLowerCase();
    if (v === '1' || v === 'true' || v === 'yes' || v === 'on') return true;
    if (v === '0' || v === 'false' || v === 'no' || v === 'off') return false;
    return null;
  }

  function readVideoDebugFlag() {
    let queryValue = null;
    try {
      const qs = new URLSearchParams(window.location.search || '');
      if (qs.has('debug-video')) queryValue = qs.get('debug-video');
      else if (qs.has('video-debug')) queryValue = qs.get('video-debug');
    } catch (_) {}

    const parsedQuery = parseDebugBool(queryValue);
    if (parsedQuery != null) {
      try { localStorage.setItem(VIDEO_DEBUG_STORAGE_KEY, parsedQuery ? '1' : '0'); } catch (_) {}
      return parsedQuery;
    }

    try {
      return localStorage.getItem(VIDEO_DEBUG_STORAGE_KEY) === '1';
    } catch (_) {
      return false;
    }
  }

  const VIDEO_DEBUG_ENABLED = readVideoDebugFlag();
  window.__REPL_DEBUG_VIDEO__ = VIDEO_DEBUG_ENABLED;

  const editorMount = document.getElementById('editor');
  const statusEl = document.getElementById('status');
    const playBtn = document.getElementById('play');
    const safePlayBtn = document.getElementById('safe-play');
    const stopBtn = document.getElementById('stop');
    const shareBtn = document.getElementById('share');
    const clearPatchBtn = document.getElementById('clear-patch');
    const exampleTrigger = document.getElementById('example-trigger');
    const examplePopover = document.getElementById('example-popover');
    const examplePopoverTabs = document.getElementById('example-popover-tabs');
    const patchBrowserTopTabs = document.getElementById('patch-browser-top-tabs');
    const examplePopoverList = document.getElementById('example-popover-list');
    const examplePopoverSearch = document.getElementById('example-popover-search');
    const examplePopoverCount = document.getElementById('example-popover-count');
    const exampleCurrentLabel = document.getElementById('example-current-label');

    const commandPopover = document.getElementById('command-popover');
    const commandPopoverTabs = document.getElementById('command-popover-tabs');
    const commandPopoverList = document.getElementById('command-popover-list');
    const commandPopoverSearch = document.getElementById('command-popover-search');
    const commandPopoverCount = document.getElementById('command-popover-count');
  let videoExamplesEnabled = true;
  const errorList = document.getElementById('errors');
  const patchTitleChip = document.getElementById('patch-title-chip');
  const beatDotsEl = document.getElementById('beat-dots');
  const blockRowsEl = document.getElementById('block-rows');
  const transportVizEl = document.getElementById('transport-viz');
  const videoToolbarEl = document.getElementById('video-toolbar');
  const samplesToggleBtn = document.getElementById('samples-toggle');
  const inputToggleBtn = document.getElementById('input-toggle');
  const inputPanel = document.getElementById('input-panel');
  const inputKindSelect = document.getElementById('input-kind');
  const inputDeviceSelect = document.getElementById('input-device');
  const outputDeviceSelect = document.getElementById('output-device');
  const outputApplyBtn = document.getElementById('output-apply');
  const outputRefreshBtn = document.getElementById('output-refresh');
  const outputStatusEl = document.getElementById('output-status');
  const inputEnableBtn = document.getElementById('input-enable');
  const inputStopBtn = document.getElementById('input-stop');
  const inputStatusEl = document.getElementById('input-status');
  const inputMeterFill = document.getElementById('input-meter-fill');
  const videoToggleBtn = document.getElementById('video-toggle');
  const videoPanel = document.getElementById('video-panel');
  const videoKindSelect = document.getElementById('video-kind');
  const videoFileWrap = document.getElementById('video-file-wrap');
  const videoFileInput = document.getElementById('video-file');
  const videoEnableBtn = document.getElementById('video-enable');
  const videoStopBtn = document.getElementById('video-stop');
  const videoPopoutBtn = document.getElementById('video-popout');
  const videoStatusEl = document.getElementById('video-status');
  const videoStageCanvas = document.getElementById('video-stage-canvas');
  const samplesPanel = document.getElementById('samples-panel');
  const samplesGroupsEl = document.getElementById('samples-groups');
    const samplesFilterInput = document.getElementById('samples-filter');
    const samplesLinkBtn = document.getElementById('samples-link');
    const samplesRelinkBtn = document.getElementById('samples-relink');
    const samplesUnlinkBtn = document.getElementById('samples-unlink');
    const samplesLocalStatus = document.getElementById('samples-local-status');
    const replWorkspace = document.getElementById('repl-workspace');
    const referenceToggleBtn = document.getElementById('reference-toggle');
    const referencePanel = document.getElementById('reference-panel');
    const referenceCloseBtn = document.getElementById('reference-close');
    const fieldReportDialog = document.getElementById('field-report-dialog');
    const fieldReportForm = document.getElementById('field-report-form');
    const fieldReportPreview = document.getElementById('field-report-preview');
    const fieldReportOpenBtns = Array.from(document.querySelectorAll('[data-field-report-open]'));
    const fieldReportCloseBtns = Array.from(document.querySelectorAll('[data-field-report-close]'));
    const fieldReportCopyBtn = document.querySelector('[data-field-report-copy]');
    const FIELD_REPORT_ISSUE_URL = 'https://github.com/OWNER/REPO/issues/new';

    const SAMPLES_MANIFEST_URL = './samples/manifest.json';
    const DEFAULT_EXAMPLE_URL = './examples/default.txt';
    const REFERENCE_SEEN_KEY = 'replReferenceSeen';
    const LOCAL_SAMPLES_DB_NAME = 'replLocalSamples';
    const LOCAL_SAMPLES_DB_VERSION = 1;
    const LOCAL_SAMPLES_STORE = 'handles';
    const LOCAL_SAMPLES_HANDLE_KEY = 'samplesDir';
    const LOCAL_SAMPLES_EXTENSIONS = new Set(['wav', 'mp3', 'ogg', 'm4a', 'aac', 'flac', 'aif', 'aiff']);
    const LOCAL_SAMPLE_GROUP_ID = 'local_folder';
    const LOCAL_SAMPLE_GROUP_LABEL = 'local folder';
    const SAVED_PATCHES_STORAGE_KEY = 'replSavedPatches:v1';
    const SAVED_PATCHES_MAX = 50;

    let scheduler = null;
    let lastGoodProgram = null;
    let lastEvaluatedText = '';
    let statusTimer = null;

    const PATCH_HASH_DEBOUNCE_MS = 900;
    const CLEAR_PATCH_ARM_MS = 2200;
    const CLEAR_PATCH_SCAFFOLD = '// title: Untitled Patch\n\ntempo 110\nmeter 4/4\n';

    const patchLinkState = {
      applyingRemotePatch: false,
      writeTimer: null,
      lastSavedCode: '',
      lastSavedTitle: '',
      editingTitle: false,
    };

    const clearPatchState = {
      armed: false,
      blank: false,
      timer: null,
    };
    let editorAPI = null;
    let shouldAutofocusEditor = true;
    let loadedExampleLabel = '';
    let lastParseErrorText = '';
    let lastRuntimeErrorText = '';
    let localSamplesDbPromise = null;
    let localSamplesDirHandle = null;
    let localSampleObjectUrls = [];
    let localSamplesBusy = false;
    let mediaDeviceChangeBound = false;
    const blockMuteOverridesBySignature = new Map();
    let lastEditorMuteSnapshotKey = '';

  // ---------------- patch title plate ----------------

  const TITLE_COMMENT_RE = /^\s*(?:\/\/\s*title\s*:\s*|#\s*title\s*:\s*|\/\/\/\s*(?:patch\s*:\s*)?)(.+?)\s*$/i;
  const FIELD_COMMENT_RE = /^\s*\/\/\/\s*field\s*:\s*(.+?)\s*$/i;

  function normalizePatchTitle(raw) {
    return String(raw || '')
      .replace(/[\u2018\u2019]/g, "'")
      .replace(/[\u201c\u201d]/g, '"')
      .replace(/[_-]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function formatPatchTitle(raw) {
    const title = normalizePatchTitle(raw) || 'UNTITLED';
    return `PATCH / ${title.toUpperCase()}`;
  }

  function findExplicitPatchTitle(text) {
    const lines = String(text || '').replace(/\r\n?/g, '\n').split('\n');
    let offset = 0;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const m = line.match(TITLE_COMMENT_RE);
      if (m && normalizePatchTitle(m[1])) {
        const value = m[1];
        const valueStartInLine = line.indexOf(value);
        const from = offset + Math.max(0, valueStartInLine);
        const to = from + value.length;
        return {
          title: normalizePatchTitle(value),
          line: i + 1,
          from,
          to,
          lineFrom: offset,
          lineTo: offset + line.length,
        };
      }
      offset += line.length + 1;
    }

    return null;
  }

  function blockMuteSignature(block) {
    if (!block) return '';
    const voice = String(block.voice || 'block').toLowerCase();
    const line = Number(block.line);
    const lineKey = Number.isFinite(line) && line > 0 ? `L${Math.floor(line)}` : 'noline';
    return `${voice}@${lineKey}`;
  }

  function blockByLine(program, lineNumber) {
    const blocks = program && Array.isArray(program.blocks) ? program.blocks : [];
    const target = Number(lineNumber);
    if (!Number.isFinite(target) || target <= 0) return null;
    for (const block of blocks) {
      if (Number(block && block.line) === Math.floor(target)) return block;
    }
    return null;
  }

  function applyStoredBlockMuteOverrides(program) {
    const blocks = program && Array.isArray(program.blocks) ? program.blocks : [];
    for (const block of blocks) {
      const sig = blockMuteSignature(block);
      if (!sig) continue;
      if (!blockMuteOverridesBySignature.has(sig)) continue;
      block.mutedDefault = Boolean(blockMuteOverridesBySignature.get(sig));
    }
  }

  function setStoredBlockMuteOverride(block, muted) {
    const sig = blockMuteSignature(block);
    if (!sig) return;
    const next = Boolean(muted);
    blockMuteOverridesBySignature.set(sig, next);
    block.mutedDefault = next;
  }

  function schedulerMuteStates() {
    if (!scheduler || typeof scheduler.getMuteStates !== 'function') return [];
    try {
      return scheduler.getMuteStates() || [];
    } catch (_) {
      return [];
    }
  }

  function editorMuteLinesSnapshot() {
    const runtime = schedulerMuteStates();
    if (runtime.length > 0) {
      return runtime.map((entry) => ({
        line: entry.line,
        muted: Boolean(entry.muted),
        pending: Boolean(entry.pending),
        pendingMuted: entry.pendingMuted == null ? Boolean(entry.muted) : Boolean(entry.pendingMuted),
        tags: Array.isArray(entry.tags) ? entry.tags.slice() : [],
      }));
    }

    const program = lastGoodProgram;
    const blocks = program && Array.isArray(program.blocks) ? program.blocks : [];
    return blocks.map((block) => ({
      line: block && block.line,
      muted: Boolean(block && block.mutedDefault),
      pending: false,
      pendingMuted: Boolean(block && block.mutedDefault),
      tags: Array.isArray(block && block.tags) ? block.tags.slice() : [],
    }));
  }

  function syncEditorBlockMuteLines() {
    if (!editorAPI || typeof editorAPI.setMutedBlockLines !== 'function') return;
    const snapshot = editorMuteLinesSnapshot();
    const key = snapshot
      .map((entry) => `${Number(entry.line) || 0}:${entry.muted ? 1 : 0}:${entry.pending ? 1 : 0}:${entry.pendingMuted ? 1 : 0}`)
      .join('|');
    if (key === lastEditorMuteSnapshotKey) return;
    lastEditorMuteSnapshotKey = key;
    editorAPI.setMutedBlockLines(snapshot);
  }

  // Bulk mute/unmute used when the editor selection spans multiple block
  // headers and the user clicks any one of their mute glyphs. The desired
  // state is computed in the editor (collective toggle: if any are unmuted,
  // mute all; otherwise unmute all) and we just apply it line-by-line.
  function setBlockMuteFromEditor(lineNumbers, nextMuted) {
    const list = Array.isArray(lineNumbers) ? lineNumbers : [];
    let touched = false;
    for (const raw of list) {
      const line = Number(raw);
      if (!Number.isFinite(line) || line <= 0) continue;
      const block = blockByLine(lastGoodProgram, line);
      if (block) setStoredBlockMuteOverride(block, Boolean(nextMuted));
      if (scheduler && typeof scheduler.setBlockMutedByLine === 'function') {
        scheduler.setBlockMutedByLine(line, Boolean(nextMuted), { quantize: 'bar' });
      }
      touched = true;
    }
    if (touched) syncEditorBlockMuteLines();
  }

  function toggleBlockMuteFromEditor(lineNumber) {
    const line = Number(lineNumber);
    if (!Number.isFinite(line) || line <= 0) return;

    let handledByScheduler = false;
    if (scheduler && typeof scheduler.toggleBlockMutedByLine === 'function') {
      const result = scheduler.toggleBlockMutedByLine(line, { quantize: 'bar' });
      if (result && result.ok) {
        handledByScheduler = true;
        const block = blockByLine(lastGoodProgram, line);
        if (block) {
          const targetMuted = result.pending ? Boolean(result.pendingMuted) : Boolean(result.muted);
          setStoredBlockMuteOverride(block, targetMuted);
        }
      }
    }

    if (!handledByScheduler) {
      const block = blockByLine(lastGoodProgram, line);
      if (block) {
        const nextMuted = !Boolean(block.mutedDefault);
        setStoredBlockMuteOverride(block, nextMuted);
        if (scheduler && typeof scheduler.setBlockMutedByLine === 'function') {
          scheduler.setBlockMutedByLine(line, nextMuted, { quantize: 'now' });
        }
      }
    }

    syncEditorBlockMuteLines();
  }

  function sourceLabelFromAttractor(block) {
    if (!block) return '';
    const source = block.source || (block.attractor && block.attractor.source) || {};
    const station = source.station || source.feed || source.region || source.city || '';
    const raw = block.attractor && block.attractor.raw ? block.attractor.raw : '';
    if (raw) return raw;
    if (station) return station;
    return '';
  }

  function generatedPatchTitle(program, text) {
    const blocks = program && Array.isArray(program.blocks) ? program.blocks : [];
    const voices = [];
    const sources = [];

    for (const block of blocks) {
      if (block && block.voice && !voices.includes(block.voice)) voices.push(block.voice);
      const sourceLabel = sourceLabelFromAttractor(block);
      if (sourceLabel && !sources.includes(sourceLabel)) sources.push(sourceLabel);
    }

    if (voices.length || sources.length) {
      const voicePart = voices.length ? voices.slice(0, 3).join(' + ') : 'patch';
      const sourcePart = sources.length ? ` · ${sources.slice(0, 2).join(' · ')}` : '';
      return `${voicePart}${sourcePart}`;
    }

    const field = String(text || '').split('\n').map((line) => line.match(FIELD_COMMENT_RE)).find(Boolean);
    if (field && field[1]) return field[1];
    return 'UNTITLED';
  }
    function computePatchTitle(text, program) {
      const explicit = findExplicitPatchTitle(text);
      if (explicit) {
        return {
          label: formatPatchTitle(explicit.title),
          explicit,
          source: 'patch',
          title: explicit.title,
        };
      }

      if (loadedExampleLabel) {
        const title = normalizePatchTitle(loadedExampleLabel) || 'Untitled Patch';
        return {
          label: `EXAMPLE / ${title.toUpperCase()}`,
          explicit: null,
          source: 'example',
          title,
        };
      }

      const generated = generatedPatchTitle(program, text);
      return {
        label: formatPatchTitle(generated),
        explicit: null,
        source: 'patch',
        title: normalizePatchTitle(generated),
      };
    }

    function patchTitleInfoFromCurrentText() {
      const text = editorAPI ? editorAPI.getValue() : '';
      let program = lastGoodProgram;

      if (window.ReplDSL && window.ReplDSL.parse) {
        const parsed = window.ReplDSL.parse(text);
        if (parsed && parsed.ok) program = parsed.program;
      }

      return computePatchTitle(text, program);
    }

    function patchTitleIsDirty() {
      if (!editorAPI) return false;

      const payload = currentPatchPayload();
      if (!String(payload.code || '').trim()) return false;

      return payload.code !== patchLinkState.lastSavedCode
        || payload.title !== patchLinkState.lastSavedTitle;
    }

    function setPatchTitleChip(label, options) {
      if (!patchTitleChip) return;

      const opts = options || {};
      const labelText = label || 'PATCH / UNTITLED';
      const labelEl = patchTitleChip.querySelector('.patch-title-chip-label');
      const stateEl = patchTitleChip.querySelector('.patch-title-chip-state');
      const isDirty = Boolean(opts.dirty);
      const isExample = opts.source === 'example';
      const isSaved = Boolean(opts.saved) && !isDirty;

      patchTitleChip.classList.toggle('is-dirty', isDirty);
      patchTitleChip.classList.toggle('is-saved', isSaved);
      patchTitleChip.classList.toggle('is-example', isExample);

      if (labelEl) {
        labelEl.textContent = labelText;
      } else {
        patchTitleChip.textContent = labelText;
      }

      if (stateEl) {
        stateEl.textContent = isDirty ? (isExample ? 'MODIFIED' : 'UNSAVED') : (isSaved ? 'SAVED' : '');
        stateEl.hidden = !stateEl.textContent;
      }

      const statePart = stateEl && stateEl.textContent ? ` · ${stateEl.textContent.toLowerCase()}` : '';
      patchTitleChip.setAttribute('aria-label', `Patch title: ${labelText}${statePart}`);
      patchTitleChip.title = 'Click to rename/save patch title · Cmd/Ctrl-S saves current patch hash · Option-click inserts title row';
    }

    function refreshPatchTitle() {
      if (!patchTitleChip || !editorAPI || patchLinkState.editingTitle) return;

      const info = patchTitleInfoFromCurrentText();
      const dirty = patchTitleIsDirty();
      const saved = Boolean(patchLinkState.lastSavedCode && !dirty && info.title);

      setPatchTitleChip(info.label, {
        dirty,
        saved,
        source: info.source,
      });
    }

    function insertPatchTitleMetadata() {
      if (!editorAPI) return;

      const text = editorAPI.getValue();
      const titleInfo = findExplicitPatchTitle(text);

      if (titleInfo) {
        editorAPI.selectRange(titleInfo.from, titleInfo.to);
        editorAPI.focus();
        return;
      }

      const inferred = patchTitleInfoFromCurrentText().title || 'Untitled Patch';
      const title = normalizePatchTitle(inferred) || 'Untitled Patch';
      const prefix = `// title: ${title}\n`;

      editorAPI.dispatchTextChange(0, 0, prefix);
      editorAPI.selectRange(prefix.indexOf(title), prefix.indexOf(title) + title.length);
      editorAPI.focus();
      refreshPatchTitle();
    }

    function upsertPatchTitleMetadata(rawTitle) {
      if (!editorAPI) return '';

      const title = normalizePatchTitle(rawTitle) || 'Untitled Patch';
      const text = editorAPI.getValue();
      const titleInfo = findExplicitPatchTitle(text);

      if (titleInfo) {
        editorAPI.dispatchTextChange(titleInfo.from, titleInfo.to, title);
      } else {
        const prefix = `// title: ${title}\n`;
        const insert = text && !text.startsWith('\n') ? `${prefix}\n` : prefix;
        editorAPI.dispatchTextChange(0, 0, insert);
      }

      loadedExampleLabel = '';
      currentExampleFile = '';
      return title;
    }

    function focusPatchTitleMetadata(selectText) {
      if (!editorAPI) return;

      const titleInfo = findExplicitPatchTitle(editorAPI.getValue());

      if (!titleInfo) {
        openPatchTitleEditor();
        return;
      }

      if (selectText && typeof editorAPI.selectRange === 'function') {
        editorAPI.selectRange(titleInfo.from, titleInfo.to);
      } else {
        editorAPI.setCursor(titleInfo.from);
      }

      editorAPI.focus();
    }

    function closePatchTitleEditor() {
      if (!patchTitleChip) return;

      patchLinkState.editingTitle = false;
      patchTitleChip.classList.remove('is-editing');

      const form = patchTitleChip.querySelector('.patch-title-editor');
      const labelEl = patchTitleChip.querySelector('.patch-title-chip-label');
      const stateEl = patchTitleChip.querySelector('.patch-title-chip-state');

      if (form) form.hidden = true;
      if (labelEl) labelEl.hidden = false;
      if (stateEl && stateEl.textContent) stateEl.hidden = false;

      refreshPatchTitle();
    }

    function openPatchTitleEditor() {
      if (!patchTitleChip || !editorAPI) return;

      const form = patchTitleChip.querySelector('.patch-title-editor');
      const input = patchTitleChip.querySelector('.patch-title-input');

      if (!form || !input) {
        insertPatchTitleMetadata();
        return;
      }

      const info = patchTitleInfoFromCurrentText();

      input.value = normalizePatchTitle(info.title) || '';
      patchLinkState.editingTitle = true;
      patchTitleChip.classList.add('is-editing');

      const labelEl = patchTitleChip.querySelector('.patch-title-chip-label');
      const stateEl = patchTitleChip.querySelector('.patch-title-chip-state');

      if (labelEl) labelEl.hidden = true;
      if (stateEl) stateEl.hidden = true;

      form.hidden = false;

      window.setTimeout(() => {
        input.focus({ preventScroll: true });
        input.select();
      }, 0);
    }

    async function savePatchTitleEditor() {
      if (!patchTitleChip) return;

      const input = patchTitleChip.querySelector('.patch-title-input');
      const title = input ? input.value : patchTitleInfoFromCurrentText().title;

      upsertPatchTitleMetadata(title);
      closePatchTitleEditor();

      await saveCurrentPatchToHash({
        reason: 'rename',
      });
    }

  function closePatchTitleEditor() {
    if (!patchTitleChip) return;
    patchLinkState.editingTitle = false;
    patchTitleChip.classList.remove('is-editing');
    const form = patchTitleChip.querySelector('.patch-title-editor');
    if (form) form.hidden = true;
    const labelEl = patchTitleChip.querySelector('.patch-title-chip-label');
    const stateEl = patchTitleChip.querySelector('.patch-title-chip-state');
    if (labelEl) labelEl.hidden = false;
    if (stateEl && stateEl.textContent) stateEl.hidden = false;
    refreshPatchTitle();
  }

  function openPatchTitleEditor() {
    if (!patchTitleChip || !editorAPI) return;
    const form = patchTitleChip.querySelector('.patch-title-editor');
    const input = patchTitleChip.querySelector('.patch-title-input');
    if (!form || !input) {
      insertPatchTitleMetadata();
      return;
    }

    const info = patchTitleInfoFromCurrentText();
    input.value = normalizePatchTitle(info.title) || '';
    patchLinkState.editingTitle = true;
    patchTitleChip.classList.add('is-editing');
    const labelEl = patchTitleChip.querySelector('.patch-title-chip-label');
    const stateEl = patchTitleChip.querySelector('.patch-title-chip-state');
    if (labelEl) labelEl.hidden = true;
    if (stateEl) stateEl.hidden = true;
    form.hidden = false;
    window.setTimeout(() => {
      input.focus({ preventScroll: true });
      input.select();
    }, 0);
  }

  async function savePatchTitleEditor() {
    if (!patchTitleChip) return;
    const input = patchTitleChip.querySelector('.patch-title-input');
    const title = input ? input.value : patchTitleInfoFromCurrentText().title;
    upsertPatchTitleMetadata(title);
    closePatchTitleEditor();
    await saveCurrentPatchToHash({ quiet: false, reason: 'rename' });
  }

  // ---------------- status / errors ----------------

  function setStatusLine() {
    if (!scheduler) {
      statusEl.textContent = 'idle';
      return;
    }
    const t = scheduler.now();
    const transport = formatTime(t.transport);
    const tempo = lastGoodProgram ? Math.round(lastGoodProgram.tempo) : 110;
    const meter = lastGoodProgram ? `${lastGoodProgram.meter.num}/${lastGoodProgram.meter.den}` : '4/4';
    const tunings = collectProgramTunings(lastGoodProgram);
    let tuningPart = '';
    if (tunings.length === 1) {
      const label = tuningLabel(tunings[0]);
      const measured = tuningMeasuredLabel(tunings[0]);
      tuningPart = ` · tuning ${label}${measured ? ` ${measured}` : ''}`;
    } else if (tunings.length > 1) {
      const shown = tunings.slice(0, 3).map((t) => tuningLabel(t)).join(' -> ');
      const more = tunings.length > 3 ? ` +${tunings.length - 3}` : '';
      tuningPart = ` · tuning scoped (${shown}${more})`;
    }
    const stateLabel = scheduler.isRunning() ? 'playing' : 'stopped';
    const bar = t.bar + 1; // human-readable: bar 1 = first bar
    statusEl.textContent = `${tempo} bpm · ${meter}${tuningPart} · ${stateLabel} · ${transport} · bar ${bar}`;
    refreshVideoStatus();
  }

  function formatTime(s) {
    const total = Math.max(0, Math.floor(s));
    const m = Math.floor(total / 60);
    const r = total % 60;
    return `${m}:${String(r).padStart(2, '0')}`;
  }

  function clearErrors() {
    errorList.innerHTML = '';
  }

    function showErrors(errors) {
      clearErrors();
      lastParseErrorText = Array.isArray(errors) && errors.length
        ? errors.map((e) => `line ${e.line}: ${e.message}`).join('\n')
        : '';

      for (const e of errors) {
        const li = document.createElement('li');
        li.textContent = `line ${e.line}: ${e.message}`;
        errorList.appendChild(li);
      }
    }

  function showWarning(text) {
    const li = document.createElement('li');
    li.textContent = text;
    li.style.color = '#a04';
    errorList.appendChild(li);
  }

  function videoDebugEnabled() {
    return VIDEO_DEBUG_ENABLED;
  }

  function applyVideoDebugGate() {
    if (videoDebugEnabled()) return;

    if (window.VideoVoice && typeof window.VideoVoice.cleanup === 'function') {
      try { window.VideoVoice.cleanup(); } catch (_) {}
    }
    if (videoToolbarEl) videoToolbarEl.hidden = true;
    if (videoPanel) videoPanel.hidden = true;
    if (videoToggleBtn) {
      videoToggleBtn.hidden = true;
      videoToggleBtn.setAttribute('aria-expanded', 'false');
    }
    videoExamplesEnabled = false;
    if (examplePopover && !examplePopover.hidden) {
      // If the popover is already open, re-render so the video category vanishes.
      renderExamplePopover();
    }
  }
    
    // ---------------- field report / bug form ----------------

    function getCurrentPatchText() {
      return editorAPI ? editorAPI.getValue() : '';
    }

    function getCurrentPatchTitle() {
      if (patchTitleChip && patchTitleChip.textContent.trim()) {
        return patchTitleChip.textContent.trim();
      }
      return 'PATCH / UNTITLED';
    }

    function getCheckedValue(form, name, fallback) {
      const checked = form ? form.querySelector(`input[name="${name}"]:checked`) : null;
      return checked ? checked.value : fallback;
    }

    function readFieldReportForm() {
      if (!fieldReportForm) {
        return {
          what: '',
          intent: '',
          kind: 'Other',
          impact: 'Annoying',
          contact: '',
          includePatch: true,
          includeDiagnostics: true,
        };
      }

      const data = new FormData(fieldReportForm);
      return {
        what: String(data.get('what') || '').trim(),
        intent: String(data.get('intent') || '').trim(),
        kind: getCheckedValue(fieldReportForm, 'kind', 'Other'),
        impact: getCheckedValue(fieldReportForm, 'impact', 'Annoying'),
        contact: String(data.get('contact') || '').trim(),
        includePatch: Boolean(data.get('includePatch')),
        includeDiagnostics: Boolean(data.get('includeDiagnostics')),
      };
    }

    function collectFieldReportDiagnostics() {
      const audioState = scheduler && scheduler.ctx ? scheduler.ctx.state : 'not booted';
      const transportState = scheduler
        ? (scheduler.isRunning() ? 'playing' : 'stopped')
        : 'not booted';

      const viewport = `${window.innerWidth} × ${window.innerHeight}`;
      const route = `${window.location.pathname}${window.location.search}${window.location.hash ? '#…' : ''}`;
      const exampleLabel = loadedExampleLabel || 'none';
      const buildNode = document.querySelector('[data-build], .build, #build');
      const build = buildNode ? buildNode.textContent.trim() : 'dev';

      let sampleBank = 'unknown';
      if (window.SampleVoice && typeof window.SampleVoice.list === 'function') {
        try {
          sampleBank = `${window.SampleVoice.list().length} samples available`;
        } catch (_) {
          sampleBank = 'sample list unavailable';
        }
      }

      return [
        ['Build', build],
        ['Route', route],
        ['Browser', navigator.userAgent],
        ['Viewport', viewport],
        ['Patch title', getCurrentPatchTitle()],
        ['Example', exampleLabel],
        ['Transport', transportState],
        ['Audio context', audioState],
        ['Sample bank', sampleBank],
        ['Last parse error', lastParseErrorText || 'none'],
        ['Last runtime error', lastRuntimeErrorText || 'none'],
        ['Timestamp', new Date().toISOString()],
      ];
    }

    function buildFieldReportBody() {
      const report = readFieldReportForm();
      const patchText = getCurrentPatchText();
      const diagnostics = collectFieldReportDiagnostics();

      const parts = [
        '## What happened',
        '',
        report.what || '[not provided]',
        '',
        '## What I was trying to do',
        '',
        report.intent || '[not provided]',
        '',
        '## Bug type',
        '',
        report.kind,
        '',
        '## Impact',
        '',
        report.impact,
        '',
        '## Current patch title',
        '',
        getCurrentPatchTitle(),
        '',
      ];

      if (report.contact) {
        parts.push('## Contact', '', report.contact, '');
      }

      if (report.includePatch) {
        parts.push(
          '## Current patch text',
          '',
          '```repl',
          patchText || '[empty patch]',
          '```',
          ''
        );
      } else {
        parts.push('## Current patch text', '', '[not included]', '');
      }

      if (report.includeDiagnostics) {
        parts.push(
          '## Diagnostics',
          '',
          ...diagnostics.map(([key, value]) => `- ${key}: ${value || 'unknown'}`),
          ''
        );
      } else {
        parts.push('## Diagnostics', '', '[not included]', '');
      }

      return parts.join('\n');
    }

    function buildFieldReportTitle() {
      const report = readFieldReportForm();
      const kind = report.kind || 'Bug';
      const title = getCurrentPatchTitle().replace(/^PATCH\s*\/\s*/i, '').trim() || 'Untitled patch';
      return `[REPL] ${kind} — ${title}`;
    }

    function refreshFieldReportPreview() {
      if (!fieldReportPreview) return;
      fieldReportPreview.value = buildFieldReportBody();
    }

    function openFieldReportDialog() {
      if (!fieldReportDialog || !fieldReportForm) return;

      refreshFieldReportPreview();

      if (typeof fieldReportDialog.showModal === 'function') {
        fieldReportDialog.showModal();
      } else {
        fieldReportDialog.setAttribute('open', '');
      }

      const first = fieldReportForm.querySelector('textarea[name="what"]');
      if (first) first.focus();
    }

    function closeFieldReportDialog() {
      if (!fieldReportDialog) return;

      if (typeof fieldReportDialog.close === 'function') {
        fieldReportDialog.close();
      } else {
        fieldReportDialog.removeAttribute('open');
      }

      if (editorAPI) editorAPI.focus();
    }

    async function copyFieldReport() {
      const body = buildFieldReportBody();

      try {
        await navigator.clipboard.writeText(body);
        if (fieldReportCopyBtn) {
          fieldReportCopyBtn.classList.add('copied');
          fieldReportCopyBtn.textContent = 'copied';
          window.setTimeout(() => {
            fieldReportCopyBtn.classList.remove('copied');
            fieldReportCopyBtn.textContent = 'copy report';
          }, 1400);
        }
      } catch (_) {
        if (fieldReportPreview) {
          fieldReportPreview.focus();
          fieldReportPreview.select();
        }
        showWarning('clipboard unavailable — report selected for manual copy');
      }
    }

    function openFieldReportIssue() {
      const title = buildFieldReportTitle();
      const body = buildFieldReportBody();
      const report = readFieldReportForm();

      const url = new URL(FIELD_REPORT_ISSUE_URL);
      url.searchParams.set('title', title);
      url.searchParams.set('body', body);
      url.searchParams.set('labels', `bug,repl,${report.kind.toLowerCase().replace(/[^a-z0-9]+/g, '-')}`);

      window.open(url.toString(), '_blank', 'noopener,noreferrer');
    }

    function bindFieldReport() {
      if (!fieldReportDialog || !fieldReportForm) return;

      fieldReportOpenBtns.forEach((btn) => {
        btn.addEventListener('click', openFieldReportDialog);
      });

      fieldReportCloseBtns.forEach((btn) => {
        btn.addEventListener('click', closeFieldReportDialog);
      });

      fieldReportForm.addEventListener('input', refreshFieldReportPreview);
      fieldReportForm.addEventListener('change', refreshFieldReportPreview);

      if (fieldReportCopyBtn) {
        fieldReportCopyBtn.addEventListener('click', copyFieldReport);
      }

      fieldReportForm.addEventListener('submit', (event) => {
        event.preventDefault();

        if (!fieldReportForm.reportValidity()) {
          refreshFieldReportPreview();
          return;
        }

        refreshFieldReportPreview();
        openFieldReportIssue();
      });

      fieldReportDialog.addEventListener('click', (event) => {
        if (event.target === fieldReportDialog) closeFieldReportDialog();
      });

      fieldReportDialog.addEventListener('cancel', () => {
        window.setTimeout(() => {
          if (editorAPI) editorAPI.focus();
        }, 0);
      });
    }

  // ---------------- evaluation ----------------

    function evaluatePolicyForProgram(program) {
      const raw = program && program.transport ? program.transport.evaluate : null;
      if (raw && typeof raw === 'object') {
        const mode = typeof raw.mode === 'string' ? raw.mode.toLowerCase() : '';
        return {
          mode: mode === 'reset' ? 'reset' : 'immediate',
          cutOnReset: Boolean(raw.cutOnReset),
        };
      }
      const mode = typeof raw === 'string' ? raw.toLowerCase() : '';
      return {
        mode: mode === 'reset' ? 'reset' : 'immediate',
        cutOnReset: false,
      };
    }

    function collectProgramTunings(program) {
      const out = [];
      const seen = new Set();
      const blocks = program && Array.isArray(program.blocks) ? program.blocks : [];
      for (const block of blocks) {
        const tuning = block && block.tuning ? block.tuning : null;
        if (!tuning || typeof tuning !== 'object') continue;
        const id = String(tuning.id || tuning.requestedId || '');
        if (!id) continue;
        const a4 = Number.isFinite(Number(tuning.a4Hz)) ? Number(tuning.a4Hz) : null;
        const key = `${id}::${a4 == null ? '' : a4}`;
        if (seen.has(key)) continue;
        seen.add(key);
        out.push(tuning);
      }
      if (out.length === 0 && program && program.tuning) {
        out.push(program.tuning);
      }
      return out;
    }

    function tuningLabel(tuning) {
      if (!tuning || typeof tuning !== 'object') return 'selected';
      const id = tuning.id || tuning.requestedId || 'selected';
      const a4 = Number.isFinite(Number(tuning.a4Hz)) ? Number(tuning.a4Hz) : null;
      return `${id}${a4 != null ? ` @${a4}Hz` : ''}`;
    }

    function tuningMeasuredLabel(tuning) {
      if (
        !tuning
        || !window.ReplTunings
        || typeof window.ReplTunings.tuningToRuntime !== 'function'
        || typeof window.ReplTunings.midiToFreq !== 'function'
      ) return '';
      try {
        const runtime = window.ReplTunings.tuningToRuntime(tuning);
        const a4 = runtime ? Number(window.ReplTunings.midiToFreq(69, runtime)) : NaN;
        const c4 = runtime ? Number(window.ReplTunings.midiToFreq(60, runtime)) : NaN;
        if (Number.isFinite(a4) && Number.isFinite(c4)) {
          return `A4=${a4.toFixed(2)}Hz C4=${c4.toFixed(2)}Hz`;
        }
      } catch (_) {}
      return '';
    }

    function tuningWarningText(program) {
      const tunings = collectProgramTunings(program).filter((t) => t && t.non12);
      if (tunings.length === 0) return '';
      if (tunings.length === 1) {
        const t = tunings[0];
        const id = t.id || t.requestedId || 'selected tuning';
        return `tuning '${id}' uses ${t.noteCount || 'non-12'} notes per octave — pitch names (A4, C4, etc.) are abstract mapping labels in this system`;
      }
      const list = tunings.slice(0, 3).map((t) => t.id || t.requestedId || 'selected').join(', ');
      const more = tunings.length > 3 ? ` (+${tunings.length - 3} more)` : '';
      return `scoped tunings include non-12 systems (${list}${more}) — pitch names (A4, C4, etc.) are abstract mapping labels in those systems`;
    }

    function tuningActivationText(program) {
      const tunings = collectProgramTunings(program);
      if (tunings.length === 0) return '';
      if (tunings.length === 1) {
        const label = tuningLabel(tunings[0]);
        const measured = tuningMeasuredLabel(tunings[0]);
        return `tuning '${label}' active${measured ? ` · ${measured}` : ''}`;
      }
      const list = tunings.slice(0, 3).map((t) => tuningLabel(t)).join(' -> ');
      const more = tunings.length > 3 ? ` +${tunings.length - 3}` : '';
      return `scoped tuning active (${tunings.length} regions) · ${list}${more}`;
    }

    async function evaluateAndRun() {
      const text = editorAPI ? editorAPI.getValue() : '';
      const result = window.ReplDSL.parse(text);

      if (!result.ok) {
        showErrors(result.errors);
        // Keep the previously-running program; don't yank audio out.
        return;
      }

      clearErrors();
      lastParseErrorText = '';
      applyStoredBlockMuteOverrides(result.program);
      lastGoodProgram = result.program;
      refreshPatchTitle();

      const tuningActivation = tuningActivationText(result.program);
      const tuningWarning = tuningWarningText(result.program);
      if (tuningActivation || tuningWarning) {
        if (tuningActivation) showWarning(tuningActivation);
        if (tuningWarning) showWarning(tuningWarning);
        setTimeout(clearErrors, 2400);
      }

      try {
        if (window.ReplAttractors && window.ReplAttractors.warm) {
          window.ReplAttractors.warm(result.program);
        }

        renderTransportShell(result.program);
        syncEditorBlockMuteLines();

        if (!scheduler) bootScheduler();
        if (!scheduler) return;

        const armed = await armInputsForProgram(result.program);
        if (!armed) return;
        const videoArmed = await armVideoForProgram(result.program);
        if (!videoArmed) return;
        lastEvaluatedText = text;

        // Hard evaluate/play:
        // - stop current audio first
        // - install the newly parsed AST
        // - start from transport zero
        //
        // This intentionally differs from safePlay(), because Cmd-Enter / [play]
        // should rebuild runtime state and allow frozen random choices to reroll.
        const evaluatePolicy = evaluatePolicyForProgram(result.program);
        if (scheduler.isRunning() && evaluatePolicy.mode === 'reset' && typeof scheduler.queueEvaluateAtReset === 'function') {
          const when = scheduler.queueEvaluateAtReset(result.program, { stopVoices: evaluatePolicy.cutOnReset });
          if (Number.isFinite(Number(when))) {
            showWarning(
              evaluatePolicy.cutOnReset
                ? 'evaluate queued — next bar reset will cut previous audio (eval reset cut)'
                : 'evaluate queued — next bar reset keeps previous tails (eval reset keep)'
            );
            setTimeout(clearErrors, 1800);
          }
          syncEditorBlockMuteLines();
          lastRuntimeErrorText = '';
          return;
        }

        if (scheduler.isRunning()) {
          scheduler.stop();
        }

        scheduler.update(result.program);
        scheduler.start();
        syncEditorBlockMuteLines();
        lastRuntimeErrorText = '';
      } catch (err) {
        lastRuntimeErrorText = err && err.stack ? err.stack : String(err || 'unknown runtime error');
        showWarning(`runtime error — ${err && err.message ? err.message : 'see field report diagnostics'}`);
      }
    }

    async function safePlay() {
      if (!scheduler) bootScheduler();

      if (!scheduler || !lastGoodProgram) {
        await evaluateAndRun();
        return;
      }

      const currentText = editorAPI ? String(editorAPI.getValue() || '') : '';
      if (currentText !== String(lastEvaluatedText || '')) {
        showWarning('patch changed since last evaluate — running evaluate');
        await evaluateAndRun();
        return;
      }

      const armed = await armInputsForProgram(lastGoodProgram);
      if (!armed) return;
      const videoArmed = await armVideoForProgram(lastGoodProgram);
      if (!videoArmed) return;

      if (typeof scheduler.safeRestart === 'function') {
        scheduler.safeRestart();
      } else {
        // Fallback for stale cached scheduler.js.
        scheduler.stop();
        scheduler.start();
      }
      syncEditorBlockMuteLines();
    }

    function stop() {
      if (scheduler) {
        scheduler.stop();
      }
      syncEditorBlockMuteLines();
      setStatusLine();
      clearActiveClasses();
    }

    function bootScheduler() {
      const audioCtx = window.StringVoice.ensureAudio();
    if (!audioCtx) {
      showWarning('this browser doesn\'t support the Web Audio API');
      return;
    }
    window.StringVoice.resume();
    if (window.InputVoice && window.InputVoice.setAudioContext) {
      window.InputVoice.setAudioContext(audioCtx);
    }
    if (window.PianoVoice && typeof window.PianoVoice.prewarm === 'function') {
      window.PianoVoice.prewarm(audioCtx).catch(() => {});
    }
    if (window.ViolinVoice && typeof window.ViolinVoice.prewarm === 'function') {
      window.ViolinVoice.prewarm(audioCtx).catch(() => {});
    }
    if (videoDebugEnabled() && window.VideoVoice && window.VideoVoice.setAudioContext) {
      window.VideoVoice.setAudioContext(audioCtx);
    }
    if (videoDebugEnabled() && window.VideoVoice && window.VideoVoice.setStageCanvas && videoStageCanvas) {
      window.VideoVoice.setStageCanvas(videoStageCanvas);
    }
    const masterBus = window.StringVoice.getMasterBus();
    scheduler = window.ReplScheduler.create({ audioCtx, masterBus });
    syncEditorBlockMuteLines();
    scheduler.onMissingSample((name) => {
      if (typeof name === 'string' && name.startsWith('drum-kit:')) {
        const id = name.slice('drum-kit:'.length) || '(missing)';
        if (id === '(missing)') {
          showWarning(`drum block is missing a kit row — add 'kit <id>'`);
        } else {
          showWarning(`drum kit '${id}' is not defined in the sample manifest`);
        }
        return;
      }
      if (typeof name === 'string' && name.startsWith('drum-lane:')) {
        const parts = name.split(':');
        const kitId = parts[1] || '?';
        const lane = parts[2] || '?';
        showWarning(`drum kit '${kitId}' has no resolved samples for lane '${lane}'`);
        return;
      }
      showWarning(`'${name}' isn't in the bank yet — see /labs/repl/samples/README.md`);
    });
  }

    // ---------------- URL hash share ----------------

    function getPatchTitleForShare() {
      if (!editorAPI) return '';

      const info = patchTitleInfoFromCurrentText();
      return normalizePatchTitle(info && info.title ? info.title : '');
    }

    function currentPatchPayload() {
      return {
        title: getPatchTitleForShare(),
        code: editorAPI ? editorAPI.getValue() : '',
      };
    }

    async function saveCurrentPatchToHash(options) {
      const opts = options || {};

      if (!window.ReplPatchLinks) {
        showWarning('save codec unavailable');
        setTimeout(clearErrors, 3000);
        return false;
      }

      const payload = currentPatchPayload();

      if (!String(payload.code || '').trim()) {
        showWarning('nothing to save yet');
        setTimeout(clearErrors, 2500);
        return false;
      }

      try {
        await window.ReplPatchLinks.write(payload, { push: true });
        upsertSavedPatchRecord(payload, currentPatchHashValue());

        patchLinkState.lastSavedCode = payload.code;
        patchLinkState.lastSavedTitle = payload.title;

        refreshPatchTitle();

        showWarning(opts.reason === 'rename'
          ? 'patch renamed + saved to URL'
          : 'patch saved to URL'
        );
        setTimeout(clearErrors, 2200);

        return true;
      } catch (err) {
        console.warn('[repl] save failed:', err);
        showWarning('patch save failed');
        setTimeout(clearErrors, 3500);
        return false;
      }
    }

    async function saveCurrentPatchToHash(options) {
      const opts = options || {};
      if (!window.ReplPatchLinks) {
        showWarning('save codec unavailable');
        setTimeout(clearErrors, 3000);
        return false;
      }

      const payload = currentPatchPayload();
      if (!String(payload.code || '').trim()) {
        showWarning('nothing to save yet');
        setTimeout(clearErrors, 2500);
        return false;
      }

      try {
        await window.ReplPatchLinks.write(payload, { push: true });
        upsertSavedPatchRecord(payload, currentPatchHashValue());
        patchLinkState.lastSavedCode = payload.code;
        patchLinkState.lastSavedTitle = payload.title;
        refreshPatchTitle();
        showWarning(opts.reason === 'rename' ? 'patch renamed + saved to URL' : 'patch saved to URL');
        setTimeout(clearErrors, 2200);
        return true;
      } catch (err) {
        console.warn('[repl] save failed:', err);
        showWarning('patch save failed');
        setTimeout(clearErrors, 3500);
        return false;
      }
    }

    function setShareVisual(state, label) {
      if (!shareBtn) return;

      shareBtn.classList.remove('is-copied', 'is-warn', 'is-error');
      if (state) shareBtn.classList.add(state);

      const main = shareBtn.querySelector('.button-main');
      const shortcut = shareBtn.querySelector('.button-shortcut');
      const status = document.getElementById('sharePatchStatus');

      if (main) main.textContent = label || 'share';
      else shareBtn.textContent = label || 'share';

      if (shortcut) shortcut.textContent = 'copy link';
      if (status) status.textContent = label && label !== 'share' ? label : '';

      window.clearTimeout(shareBtn._shareResetTimer);
      if (label && label !== 'share') {
        shareBtn._shareResetTimer = window.setTimeout(() => {
          shareBtn.classList.remove('is-copied', 'is-warn', 'is-error');
          if (main) main.textContent = 'share';
          if (shortcut) shortcut.textContent = 'copy link';
          if (status) status.textContent = '';
        }, 1800);
      }
    }

    async function persistPatchHashNow() {
      if (!window.ReplPatchLinks) return;
      if (patchLinkState.applyingRemotePatch) return;

      const payload = currentPatchPayload();
      if (!payload.code.trim()) return;

      if (
        payload.code === patchLinkState.lastSavedCode
        && payload.title === patchLinkState.lastSavedTitle
      ) {
        return;
      }

      try {
        const result = await window.ReplPatchLinks.write(payload, { replace: true });
        patchLinkState.lastSavedCode = payload.code;
        patchLinkState.lastSavedTitle = payload.title;

        if (result && result.warn) {
          setShareVisual('is-warn', 'long link');
        }
      } catch (err) {
        console.warn('[repl] could not persist patch hash:', err);
        setShareVisual('is-error', 'hash fail');
      }
    }

    function schedulePatchHashPersist() {
      if (patchLinkState.applyingRemotePatch) return;

      window.clearTimeout(patchLinkState.writeTimer);
      patchLinkState.writeTimer = window.setTimeout(() => {
        refreshPatchTitle();
      }, PATCH_HASH_DEBOUNCE_MS);
    }

    async function shareCurrent() {
      if (!window.ReplPatchLinks) {
        showWarning('share codec unavailable');
        setTimeout(clearErrors, 3000);
        return;
      }

      const payload = currentPatchPayload();

      if (!payload.code.trim()) {
        showWarning('nothing to share yet');
        setTimeout(clearErrors, 2500);
        return;
      }

      if (shareBtn) shareBtn.disabled = true;

      try {
        const result = await window.ReplPatchLinks.share(payload);

        patchLinkState.lastSavedCode = payload.code;
        patchLinkState.lastSavedTitle = payload.title;

          await window.ReplPatchLinks.write(payload, { push: true });
          refreshPatchTitle();

          if (result.warn) {
          setShareVisual('is-warn', result.copied ? 'copied · long' : 'long link');
        } else {
          setShareVisual(result.copied ? 'is-copied' : 'is-warn', result.copied ? 'copied url' : 'copy failed');
        }

        showWarning(result.copied ? 'share link copied to clipboard' : 'URL bar updated — copy from there to share');
        setTimeout(clearErrors, 2500);
      } catch (err) {
        console.warn('[repl] share failed:', err);
        setShareVisual('is-error', 'too large');
        showWarning('patch link too large or share failed');
        setTimeout(clearErrors, 3500);
      } finally {
        if (shareBtn) shareBtn.disabled = false;
      }
    }
    
    function setClearPatchVisual(state) {
      if (!clearPatchBtn) return;

      const main = clearPatchBtn.querySelector('.button-main');
      const shortcut = clearPatchBtn.querySelector('.button-shortcut');

      clearPatchBtn.classList.remove(
        'is-armed',
        'is-blank-armed',
        'is-cleared'
      );

      if (state === 'armed') {
        clearPatchBtn.classList.add('is-armed');
        if (main) main.textContent = '?';
        if (shortcut) shortcut.textContent = 'click again to clear patch';
        clearPatchBtn.setAttribute('aria-label', 'Confirm clear patch');
        clearPatchBtn.title = 'Click again to clear patch';
        return;
      }

      if (state === 'blank-armed') {
        clearPatchBtn.classList.add('is-blank-armed');
        if (main) main.textContent = '∅';
        if (shortcut) shortcut.textContent = 'click again to blank editor';
        clearPatchBtn.setAttribute('aria-label', 'Confirm blank editor');
        clearPatchBtn.title = 'Click again to blank editor';
        return;
      }

      if (state === 'cleared') {
        clearPatchBtn.classList.add('is-cleared');
        if (main) main.textContent = '✓';
        if (shortcut) shortcut.textContent = 'patch cleared';
        clearPatchBtn.setAttribute('aria-label', 'Patch cleared');
        clearPatchBtn.title = 'Patch cleared';
        return;
      }

      if (main) main.textContent = '×';
      if (shortcut) shortcut.textContent = 'clear patch';
      clearPatchBtn.setAttribute('aria-label', 'Clear patch');
      clearPatchBtn.title = 'Clear patch · Cmd/Ctrl-Shift-Backspace. Option-click: blank editor.';
    }

    function resetClearPatchArm() {
      window.clearTimeout(clearPatchState.timer);
      clearPatchState.armed = false;
      clearPatchState.blank = false;
      clearPatchState.timer = null;
      setClearPatchVisual('idle');
    }

    function armClearPatch(options) {
      const opts = options || {};

      window.clearTimeout(clearPatchState.timer);
      clearPatchState.armed = true;
      clearPatchState.blank = Boolean(opts.blank);

      setClearPatchVisual(clearPatchState.blank ? 'blank-armed' : 'armed');

      clearPatchState.timer = window.setTimeout(() => {
        resetClearPatchArm();
      }, CLEAR_PATCH_ARM_MS);
    }

    function clearPatchHashIfNeeded() {
      try {
        if (!window.location.hash || !window.location.hash.startsWith('#patch=v1.')) return;
        const nextUrl = `${window.location.pathname}${window.location.search}`;
        window.history.replaceState(null, '', nextUrl);
      } catch (_) {}
    }

    function performClearPatch(options) {
      const opts = options || {};
      const blank = Boolean(opts.blank);

      window.clearTimeout(clearPatchState.timer);
      clearPatchState.armed = false;
      clearPatchState.timer = null;

      stop();

      loadedExampleLabel = '';
      currentExampleFile = '';
      lastGoodProgram = null;
      lastEvaluatedText = '';
      lastParseErrorText = '';
      lastRuntimeErrorText = '';
      lastEditorMuteSnapshotKey = '';

      if (blockMuteOverridesBySignature && typeof blockMuteOverridesBySignature.clear === 'function') {
        blockMuteOverridesBySignature.clear();
      }

      if (editorAPI && typeof editorAPI.setValue === 'function') {
        editorAPI.setValue(blank ? '' : CLEAR_PATCH_SCAFFOLD);
      }

      patchLinkState.applyingRemotePatch = false;
      patchLinkState.lastSavedCode = '';
      patchLinkState.lastSavedTitle = '';
      window.clearTimeout(patchLinkState.writeTimer);
      patchLinkState.writeTimer = null;

      clearPatchHashIfNeeded();
      clearErrors();

      if (exampleCurrentLabel) {
        exampleCurrentLabel.textContent = 'load…';
      }

      refreshPatchTitle();
      syncEditorBlockMuteLines();
      setStatusLine();
      setShareVisual('', 'share');
      setClearPatchVisual('cleared');

      window.setTimeout(() => {
        if (!clearPatchState.armed) setClearPatchVisual('idle');
      }, 1300);

      if (editorAPI) editorAPI.focus();
    }

    function requestClearPatch(options) {
      const opts = options || {};

      if (clearPatchState.armed) {
        performClearPatch({
          blank: Boolean(clearPatchState.blank || opts.blank),
        });
        return;
      }

      armClearPatch({
        blank: Boolean(opts.blank),
      });

      showWarning(opts.blank
        ? 'blank editor armed — click clear patch again to remove all score text'
        : 'clear patch armed — click clear patch again to reset the score'
      );
      window.setTimeout(clearErrors, CLEAR_PATCH_ARM_MS);
    }

    async function loadFromHash() {
      if (!location.hash || location.hash === '#') return false;

      if (location.hash.startsWith('#example=')) return false;

      if (!window.ReplPatchLinks) {
        showWarning('share codec unavailable — falling back to default example');
        return false;
      }

      if (!location.hash.startsWith('#patch=v1.')) {
        return false;
      }

      const shared = await window.ReplPatchLinks.read();

      if (shared && typeof shared.code === 'string' && shared.code.trim()) {
        patchLinkState.applyingRemotePatch = true;

        try {
          loadedExampleLabel = '';
          currentExampleFile = '';
          if (editorAPI) editorAPI.setValue(shared.code);
          patchLinkState.lastSavedCode = shared.code;
          patchLinkState.lastSavedTitle = shared.title || '';
          refreshPatchTitle();
          return true;
        } finally {
          patchLinkState.applyingRemotePatch = false;
        }
      }

      showWarning('couldn\'t load shared patch — falling back to default example');
      return false;
    }

  async function loadDefaultExample() {
    try {
      const r = await fetch(DEFAULT_EXAMPLE_URL);
      if (r.ok) {
        const t = await r.text();
        loadedExampleLabel = 'default';
        if (editorAPI) editorAPI.setValue(t);
        refreshPatchTitle();
        return;
      }
    } catch (_) {}
    if (editorAPI) {
      loadedExampleLabel = '';
      editorAPI.setValue('// failed to load default example. start typing.\n\ntempo 110\n\nstring   A3   C4   E4   G4\nforce    f    mf   p    f\n');
      refreshPatchTitle();
    }
  }

    // ---------------- reference sidebar ----------------

    function setReferenceOpen(open, opts) {
      const options = opts || {};
      const shouldOpen = Boolean(open);

      if (referencePanel) {
        referencePanel.hidden = !shouldOpen;
      }

      if (referenceToggleBtn) {
        referenceToggleBtn.setAttribute('aria-expanded', shouldOpen ? 'true' : 'false');
      }

      if (replWorkspace) {
        replWorkspace.classList.toggle('reference-closed', !shouldOpen);
      }

      if (!shouldOpen && options.markSeen !== false) {
        try { localStorage.setItem(REFERENCE_SEEN_KEY, '1'); } catch (_) {}
      }
    }

    function toggleReference() {
      const isOpen = referencePanel ? !referencePanel.hidden : false;
      setReferenceOpen(!isOpen, { markSeen: isOpen });
      if (editorAPI) editorAPI.focus();
    }

    function initReferencePanel() {
      let seen = false;
      try { seen = localStorage.getItem(REFERENCE_SEEN_KEY) === '1'; } catch (_) {}
      setReferenceOpen(!seen, { markSeen: false });
      shouldAutofocusEditor = seen;
    }
    
  // ---------------- editor keybindings ----------------
  //
  // Editor-local keymap (Cmd-Enter, Cmd-Shift-Enter, Esc, Tab, Cmd-/, Cmd-S,
  // Cmd-I, Cmd-K) lives in repl-editor.js. The button handlers below cover the
  // pointer-driven path and refocus the editor afterwards.

    playBtn.addEventListener('click', async () => {
      await evaluateAndRun();
      if (editorAPI) editorAPI.focus();
    });
    if (safePlayBtn) {
      safePlayBtn.addEventListener('click', async () => {
        await safePlay();
        if (editorAPI) editorAPI.focus();
      });
    }
    stopBtn.addEventListener('click', () => {
      stop();
      if (editorAPI) editorAPI.focus();
    });
    shareBtn.addEventListener('click', async () => {
      await shareCurrent();
      if (editorAPI) editorAPI.focus();
    });

    if (clearPatchBtn) {
      clearPatchBtn.addEventListener('click', (event) => {
        event.preventDefault();
        requestClearPatch({
          blank: Boolean(event.altKey),
        });
      });
    }
    if (referenceToggleBtn) {
      referenceToggleBtn.addEventListener('click', toggleReference);
    }

    if (referenceCloseBtn) {
      referenceCloseBtn.addEventListener('click', () => {
        setReferenceOpen(false);
        if (editorAPI) editorAPI.focus();
      });
    }

    if (patchTitleChip) {
      patchTitleChip.addEventListener('click', (e) => {
        const target = e.target;

        if (target && target.closest && target.closest('.patch-title-editor')) return;

        if (e.altKey) {
          e.preventDefault();
          insertPatchTitleMetadata();
          return;
        }

        e.preventDefault();
        openPatchTitleEditor();
      });

      patchTitleChip.addEventListener('keydown', (e) => {
        const target = e.target;

        if (target && target.closest && target.closest('.patch-title-editor')) return;

        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openPatchTitleEditor();
        }
      });

      const titleForm = patchTitleChip.querySelector('.patch-title-editor');
      const titleCancel = patchTitleChip.querySelector('[data-title-cancel]');

      if (titleForm) {
        titleForm.addEventListener('submit', (e) => {
          e.preventDefault();
          savePatchTitleEditor();
        });

        titleForm.addEventListener('keydown', (e) => {
          if (e.key === 'Escape') {
            e.preventDefault();
            closePatchTitleEditor();
            if (editorAPI) editorAPI.focus();
          }
        });
      }

      if (titleCancel) {
        titleCancel.addEventListener('click', (e) => {
          e.preventDefault();
          closePatchTitleEditor();
          if (editorAPI) editorAPI.focus();
        });
      }
    }

  // Document-level Esc safety net: if the user presses Esc anywhere inside
  // the REPL shell, stop audio and refocus the editor. Scoped to the REPL
  // so it doesn't interfere with other browser controls outside.
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    const replShell = document.querySelector('main.shell');
    const t = e.target;
    if (!replShell || !(t instanceof Node) || !replShell.contains(t)) return;
    // If a CodeMirror keymap already handled Esc inside the editor, this
    // path is harmless: stop() is idempotent and focus() is too.
    stop();
    if (editorAPI) editorAPI.focus();
  });
    
    document.addEventListener('keydown', (event) => {
      const key = String(event.key || '').toLowerCase();
      const hasCommandModifier = Boolean(event.metaKey || event.ctrlKey);

      if (!hasCommandModifier || key !== 's') return;

      const replShell = document.querySelector('main.shell');
      const target = event.target;

      if (!replShell || !(target instanceof Node) || !replShell.contains(target)) return;

      event.preventDefault();
      event.stopPropagation();

      saveCurrentPatchToHash({
        reason: 'save',
      });
    });

    document.addEventListener('keydown', (event) => {
      const key = String(event.key || '');
      const isDeleteKey = key === 'Backspace' || key === 'Delete';
      const hasCommandModifier = Boolean(event.metaKey || event.ctrlKey);

      if (!hasCommandModifier || !event.shiftKey || !isDeleteKey) return;

      const replShell = document.querySelector('main.shell');
      const target = event.target;
      if (!replShell || !(target instanceof Node) || !replShell.contains(target)) return;

      event.preventDefault();
      event.stopPropagation();

      requestClearPatch({
        blank: Boolean(event.altKey),
      });
    });



  document.addEventListener('keydown', (event) => {
    const key = String(event.key || '').toLowerCase();
    const hasCommandModifier = Boolean(event.metaKey || event.ctrlKey);
    if (!hasCommandModifier || key !== 's') return;

    const replShell = document.querySelector('main.shell');
    const target = event.target;
    if (!replShell || !(target instanceof Node) || !replShell.contains(target)) return;

    event.preventDefault();
    event.stopPropagation();
    saveCurrentPatchToHash({ reason: 'save' });
  });

  function setupExamplePicker(selectEl) {
    if (!selectEl || selectEl.dataset.customPicker === '1') return;
    selectEl.dataset.customPicker = '1';
    selectEl.classList.add('native-example-select');
    selectEl.setAttribute('aria-hidden', 'true');
    selectEl.tabIndex = -1;

    const picker = document.createElement('span');
    picker.className = 'example-picker';

    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'example-picker-button';
    button.setAttribute('aria-haspopup', 'listbox');
    button.setAttribute('aria-expanded', 'false');
    button.innerHTML = '<span class="button-main">load example</span><span class="button-shortcut">choose patch</span>';

    const list = document.createElement('ul');
    list.className = 'example-picker-list';
    list.setAttribute('role', 'listbox');
    list.hidden = true;

    const colors = ['ryb-red', 'ryb-yellow', 'ryb-blue'];
    Array.from(selectEl.options).forEach((opt) => {
      if (!opt.value) return;
      const item = document.createElement('li');
      item.setAttribute('role', 'presentation');

      const row = document.createElement('button');
      row.type = 'button';
      const optionIndex = list.children.length;
      row.className = `example-picker-option ${colors[optionIndex % colors.length]}`;
      row.setAttribute('role', 'option');
      row.dataset.value = opt.value;
      row.textContent = opt.textContent || opt.value;

      row.addEventListener('click', () => {
        selectEl.value = row.dataset.value || '';
        selectEl.dispatchEvent(new Event('change', { bubbles: true }));
        closePicker();
      });

      item.appendChild(row);
      list.appendChild(item);
    });

    function openPicker() {
      list.hidden = false;
      button.setAttribute('aria-expanded', 'true');
      const first = list.querySelector('.example-picker-option');
      if (first) first.focus({ preventScroll: true });
    }

    function closePicker() {
      list.hidden = true;
      button.setAttribute('aria-expanded', 'false');
    }

    function togglePicker() {
      if (list.hidden) openPicker();
      else closePicker();
    }

    button.addEventListener('click', togglePicker);
    button.addEventListener('keydown', (e) => {
      if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openPicker();
      }
    });

    list.addEventListener('keydown', (e) => {
      const rows = Array.from(list.querySelectorAll('.example-picker-option'));
      const current = document.activeElement;
      const idx = rows.indexOf(current);
      if (e.key === 'Escape') {
        e.preventDefault();
        closePicker();
        button.focus();
        return;
      }
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        (rows[Math.min(rows.length - 1, idx + 1)] || rows[0] || button).focus();
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        (rows[Math.max(0, idx - 1)] || rows[rows.length - 1] || button).focus();
      }
      if (e.key === 'Home') {
        e.preventDefault();
        if (rows[0]) rows[0].focus();
      }
      if (e.key === 'End') {
        e.preventDefault();
        if (rows[rows.length - 1]) rows[rows.length - 1].focus();
      }
    });

    document.addEventListener('click', (e) => {
      if (!picker.contains(e.target)) closePicker();
    });

    selectEl.parentNode.insertBefore(picker, selectEl.nextSibling);
    picker.appendChild(button);
    picker.appendChild(list);
  }

  // ---------------- examples loader ----------------

  // ---- categorized example popover ----
  // Replaces the old <select id="example-select">. Tabs group examples by
  // topic; URL hash (`#example=<slug>`) survives refresh and can be deep-linked.

  const EXAMPLE_CATEGORIES = [
    { id: 'foundations', label: 'foundations', examples: [
      { file: '0a. welcome.txt', label: '0a. welcome (start here)' },
      { file: '0b. a row of notes.txt', label: '0b. a row of notes' },
      { file: '0c. rests and ties.txt', label: '0c. rests and ties' },
      { file: '0d. two voices.txt', label: '0d. two voices' },
      { file: '0e. tempo and meter.txt', label: '0e. tempo and meter' },
      { file: 'default.txt', label: 'default' },
      { file: '1. literal-vs-coupled.txt', label: 'literal vs coupled' },
      { file: '1b. arrangement.txt', label: 'arrangement (enter/exit)' },
      { file: '2. pitch-organism.txt', label: 'pitch organism' },
      { file: '2b. sine-noise-voices.txt', label: 'sine + noise voices' },
      { file: '2c. drone-pluck-pulse.txt', label: 'drone + pluck + pulse' },
      { file: '3. sample-field.txt', label: 'sample field' },
      { file: '4. speed-warp.txt', label: 'speed warp' },
    ] },
    { id: 'coupling', label: 'coupling', examples: [
      { file: '5. weather-dew.txt', label: 'weather dew' },
      { file: '6. quake-rupture.txt', label: 'quake rupture' },
      { file: '7. tide-breath.txt', label: 'tide breath' },
      { file: '8. solar-flare.txt', label: 'solar flare' },
      { file: '9. archive-memory.txt', label: 'archive memory' },
    ] },
    { id: 'reference', label: 'reference', examples: [
      { file: '10. notation-reference.txt', label: 'notation reference' },
      { file: '11. effect-surfaces.txt', label: 'effect surfaces' },
      { file: '12. weather-body.txt', label: 'weather body' },
      { file: '13. archive-scar.txt', label: 'archive scar' },
      { file: '14. fades.txt', label: 'fades' },
    ] },
    { id: 'live-input', label: 'live input', examples: [
      { file: '15. live-input.txt', label: 'live input primer' },
      { file: '16. live-input-modulation.txt', label: 'live input modulation' },
      { file: '17. live-input-as-silent-attractor.txt', label: 'silent mic attractor' },
      { file: '18. live-input-as-audible-material.txt', label: 'audible mic material' },
      { file: '19. tab-input-sample-weather.txt', label: 'tab input sample weather' },
      { file: '20. interface-input-cybernetic-score.txt', label: 'interface input cybernetic score' },
    ] },
    { id: 'video', label: 'video', isVideo: true, examples: [
      { file: '2e. video-arm-v1.txt', label: 'video arm v1', isVideo: true },
      { file: '21. video-01-camera-basics.txt', label: 'video 01 camera basics', isVideo: true },
      { file: '22. video-02-camera-pattern-overlay.txt', label: 'video 02 camera pattern overlay', isVideo: true },
      { file: '23. video-03-video-as-input-signals.txt', label: 'video 03 video as input signals', isVideo: true },
      { file: '24. video-04-camera-drives-audio.txt', label: 'video 04 camera drives audio', isVideo: true },
      { file: '25. video-05-audio-drives-video.txt', label: 'video 05 audio drives video', isVideo: true },
      { file: '26. video-06-bidirectional-loop.txt', label: 'video 06 bidirectional loop', isVideo: true },
      { file: '27. video-07-screen-capture-body.txt', label: 'video 07 screen capture body', isVideo: true },
      { file: '28. video-08-file-material.txt', label: 'video 08 file material', isVideo: true },
      { file: '29. video-09-multilayer-composite.txt', label: 'video 09 multilayer composite', isVideo: true },
      { file: '30. video-10-video-gen-basics.txt', label: 'video 10 video gen basics', isVideo: true },
      { file: '31. video-11-gen-to-stage-reuse.txt', label: 'video 11 gen to stage reuse', isVideo: true },
      { file: '32. video-12-performance-scene.txt', label: 'video 12 performance scene', isVideo: true },
    ] },
    { id: 'tuning', label: 'tuning', examples: [
      { file: '33. tuning-scopes-and-reference.txt', label: 'tuning scopes + reference' },
      { file: '34. tuning-performance-organism.txt', label: 'tuning performance organism' },
      { file: '35. pitch-span-glide.txt', label: 'pitch ramps' },
    ] },
    { id: 'piano', label: 'piano', examples: [
      { file: '36. iowa-piano-body.txt', label: '36. iowa piano body' },
      { file: '36c. piano-layer-xfade.txt', label: '36c. layer xfade (pp / mf / ff)' },
      { file: '36d. piano-body-resonance.txt', label: '36d. body resonance (sympathetic / lid)' },
      { file: '36e. piano-phasing.txt', label: '36e. phasing (Reich)' },
      { file: '36f. piano-groove.txt', label: '36f. groove (stacked channels)' },
      { file: '36g. piano-pitch-span-glide.txt', label: '36g. pitch-span glide' },
      { file: '36h. piano-études.txt', label: '36h. études — masterpiece' },
    ] },
    { id: 'violin', label: 'violin', examples: [
      { file: '40. iowa-violin-arco.txt', label: '40. iowa violin arco' },
      { file: '40b. violin-pizz.txt', label: '40b. pizzicato' },
      { file: '40c. violin-strings.txt', label: '40c. strings (sulG / D / A / E)' },
      { file: '40d. violin-vibrato.txt', label: '40d. vibrato + tremolo' },
      { file: '40e. violin-glide.txt', label: '40e. portamento' },
      { file: '40f. violin-body.txt', label: '40f. body + sympathetic' },
      { file: '40g. violin-double-stops.txt', label: '40g. double stops' },
      { file: '40h. violin-études.txt', label: '40h. études' },
    ] },
    { id: 'cello', label: 'cello', examples: [
      { file: '42a. cello-arco.txt', label: '42a. arco' },
      { file: '42b. cello-pizz.txt', label: '42b. pizzicato' },
      { file: '42c. cello-strings.txt', label: '42c. strings (sulC / G / D / A)' },
      { file: '42d. cello-double-stops.txt', label: '42d. double stops' },
      { file: '42e. cello-body.txt', label: '42e. body + sympathetic' },
      { file: '42f. cello-etudes.txt', label: '42f. études' },
    ] },
    { id: 'marimba', label: 'marimba', examples: [
      { file: '41a. marimba-first-bars.txt', label: '41a. first bars' },
      { file: '41b. marimba-resonance-and-damping.txt', label: '41b. resonance + damping' },
      { file: '41c. marimba-rolls.txt', label: '41c. rolls + four mallets' },
      { file: '41d. marimba-arrangement.txt', label: '41d. wooden machine arrangement' },
    ] },
    { id: 'vibraphone', label: 'vibraphone', examples: [
      { file: '43a. vibraphone-sustain.txt', label: '43a. sustain + pedal' },
      { file: '43b. vibraphone-pedal-and-damp.txt', label: '43b. pedal + damp' },
      { file: '43c. vibraphone-motor.txt', label: '43c. motor shimmer' },
      { file: '43d. vibraphone-bowed-bars.txt', label: '43d. bowed bars' },
      { file: '43e. vibraphone-chords.txt', label: '43e. chord shimmer' },
      { file: '43f. vibraphone-arrangement.txt', label: '43f. arrangement' },
    ] },
    { id: 'voice', label: 'voice / vox', examples: [
      { file: '45a. voice-vowels.txt', label: '45a. robot vowels' },
      { file: '45b. voice-breath-and-roughness.txt', label: '45b. carriers + roughness' },
      { file: '45c. voice-techniques.txt', label: '45c. robot states' },
      { file: '45d. voice-ensemble-chords.txt', label: '45d. vocoder + chords' },
      { file: '45e. voice-machine-choir.txt', label: '45e. machine choir' },
    ] },
    { id: 'drums', label: 'drums', examples: [
      { file: '2d. drum-kits.txt', label: '2d. drum kit grammar' },
      { file: '2d2. breakcore-beat.txt', label: '2d2. breakcore beat' },
      { file: '44a. smdrums-basic-kit.txt', label: '44a. rock kit map' },
      { file: '44b. smdrums-ride-time.txt', label: '44b. rock ride time' },
      { file: '44c. smdrums-variance.txt', label: '44c. variance as round robin' },
      { file: '44d. smdrums-fills.txt', label: '44d. fills + cymbal grammar' },
    ] },
  ];
    let activePatchBrowserTab = 'examples';
    let activeExampleCategoryId = EXAMPLE_CATEGORIES[0].id;
    let savedPatchDeleteArmedId = '';
    let savedPatchDeleteTimer = null;
    let savedPatchCopiedId = '';
    let savedPatchCopiedTimer = null;
    let currentExampleFile = '';
    let activeExampleFocusIndex = 0;
    let exampleSearchQuery = '';

    let activeCommandGroupId = 'actions';
    let activeCommandFocusIndex = 0;
    let commandSearchQuery = '';
    const commandBrowserState = {
      mode: 'commands',
      samplePath: [],
    };
    const commandSampleLibraryState = {
      libraries: null,
      loading: null,
      auditionBuffers: new Map(),
      auditionSource: null,
    };


  function visibleExampleCategories() {
    return EXAMPLE_CATEGORIES.filter((cat) => videoExamplesEnabled || !cat.isVideo);
  }

  function findExampleByFile(file) {
    if (!file) return null;
    for (const cat of EXAMPLE_CATEGORIES) {
      for (const ex of cat.examples) {
        if (ex.file === file) return { category: cat, example: ex };
      }
    }
    return null;
  }

    function escapeExampleHtml(s) {
      return String(s).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
      }[c]));
    }

    function exampleNumber(ex) {
      const file = String((ex && ex.file) || '');
      const label = String((ex && ex.label) || '');
      const m = file.match(/^([\dA-Za-z]+(?:[.-][\dA-Za-z]+)?)\./)
        || label.match(/^([\dA-Za-z]+(?:[.-][\dA-Za-z]+)?)[.)\s]/);
      return m ? m[1].toUpperCase() : '•';
    }

    function cleanExampleTitle(ex) {
      const label = String((ex && ex.label) || (ex && ex.file) || 'example')
        .replace(/\.txt$/i, '')
        .replace(/^[\dA-Za-z]+(?:[.-][\dA-Za-z]+)?[.)]?\s*/i, '')
        .replace(/\s+/g, ' ')
        .trim();

        return (label || 'example').toLowerCase();
    }

    function exampleAccentId(cat, ex) {
      const raw = [
        cat && cat.id,
        cat && cat.label,
        ex && ex.group,
        ex && ex.accent,
        ex && ex.label,
        ex && ex.file,
      ].join(' ').toLowerCase();

      if (raw.includes('marimba')) return 'marimba';
      if (raw.includes('vibraphone') || raw.includes('vibes')) return 'vibraphone';
      if (raw.includes('violin')) return 'violin';
      if (raw.includes('cello')) return 'cello';
      if (raw.includes('voice') || raw.includes('vox') || raw.includes('robot')) return 'voice';
      if (raw.includes('drum') || raw.includes('breakcore') || raw.includes('rock')) return 'drums';
      if (raw.includes('video') || raw.includes('camera') || raw.includes('screen')) return 'video';
      if (raw.includes('piano')) return 'piano';
      if (raw.includes('sample')) return 'samples';
      if (raw.includes('input') || raw.includes('mic') || raw.includes('tab')) return 'live-input';
      if (raw.includes('coupling') || raw.includes('weather') || raw.includes('quake') || raw.includes('tide')) return 'coupling';
      if (raw.includes('reference') || raw.includes('notation')) return 'reference';
      return String((cat && cat.id) || 'foundations').toLowerCase().replace(/[^a-z0-9_-]+/g, '-');
    }

    function exampleDetail(cat, ex) {
      if (ex && ex.detail) return String(ex.detail);

      const raw = `${(cat && cat.id) || ''} ${(ex && ex.file) || ''} ${(ex && ex.label) || ''}`.toLowerCase();

      if (raw.includes('marimba')) return 'mallets · resonance · struck body';
      if (raw.includes('vibraphone') || raw.includes('vibes')) return 'pedal · motor · metal shimmer';
      if (raw.includes('violin')) return 'bow state · strings · body';
      if (raw.includes('cello')) return 'low strings · bow state · body';
      if (raw.includes('piano')) return 'Iowa Steinway · pedal · sympathetic';
      if (raw.includes('voice') || raw.includes('robot')) return 'synthetic mouth · carrier · vocoder';
      if (raw.includes('drum') || raw.includes('breakcore') || raw.includes('rock')) return 'kit lanes · variance · one-shots';
      if (raw.includes('input') || raw.includes('mic') || raw.includes('tab')) return 'live source · modulation · routing';
      if (raw.includes('video') || raw.includes('camera') || raw.includes('screen')) return 'image source · feedback · stage';
      if (raw.includes('weather') || raw.includes('quake') || raw.includes('tide') || raw.includes('solar')) return 'attractor · coupling · environment';
      if (raw.includes('reference') || raw.includes('notation')) return 'syntax · grammar · surfaces';
      if (raw.includes('sample')) return 'archive · playback · scar';
      return 'score-grid patch · tutorial card';
    }

    function exampleMatchesQuery(cat, ex, query) {
      const q = String(query || '').trim().toLowerCase();
      if (!q) return true;

      const haystack = [
        cat && cat.id,
        cat && cat.label,
        ex && ex.file,
        ex && ex.label,
        ex && ex.detail,
        exampleDetail(cat, ex),
      ].join(' ').toLowerCase();

      return q.split(/\s+/).filter(Boolean).every((part) => haystack.includes(part));
    }

    function visibleExamplesForCategory(cat) {
      if (!cat) return [];
      return (cat.examples || []).filter((ex) => {
        if (!videoExamplesEnabled && ex && ex.isVideo) return false;
        return exampleMatchesQuery(cat, ex, exampleSearchQuery);
      });
    }

    function visibleExampleCategories() {
      return EXAMPLE_CATEGORIES
        .filter((cat) => videoExamplesEnabled || !cat.isVideo)
        .map((cat) => ({ ...cat, examples: visibleExamplesForCategory(cat) }))
        .filter((cat) => cat.examples.length > 0 || !exampleSearchQuery);
    }

    function totalVisibleExamples(cats) {
      return (cats || []).reduce((sum, cat) => sum + (cat.examples ? cat.examples.length : 0), 0);
    }

    function exampleItemButtons() {
      if (!examplePopoverList) return [];
      return Array.from(examplePopoverList.querySelectorAll('.example-popover-item'));
    }

    function focusExampleItem(index) {
      const items = exampleItemButtons();
      if (!items.length) return;

      const next = Math.max(0, Math.min(items.length - 1, Number(index) || 0));
      activeExampleFocusIndex = next;
      items[next].focus();
    }

    function moveExampleFocus(delta) {
      const items = exampleItemButtons();
      if (!items.length) return;

      const current = items.indexOf(document.activeElement);
      const base = current >= 0 ? current : activeExampleFocusIndex;
      const next = (base + delta + items.length) % items.length;
      focusExampleItem(next);
    }

    function safeSavedPatchId(seed) {
      const base = String(seed || '')
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '')
        .slice(0, 42);
      return base || `patch-${Date.now().toString(36)}`;
    }

    function readSavedPatches() {
      try {
        const raw = localStorage.getItem(SAVED_PATCHES_STORAGE_KEY);
        const list = JSON.parse(raw || '[]');
        if (!Array.isArray(list)) return [];
        return list
          .filter((item) => item && typeof item === 'object' && typeof item.code === 'string')
          .map((item) => ({
            id: String(item.id || safeSavedPatchId(item.title || item.hash || item.updatedAt)),
            title: normalizePatchTitle(item.title || 'Untitled Patch') || 'Untitled Patch',
            code: String(item.code || ''),
            hash: String(item.hash || ''),
            createdAt: Number(item.createdAt) || Date.now(),
            updatedAt: Number(item.updatedAt) || Number(item.createdAt) || Date.now(),
            lines: Number(item.lines) || String(item.code || '').split(/\r?\n/).filter((line) => line.trim()).length,
            voices: Array.isArray(item.voices) ? item.voices.slice(0, 8) : [],
            pinned: Boolean(item.pinned),
            tempo: String(item.tempo || '').slice(0, 24),
            meter: String(item.meter || '').slice(0, 24),
            preview: String(item.preview || savedPatchPreview(item.code || '')).slice(0, 220),
          }))
          .sort((a, b) => {
            const pinned = Number(Boolean(b.pinned)) - Number(Boolean(a.pinned));
            if (pinned) return pinned;
            return Number(b.updatedAt) - Number(a.updatedAt);
          })
          .slice(0, SAVED_PATCHES_MAX);
      } catch (_) {
        return [];
      }
    }

    function writeSavedPatches(list) {
      try {
        const sorted = (list || [])
          .filter((item) => item && typeof item === 'object')
          .sort((a, b) => {
            const pinned = Number(Boolean(b.pinned)) - Number(Boolean(a.pinned));
            if (pinned) return pinned;
            return Number(b.updatedAt) - Number(a.updatedAt);
          })
          .slice(0, SAVED_PATCHES_MAX);
        localStorage.setItem(SAVED_PATCHES_STORAGE_KEY, JSON.stringify(sorted));
      } catch (err) {
        console.warn('[repl] could not write saved patches:', err);
      }
    }

    function savedPatchTopDirectives(code) {
      const out = { tempo: '', meter: '' };
      for (const line of String(code || '').split(/\r?\n/)) {
        const clean = line.trim();
        if (!clean || clean.startsWith('//')) continue;
        const parts = clean.split(/\s+/);
        const head = String(parts[0] || '').toLowerCase();
        if (head === 'tempo' && !out.tempo) out.tempo = parts[1] || '';
        if (head === 'meter' && !out.meter) out.meter = parts[1] || '';
        if (out.tempo && out.meter) break;
      }
      return out;
    }

    function savedPatchPreview(code) {
      const lines = String(code || '')
        .split(/\r?\n/)
        .map((line) => line.trim())
        .filter((line) => line && !line.startsWith('//'));
      const directives = savedPatchTopDirectives(code);
      const body = lines.filter((line) => !/^(tempo|meter|eval|evaluate|tuning)\b/i.test(line));
      const parts = [];
      if (directives.tempo) parts.push(`tempo ${directives.tempo}`);
      if (directives.meter) parts.push(`meter ${directives.meter}`);
      parts.push(...body.slice(0, 2));
      return parts.join(' · ') || 'empty patch';
    }

    function savedPatchVoices(code) {
      const out = [];
      const seen = new Set();
      const voiceSet = new Set(Array.from(COMMAND_INSERT_VOICE_HEADS || []));
      for (const line of String(code || '').split(/\r?\n/)) {
        const head = String(line || '').trim().split(/\s+/, 1)[0].toLowerCase();
        if (!head || seen.has(head) || !voiceSet.has(head)) continue;
        seen.add(head);
        out.push(head);
      }
      return out;
    }

    function currentPatchHashValue() {
      try { return window.location.hash && window.location.hash.startsWith('#patch=v1.') ? window.location.hash : ''; }
      catch (_) { return ''; }
    }

    function upsertSavedPatchRecord(payload, hash) {
      const code = String(payload && payload.code || '');
      if (!code.trim()) return null;
      const title = normalizePatchTitle(payload && payload.title) || 'Untitled Patch';
      const patchHash = String(hash || currentPatchHashValue() || '');
      const now = Date.now();
      const list = readSavedPatches();
      const existingIndex = list.findIndex((item) => ((patchHash && item.hash === patchHash) || (item.code === code && item.title === title)));
      const previous = existingIndex >= 0 ? list[existingIndex] : null;
      const directives = savedPatchTopDirectives(code);
      const record = {
        id: previous ? previous.id : safeSavedPatchId(`${title}-${now.toString(36)}`),
        title,
        code,
        hash: patchHash,
        createdAt: previous ? previous.createdAt : now,
        updatedAt: now,
        pinned: previous ? Boolean(previous.pinned) : false,
        lines: code.split(/\r?\n/).filter((line) => line.trim()).length,
        voices: savedPatchVoices(code),
        tempo: directives.tempo,
        meter: directives.meter,
        preview: savedPatchPreview(code),
      };
      if (existingIndex >= 0) list.splice(existingIndex, 1);
      list.unshift(record);
      writeSavedPatches(list);
      return record;
    }

    function savedPatchRelativeTime(ts) {
      const delta = Math.max(0, Date.now() - (Number(ts) || 0));
      const minute = 60000;
      const hour = 60 * minute;
      const day = 24 * hour;
      if (delta < minute) return 'just now';
      if (delta < hour) return `${Math.floor(delta / minute)}m ago`;
      if (delta < day) return `${Math.floor(delta / hour)}h ago`;
      return `${Math.floor(delta / day)}d ago`;
    }

    function renderPatchBrowserTopTabs() {
      if (!patchBrowserTopTabs) return;
      const savedCount = readSavedPatches().length;
      const exampleCount = totalVisibleExamples(visibleExampleCategories());
      const tabs = [{ id: 'examples', label: 'examples', count: exampleCount }, { id: 'my-patches', label: 'my patches', count: savedCount }];
      patchBrowserTopTabs.innerHTML = '';
      for (const tab of tabs) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = ['patch-browser-top-tab', tab.id === activePatchBrowserTab ? 'is-active' : ''].filter(Boolean).join(' ');
        btn.setAttribute('role', 'tab');
        btn.setAttribute('aria-selected', tab.id === activePatchBrowserTab ? 'true' : 'false');
        btn.innerHTML = `<span class="patch-browser-top-tab-label">${escapeExampleHtml(tab.label)}</span><span class="patch-browser-top-tab-count">${escapeExampleHtml(String(tab.count))}</span>`;
        btn.addEventListener('click', () => { activePatchBrowserTab = tab.id; activeExampleFocusIndex = 0; renderExamplePopover(); });
        patchBrowserTopTabs.appendChild(btn);
      }
    }

    const PATCH_BROWSER_STARTER_RECIPES = {
      piano: {
        label: 'piano body',
        nouns: ['resonant body', 'prepared room', 'pedal field', 'hammer trace'],
        make: () => {
          const chord = choosePatchStarterValue([
            'C3 E3 G3 C4',
            'A2 E3 C4 E4',
            'D3 A3 C4 F4',
            'G2 D3 B3 E4',
          ]);
          const pedal = choosePatchStarterValue(['0 0 0.75 0', '0 0.65 0 1', '1 1 0 0']);
          const gain = choosePatchStarterValue(['0.72', '0.78', '0.64', '0.86']);
          return `piano ${chord}\npedal ${pedal}\ngain ${gain}`;
        },
      },
      bk: {
        label: 'bk fragment',
        nouns: ['bk fragment', 'cut cell', 'break shard', 'sample scar'],
        make: () => {
          const sample = choosePatchStarterValue(['bk-01', 'bk-03', 'bk-07', 'bk-10']);
          const gain = choosePatchStarterValue(['0.72', '0.8', '0.68']);
          const pan = choosePatchStarterValue(['center', 'left . right', '. center . left']);
          return `sample ${sample}\ngain ${gain}\npan ${pan}`;
        },
      },
      string: {
        label: 'string drone',
        nouns: ['string drone', 'body tone', 'slow string', 'pressure field'],
        make: () => {
          const line = choosePatchStarterValue(['C3 . G3 .', 'A2 ~ E3 .', 'D3 . A3 ~', 'G2 . D3 .']);
          const force = choosePatchStarterValue(['mf mp p pp', 'p mp mf f', 'mp mf f ff']);
          const space = choosePatchStarterValue(['0.28', '0.34', '0.22']);
          return `string ${line}\nforce ${force}\nspace ${space}`;
        },
      },
    };

    function choosePatchStarterValue(list) {
      const values = Array.isArray(list) ? list : [];
      if (!values.length) return '';
      return values[Math.floor(Math.random() * values.length) % values.length];
    }

    function makePatchBrowserStarter(kind) {
      const recipe = PATCH_BROWSER_STARTER_RECIPES[kind] || PATCH_BROWSER_STARTER_RECIPES.piano;
      const noun = choosePatchStarterValue(recipe.nouns) || recipe.label;
      return {
        kind,
        label: recipe.label,
        noun,
        code: recipe.make(),
      };
    }

    function sanitizePatchBrowserStarterCode(starter) {
      const kind = String(starter && starter.kind || '').toLowerCase();
      const lines = String(starter && starter.code || '')
        .replace(/\r\n?/g, '\n')
        .split('\n')
        .map((line) => line.trim())
        .filter(Boolean);

      const sanitized = lines.map((line) => {
        const parts = line.split(/\s+/);
        const head = String(parts[0] || '').toLowerCase();

        if (head === 'pedal') {
          const values = parts.slice(1).map((token) => {
            const raw = String(token || '').trim();
            const lower = raw.toLowerCase();
            if (raw === '.' || raw === '~' || raw === '_' || raw === '*') return '0';
            if (lower === 'on') return 'on';
            if (lower === 'off') return 'off';
            if (lower === 'down') return '1';
            if (lower === 'up') return '0';
            if (lower === 'half') return '0.5';
            const n = Number(raw);
            if (Number.isFinite(n)) return String(Math.max(0, Math.min(1, n)));
            return '0';
          });
          return `pedal ${values.length ? values.join(' ') : '0'}`;
        }

        if (head === 'force') {
          const legalDynamics = new Set(['pp', 'p', 'mp', 'mf', 'f', 'ff', 'fff', 'random']);
          const values = parts.slice(1).map((token) => {
            const raw = String(token || '').trim();
            const lower = raw.toLowerCase();
            if (raw === '.' || raw === '~' || raw === '_' || raw === '*') return 'mf';
            if (legalDynamics.has(lower)) return lower;
            const n = Number(raw);
            if (Number.isFinite(n)) return String(Math.max(0, Math.min(1, n)));
            return 'mf';
          });
          return `force ${values.length ? values.join(' ') : 'mf'}`;
        }

        return line;
      });

      if (kind === 'piano' && !sanitized.some((line) => /^pedal\b/i.test(line))) {
        sanitized.push('pedal 0 0 0.75 0');
      }

      return sanitized.join('\n');
    }

    function validatePatchBrowserStarterPatch(patch) {
      if (!String(patch || '').trim()) return false;
      if (!window.ReplDSL || typeof window.ReplDSL.parse !== 'function') return true;
      try {
        const parsed = window.ReplDSL.parse(patch);
        return Boolean(parsed && parsed.ok);
      } catch (_) {
        return false;
      }
    }

    function fallbackPatchBrowserStarterScaffold(starter) {
      const kind = String(starter && starter.kind || '').toLowerCase();
      const title = normalizePatchTitle(starter && starter.noun ? starter.noun : starter && starter.label) || 'starter block';
      const needsTuning = kind === 'piano' || kind === 'string';
      const block = kind === 'bk'
        ? 'sample bk-01\ngain 0.8\npan center'
        : kind === 'string'
          ? 'string C3 . G3 .\nforce mf mp p pp\nspace 0.28'
          : 'piano C3 E3 G3 C4\npedal 0 0 0.75 0\ngain 0.78';
      const header = [
        `// title: ${title}`,
        '',
        'tempo 110',
        'meter 4/4',
      ];
      if (needsTuning) header.push('tuning 12-henricus-grammateus');
      return `${header.join('\n')}\n\n${block}\n`;
    }

    function patchBrowserStarterScaffold(starter) {
      const code = sanitizePatchBrowserStarterCode(starter).trim();
      if (!code) return '';
      const needsTuning = starter && (starter.kind === 'piano' || starter.kind === 'string');
      const title = normalizePatchTitle(starter && starter.noun ? starter.noun : starter && starter.label) || 'Starter Block';
      const header = [
        `// title: ${title}`,
        '',
        'tempo 110',
        'meter 4/4',
      ];
      if (needsTuning) header.push('tuning 12-henricus-grammateus');
      const patch = `${header.join('\n')}\n\n${code}\n`;
      return validatePatchBrowserStarterPatch(patch) ? patch : fallbackPatchBrowserStarterScaffold(starter);
    }

    function addPatchBrowserStarterBlock(starter) {
      if (!starter || !starter.code || !editorAPI) return;
      const patch = patchBrowserStarterScaffold(starter);
      if (!patch) return;

      stop();
      loadedExampleLabel = '';
      currentExampleFile = '';
      lastGoodProgram = null;
      lastEvaluatedText = '';
      lastParseErrorText = '';
      lastRuntimeErrorText = '';
      lastEditorMuteSnapshotKey = '';
      if (blockMuteOverridesBySignature && typeof blockMuteOverridesBySignature.clear === 'function') {
        blockMuteOverridesBySignature.clear();
      }

      editorAPI.setValue(patch);
      patchLinkState.applyingRemotePatch = false;
      patchLinkState.lastSavedCode = '';
      patchLinkState.lastSavedTitle = '';
      window.clearTimeout(patchLinkState.writeTimer);
      patchLinkState.writeTimer = null;
      clearPatchHashIfNeeded();
      clearErrors();
      if (exampleCurrentLabel) exampleCurrentLabel.textContent = 'examples / saved';
      refreshPatchTitle();
      syncEditorBlockMuteLines();
      setStatusLine();
      closeExamplePopover();
      editorAPI.focus();
    }

    function openPatchBrowserTutorials() {
      activePatchBrowserTab = 'examples';
      activeExampleCategoryId = 'foundations';
      activeExampleFocusIndex = 0;
      if (examplePopoverSearch) {
        examplePopoverSearch.value = '';
        exampleSearchQuery = '';
      }
      renderExamplePopover();
      window.requestAnimationFrame(() => {
        const first = examplePopoverList && examplePopoverList.querySelector('.example-popover-item');
        if (first && typeof first.focus === 'function') first.focus();
      });
    }

    function renderSavedPatchEmptyState() {
      if (!examplePopoverList) return;
      const primary = makePatchBrowserStarter(choosePatchStarterValue(['piano', 'bk', 'string']));
      const alternates = ['piano', 'bk', 'string']
        .filter((kind) => kind !== primary.kind)
        .map((kind) => makePatchBrowserStarter(kind));
      const shell = document.createElement('div');
      shell.className = 'patch-browser-empty';
      shell.innerHTML = [
        '<div class="patch-browser-empty-glyph" aria-hidden="true">⟦ . ⟧</div>',
        '<div>',
        '<p class="patch-browser-empty-copy">you do not have anything saved yet. start with a tutorial, or skip ahead with a generated block.</p>',
        '<div class="patch-browser-empty-route">',
        '<button type="button" class="patch-browser-tutorial-button" data-patch-tutorials>open tutorials</button>',
        '</div>',
        '<span class="patch-browser-empty-route-note">power user skip:</span>',
        `<pre class="patch-browser-empty-code" aria-label="generated starter patch preview">${escapeExampleHtml(patchBrowserStarterScaffold(primary))}</pre>`,
        '<div class="patch-browser-starter-grid"></div>',
        '</div>',
      ].join('');
      const tutorialButton = shell.querySelector('[data-patch-tutorials]');
      if (tutorialButton) tutorialButton.addEventListener('click', openPatchBrowserTutorials);
      const grid = shell.querySelector('.patch-browser-starter-grid');
      const starters = [primary].concat(alternates);
      starters.forEach((starter, index) => {
        const item = document.createElement('span');
        item.className = 'patch-browser-starter';
        const label = index === 0 ? `add ${starter.noun}` : starter.label;
        item.innerHTML = `<button type="button" title="${escapeExampleHtml(patchBrowserStarterScaffold(starter))}">${escapeExampleHtml(label)}</button>`;
        item.querySelector('button').addEventListener('click', () => addPatchBrowserStarterBlock(starter));
        grid.appendChild(item);
      });
      examplePopoverList.appendChild(shell);
    }

    function savedPatchUrl(record) {
      const hash = String(record && record.hash || '');
      if (!hash) return '';
      try { return `${window.location.origin}${window.location.pathname}${window.location.search}${hash}`; }
      catch (_) { return hash; }
    }

    function openSavedPatch(record) {
      if (!record || !editorAPI) return;
      loadedExampleLabel = '';
      currentExampleFile = '';
      editorAPI.setValue(String(record.code || ''));
      if (record.hash && record.hash.startsWith('#patch=v1.')) {
        try { history.pushState(null, '', `${window.location.pathname}${window.location.search}${record.hash}`); } catch (_) {}
      }
      patchLinkState.lastSavedCode = String(record.code || '');
      patchLinkState.lastSavedTitle = normalizePatchTitle(record.title || '');
      if (exampleCurrentLabel) exampleCurrentLabel.textContent = 'saved';
      activePatchBrowserTab = 'my-patches';
      refreshPatchTitle();
      closeExamplePopover();
      editorAPI.focus();
    }

    async function copySavedPatchUrl(record) {
      const url = savedPatchUrl(record);
      if (!url) { showWarning('saved patch has no hash URL yet'); setTimeout(clearErrors, 2200); return; }
      try {
        await navigator.clipboard.writeText(url);
        savedPatchCopiedId = record.id;
        window.clearTimeout(savedPatchCopiedTimer);
        savedPatchCopiedTimer = window.setTimeout(() => {
          savedPatchCopiedId = '';
          if (examplePopover && !examplePopover.hidden) renderExamplePopover();
        }, 1500);
        if (examplePopover && !examplePopover.hidden) renderExamplePopover();
        showWarning('saved patch URL copied');
      }
      catch (_) { showWarning('clipboard unavailable — open patch and use share'); }
      setTimeout(clearErrors, 2200);
    }

    function toggleSavedPatchPinned(record) {
      if (!record) return;
      const list = readSavedPatches();
      const item = list.find((patch) => patch.id === record.id);
      if (!item) return;
      item.pinned = !Boolean(item.pinned);
      item.updatedAt = Date.now();
      writeSavedPatches(list);
      renderExamplePopover();
    }

    function exportSavedPatchLibrary() {
      const payload = {
        app: 'seb-repl',
        kind: 'saved-patches',
        version: 1,
        exportedAt: new Date().toISOString(),
        patches: readSavedPatches(),
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'seb-repl-patches.json';
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    }

    function mergeImportedSavedPatches(incoming) {
      const current = readSavedPatches();
      const byKey = new Map();
      for (const item of current) {
        byKey.set(item.id || item.hash, item);
        if (item.hash) byKey.set(item.hash, item);
      }
      let imported = 0;
      for (const raw of incoming || []) {
        if (!raw || typeof raw !== 'object' || typeof raw.code !== 'string' || !raw.code.trim()) continue;
        const title = normalizePatchTitle(raw.title || 'Untitled Patch') || 'Untitled Patch';
        const directives = savedPatchTopDirectives(raw.code);
        const id = String(raw.id || safeSavedPatchId(`${title}-${raw.updatedAt || Date.now()}`));
        const candidate = {
          id,
          title,
          code: String(raw.code || ''),
          hash: String(raw.hash || ''),
          createdAt: Number(raw.createdAt) || Date.now(),
          updatedAt: Number(raw.updatedAt) || Date.now(),
          pinned: Boolean(raw.pinned),
          lines: String(raw.code || '').split(/\r?\n/).filter((line) => line.trim()).length,
          voices: savedPatchVoices(raw.code),
          tempo: directives.tempo,
          meter: directives.meter,
          preview: savedPatchPreview(raw.code),
        };
        const existing = byKey.get(candidate.hash) || byKey.get(candidate.id);
        if (!existing) {
          current.push(candidate);
          imported += 1;
          continue;
        }
        if (Number(candidate.updatedAt) > Number(existing.updatedAt)) {
          Object.assign(existing, candidate, { pinned: Boolean(existing.pinned || candidate.pinned) });
          imported += 1;
        }
      }
      writeSavedPatches(current);
      return imported;
    }

    function importSavedPatchLibrary() {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'application/json,.json';
      input.addEventListener('change', async () => {
        const file = input.files && input.files[0];
        if (!file) return;
        try {
          const text = await file.text();
          const data = JSON.parse(text);
          const patches = Array.isArray(data) ? data : (Array.isArray(data.patches) ? data.patches : []);
          const count = mergeImportedSavedPatches(patches);
          renderExamplePopover();
          showWarning(count ? `imported ${count} saved patch${count === 1 ? '' : 'es'}` : 'no newer saved patches found');
        } catch (err) {
          console.warn('[repl] patch library import failed:', err);
          showWarning('patch library import failed');
        }
        setTimeout(clearErrors, 2600);
      });
      input.click();
    }

    function deleteSavedPatch(record) {
      if (!record) return;
      if (savedPatchDeleteArmedId !== record.id) {
        savedPatchDeleteArmedId = record.id;
        window.clearTimeout(savedPatchDeleteTimer);
        savedPatchDeleteTimer = window.setTimeout(() => { savedPatchDeleteArmedId = ''; if (examplePopover && !examplePopover.hidden) renderExamplePopover(); }, 2200);
        renderExamplePopover();
        return;
      }
      savedPatchDeleteArmedId = '';
      window.clearTimeout(savedPatchDeleteTimer);
      writeSavedPatches(readSavedPatches().filter((item) => item.id !== record.id));
      renderExamplePopover();
    }

    function renderSavedPatchLibraryBar(count) {
      const bar = document.createElement('div');
      bar.className = 'saved-patch-library-bar';
      bar.innerHTML = [
        `<span class="saved-patch-library-title">my patches / ${escapeExampleHtml(String(count))}</span>`,
        '<span class="saved-patch-library-tools">',
        '<button type="button" data-action="import">import</button>',
        '<button type="button" data-action="export">export</button>',
        '</span>',
      ].join('');
      bar.querySelector('[data-action="import"]').addEventListener('click', importSavedPatchLibrary);
      bar.querySelector('[data-action="export"]').addEventListener('click', exportSavedPatchLibrary);
      return bar;
    }

    function renderSavedPatchBrowser() {
      if (!examplePopoverTabs || !examplePopoverList) return;
      const query = String(exampleSearchQuery || '').trim().toLowerCase();
      let patches = readSavedPatches();
      if (query) {
        patches = patches.filter((item) => [
          item.title,
          item.preview,
          item.tempo,
          item.meter,
          (item.voices || []).join(' '),
        ].join(' ').toLowerCase().includes(query));
      }
      if (examplePopoverCount) examplePopoverCount.textContent = `${patches.length} SAVED`;
      examplePopoverTabs.innerHTML = '<div class="example-popover-section-label example-accent-samples">local hash library</div>';
      examplePopoverList.innerHTML = '';
      examplePopoverList.appendChild(renderSavedPatchLibraryBar(patches.length));
      if (!patches.length) { renderSavedPatchEmptyState(); return; }
      patches.forEach((record) => {
        const card = document.createElement('div');
        card.className = ['saved-patch-card', record.pinned ? 'is-pinned' : ''].filter(Boolean).join(' ');
        const voices = record.voices && record.voices.length ? record.voices.slice(0, 4).join(' + ') : 'no voices yet';
        const meter = record.meter ? ` · ${record.meter}` : '';
        const tempo = record.tempo ? `tempo ${record.tempo}` : 'tempo ?';
        const copied = savedPatchCopiedId === record.id;
        card.innerHTML = [
          `<button type="button" class="saved-patch-pin" aria-pressed="${record.pinned ? 'true' : 'false'}" title="${record.pinned ? 'unpin patch' : 'pin patch'}">${record.pinned ? '★' : '☆'}</button>`,
          `<button type="button" class="saved-patch-open"><span class="saved-patch-title">PATCH / ${escapeExampleHtml(record.title)}</span><span class="saved-patch-meta">${escapeExampleHtml(`${savedPatchRelativeTime(record.updatedAt)} · ${record.lines || 0} lines · ${voices}`)}</span><span class="saved-patch-preview">${escapeExampleHtml(`${tempo}${meter} · ${record.preview || 'saved patch'}`)}</span></button>`,
          '<span class="saved-patch-actions">',
          '<button type="button" data-action="open">open</button>',
          `<button type="button" data-action="copy"${copied ? ' data-copy-done="1"' : ''}>${copied ? 'copied' : 'copy url'}</button>`,
          `<button type="button" data-action="delete"${savedPatchDeleteArmedId === record.id ? ' data-delete-armed="1"' : ''}>${savedPatchDeleteArmedId === record.id ? 'delete?' : 'delete'}</button>`,
          '</span>',
        ].join('');
        card.querySelector('.saved-patch-open').addEventListener('click', () => openSavedPatch(record));
        card.querySelector('.saved-patch-pin').addEventListener('click', () => toggleSavedPatchPinned(record));
        card.querySelector('[data-action="open"]').addEventListener('click', () => openSavedPatch(record));
        card.querySelector('[data-action="copy"]').addEventListener('click', () => copySavedPatchUrl(record));
        card.querySelector('[data-action="delete"]').addEventListener('click', () => deleteSavedPatch(record));
        examplePopoverList.appendChild(card);
      });
    }

    function renderExamplePopover() {
      if (!examplePopoverTabs || !examplePopoverList) return;

      renderPatchBrowserTopTabs();
      if (activePatchBrowserTab === 'my-patches') {
        renderSavedPatchBrowser();
        return;
      }

      const cats = visibleExampleCategories();
      const count = totalVisibleExamples(cats);

      if (examplePopoverCount) {
        examplePopoverCount.textContent = `${count} PATCH${count === 1 ? '' : 'ES'}`;
      }

      if (!cats.length) {
        examplePopoverTabs.innerHTML = '';
        examplePopoverList.innerHTML = '<div class="example-popover-empty">No score cards match this filter.</div>';
        return;
      }

      if (!cats.some((c) => c.id === activeExampleCategoryId)) {
        activeExampleCategoryId = cats[0].id;
        activeExampleFocusIndex = 0;
      }

      examplePopoverTabs.innerHTML = '';

      for (const cat of cats) {
        const accent = exampleAccentId(cat, null);
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = [
          'example-popover-tab',
          `example-accent-${accent}`,
          cat.id === activeExampleCategoryId ? 'is-active' : '',
        ].filter(Boolean).join(' ');
        btn.setAttribute('role', 'tab');
        btn.setAttribute('aria-selected', cat.id === activeExampleCategoryId ? 'true' : 'false');
        btn.innerHTML = [
          '<span class="example-popover-tab-main">',
          escapeExampleHtml(cat.label || cat.id),
          '</span>',
          '<span class="example-popover-tab-count">',
          escapeExampleHtml(cat.examples.length),
          '</span>',
        ].join('');

        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          activeExampleCategoryId = cat.id;
          activeExampleFocusIndex = 0;
          renderExamplePopover();
          requestAnimationFrame(positionExamplePopover);
        });

        btn.addEventListener('keydown', (e) => {
          const tabs = Array.from(examplePopoverTabs.querySelectorAll('.example-popover-tab'));
          const idx = tabs.indexOf(document.activeElement);

          if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
            e.preventDefault();
            const next = tabs[(idx + 1 + tabs.length) % tabs.length];
            if (next) next.focus();
          }

          if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
            e.preventDefault();
            const next = tabs[(idx - 1 + tabs.length) % tabs.length];
            if (next) next.focus();
          }

          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            btn.click();
          }
        });

        examplePopoverTabs.appendChild(btn);
      }

      examplePopoverList.innerHTML = '';

      const active = cats.find((c) => c.id === activeExampleCategoryId);
      if (!active) return;

      const section = document.createElement('div');
      section.className = `example-popover-section-label example-accent-${exampleAccentId(active, null)}`;
      section.textContent = active.label || active.id;
      examplePopoverList.appendChild(section);

      active.examples.forEach((ex, idx) => {
        const accent = exampleAccentId(active, ex);
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = [
          'example-popover-item',
          `example-accent-${accent}`,
          ex.file === currentExampleFile ? 'is-current' : '',
        ].filter(Boolean).join(' ');
        btn.dataset.exampleFile = ex.file;
        btn.dataset.exampleIndex = String(idx);

        if (ex.isVideo) btn.dataset.video = '1';
        if (ex.file === currentExampleFile) btn.setAttribute('aria-current', 'true');

        btn.innerHTML = [
          '<span class="example-popover-num">',
          escapeExampleHtml(exampleNumber(ex)),
          '</span>',
          '<span class="example-popover-copy">',
          '<span class="example-popover-label">',
          escapeExampleHtml(cleanExampleTitle(ex)),
          '</span>',
          '<span class="example-popover-detail">',
          escapeExampleHtml(exampleDetail(active, ex)),
          '</span>',
          '</span>',
          '<span class="example-popover-stamp" aria-hidden="true"></span>',
        ].join('');

        btn.addEventListener('click', () => {
          activeExampleFocusIndex = idx;
          void loadExampleByFile(ex.file);
          closeExamplePopover();
        });

        btn.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            moveExampleFocus(1);
          }

          if (e.key === 'ArrowUp') {
            e.preventDefault();
            moveExampleFocus(-1);
          }

          if (e.key === 'Home') {
            e.preventDefault();
            focusExampleItem(0);
          }

          if (e.key === 'End') {
            e.preventDefault();
            focusExampleItem(exampleItemButtons().length - 1);
          }

          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            btn.click();
          }
        });

        examplePopoverList.appendChild(btn);
      });

      const items = exampleItemButtons();
      if (items.length) {
        const currentIndex = items.findIndex((item) => item.dataset.exampleFile === currentExampleFile);
        activeExampleFocusIndex = currentIndex >= 0 ? currentIndex : Math.min(activeExampleFocusIndex, items.length - 1);
      }
    }

    function positionExamplePopover() {
      // Centered modal is positioned entirely by CSS.
      // Kept as a no-op because open/render/resize code already calls it.
    }

    function openExamplePopover() {
      if (!examplePopover || !exampleTrigger) return;

      if (currentExampleFile) activePatchBrowserTab = 'examples';
      else if (readSavedPatches().length > 0) activePatchBrowserTab = 'my-patches';

      if (currentExampleFile) {
        const found = findExampleByFile(currentExampleFile);
        if (found && visibleExampleCategories().some((c) => c.id === found.category.id)) {
          activeExampleCategoryId = found.category.id;
        }
      }

      if (examplePopoverSearch) {
        exampleSearchQuery = examplePopoverSearch.value || '';
      }

        renderExamplePopover();

        examplePopover.style.left = '';
        examplePopover.style.top = '';
        examplePopover.hidden = false;
        document.body.classList.add('example-popover-open');
        exampleTrigger.setAttribute('aria-expanded', 'true');

        requestAnimationFrame(() => {
          const current = examplePopoverList && examplePopoverList.querySelector('.example-popover-item.is-current');
          if (current) {
            current.scrollIntoView({ block: 'nearest' });
          }

          if (examplePopoverSearch) {
            examplePopoverSearch.focus();
            examplePopoverSearch.select();
          }
        });
    }

    function closeExamplePopover() {
      if (!examplePopover || !exampleTrigger) return;
        examplePopover.hidden = true;
        document.body.classList.remove('example-popover-open');
        exampleTrigger.setAttribute('aria-expanded', 'false');
    }

  function toggleExamplePopover() {
    if (!examplePopover) return;
    if (examplePopover.hidden) openExamplePopover();
    else closeExamplePopover();
  }

  function exampleHashSlug(file) {
    return String(file || '').replace(/\.txt$/i, '');
  }

  function writeExampleHash(file) {
    if (!file) return;
    try {
      const target = '#example=' + encodeURIComponent(exampleHashSlug(file));
      if (window.location.hash !== target) {
        history.replaceState(null, '', target);
      }
    } catch (_) {}
  }

  function readExampleHash() {
    const h = (window.location.hash || '').replace(/^#/, '');
    if (!h.startsWith('example=')) return '';
    let decoded = '';
    try { decoded = decodeURIComponent(h.slice('example='.length)); } catch (_) { return ''; }
    if (!decoded) return '';
    const candidates = [decoded, decoded + '.txt'];
    for (const cand of candidates) {
      if (findExampleByFile(cand)) return cand.endsWith('.txt') ? cand : cand + '.txt';
    }
    return '';
  }

  async function loadExampleByFile(file) {
    if (!file) return;
    const found = findExampleByFile(file);
    if (found && found.example.isVideo && !videoExamplesEnabled) return;
    try {
      const r = await fetch('./examples/' + file);
        if (r.ok) {
          const text = await r.text();
          const label = found ? found.example.label : file.replace(/\.txt$/i, '');
          loadedExampleLabel = label;
          currentExampleFile = file;

          if (found && found.category) activeExampleCategoryId = found.category.id;
          if (exampleCurrentLabel) exampleCurrentLabel.textContent = 'examples / saved';
          if (editorAPI) editorAPI.setValue(text);

          refreshPatchTitle();
          writeExampleHash(file);

          patchLinkState.lastSavedCode = editorAPI ? editorAPI.getValue() : '';
          patchLinkState.lastSavedTitle = getPatchTitleForShare();
          refreshPatchTitle();

          if (examplePopover && !examplePopover.hidden) {
            renderExamplePopover();
          }
        }
    } catch (err) {
      console.warn('[repl] failed to load example:', file, err);
      showWarning(`couldn't load example: ${file}`);
    }
      if (editorAPI) editorAPI.focus();
  }

    if (exampleTrigger && examplePopover) {
      exampleTrigger.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleExamplePopover();
      });

      exampleTrigger.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openExamplePopover();

          requestAnimationFrame(() => {
            if (examplePopoverSearch) examplePopoverSearch.focus();
            else focusExampleItem(activeExampleFocusIndex);
          });
        }
      });

      if (examplePopoverSearch) {
        examplePopoverSearch.addEventListener('click', (e) => {
          e.stopPropagation();
        });

        examplePopoverSearch.addEventListener('input', () => {
          exampleSearchQuery = examplePopoverSearch.value || '';
          activeExampleFocusIndex = 0;
          renderExamplePopover();
          requestAnimationFrame(positionExamplePopover);
        });

        examplePopoverSearch.addEventListener('keydown', (e) => {
          if (e.key === 'Escape') {
            e.preventDefault();
            closeExamplePopover();
            exampleTrigger.focus();
          }

          if (e.key === 'ArrowDown') {
            e.preventDefault();
            focusExampleItem(0);
          }

          if (e.key === 'Enter') {
            const first = exampleItemButtons()[0];
            if (first) {
              e.preventDefault();
              first.click();
            }
          }
        });
      }

      examplePopover.addEventListener('click', (e) => {
        e.stopPropagation();
      });

      document.addEventListener('click', (e) => {
        if (examplePopover.hidden) return;
        if (examplePopover.contains(e.target)) return;
        if (exampleTrigger.contains(e.target)) return;
        closeExamplePopover();
      });

      document.addEventListener('keydown', (e) => {
        if (examplePopover.hidden) return;

        if (e.key === 'Escape') {
          e.preventDefault();
          closeExamplePopover();
          exampleTrigger.focus();
        }

        if (e.key === 'ArrowDown' && document.activeElement === exampleTrigger) {
          e.preventDefault();
          focusExampleItem(activeExampleFocusIndex);
        }
      });

      window.addEventListener('resize', () => {
        if (!examplePopover.hidden) positionExamplePopover();
      });

      window.addEventListener('hashchange', () => {
        const file = readExampleHash();
        if (file && file !== currentExampleFile) void loadExampleByFile(file);
      });
    }

    // ---------------- transport / coupling visualizer ----------------

    // Cached DOM structure: rebuilt only when the program changes, then updated
    // every frame from scheduler.now().
    let blockRowEls = []; // [ { row, slotEls, everyEl, couplingEl, surfacesEl } per block ]
    let beatDotEls = [];
    let couplingSummaryEls = null;

    const SIGNAL_META = {
      I: {
        key: 'intensity',
        name: 'intensity',
        summary: 'overall signal strength / amplitude pressure',
        detail: 'How strong the current source is. Usually tracks amplitude, confidence, or signal presence.',
        use: 'higher I = louder, more present, more forceful',
        modulates: ['gain', 'compress', 'trigger', 'space'],
      },
      V: {
        key: 'volatility',
        name: 'volatility',
        summary: 'instability, flux, and rate of change',
        detail: 'How unstable or fast-changing the source is. Often derived from flux, motion, or sudden parameter change.',
        use: 'higher V = more drift, jitter, mutation, spatial instability',
        modulates: ['pan', 'blur', 'grain', 'rate', 'leaf'],
      },
      P: {
        key: 'pressure',
        name: 'pressure',
        summary: 'force applied by the source to the patch',
        detail: 'How much force the source applies to the patch. Useful for density, compression, and body behavior.',
        use: 'higher P = heavier behavior, more compression, stronger body/color',
        modulates: ['force', 'body', 'compress', 'filter', 'crush'],
      },
      D: {
        key: 'density',
        name: 'density',
        summary: 'activity concentration and event crowding',
        detail: 'How active or crowded the source is over time. Usually related to onset rate, activity, or event concentration.',
        use: 'higher D = more events, tighter spacing, denser sample behavior',
        modulates: ['beat', 'time', 'grain', 'trigger', 'sample'],
      },
      T: {
        key: 'periodicity',
        name: 'tension',
        summary: 'distance from rest; harmonic or behavioral strain',
        detail: 'How far the source is from rest. A composite signal for instability, brightness, pressure, or unresolved motion.',
        use: 'higher T = more edge, stretch, harmonic strain, or unresolved energy',
        modulates: ['pitch', 'tone', 'filter', 'resonance', 'decay'],
      },
      R: {
        key: 'rupture',
        name: 'rupture',
        summary: 'attacks, transients, breaks, and discontinuities',
        detail: 'How sharply the source breaks continuity. Usually tracks transients, attacks, spikes, or discontinuities.',
        use: 'higher R = attacks, cuts, scars, re-articulations',
        modulates: ['trigger', 'scar', 'leaf', 'start', 'reset'],
      },
    };



    const SURFACE_META = {
      speed: {
        name: 'speed',
        summary: 'pattern-time multiplier / temporal pressure',
        detail: 'Changes how quickly a block consumes its score material. When coupled, speed becomes the surface where signal motion can bend musical time.',
        use: 'higher drive = faster bodies, warped pacing, or drifted clock behavior',
        audio: 'Pattern-time cursor speed; not sample playback rate.',
        range: 'number or ratio, typically 0.0625–16; default 1',
        examples: ['speed 1/2', 'speed 2', 'speed *'],
        drivenBy: ['volatility', 'density', 'rupture'],
      },
      pan: {
        name: 'pan',
        summary: 'left-right position / spatial lateral motion',
        detail: 'Moves material across the stereo field. It is the simplest surface for drift, jitter, and attractor steering.',
        use: 'higher drive = more lateral motion, instability, or spatial displacement',
        audio: 'Stereo pan before block output/effects.',
        range: 'left/center/right or -1..1; default center',
        examples: ['pan left', 'pan -0.4', 'pan *~'],
        drivenBy: ['volatility', 'intensity', 'pressure'],
      },
      gain: {
        name: 'gain',
        summary: 'level / amplitude opening',
        detail: 'Controls how present a block is in the mix. It is usually the first surface touched by intensity and confidence.',
        use: 'higher drive = louder, closer, more exposed material',
        audio: 'Event amplitude scalar before shared output.',
        range: 'quiet/half/full/loud or 0..1.5; default 1',
        examples: ['gain quiet', 'gain 0.45', 'gain mic.intensity 0 1'],
        drivenBy: ['intensity', 'pressure'],
      },
      force: {
        name: 'force',
        summary: 'gesture weight / physical push',
        detail: 'Applies body-like pressure to synthesis and coupled behavior. Useful when a source should push the patch instead of merely modulating it.',
        use: 'higher drive = heavier articulation, stronger impact, more push',
        audio: 'Attack/excitation weight for synth and percussive voices.',
        range: 'pp p mp mf f ff fff or 0..1; default mf-ish',
        examples: ['force mf', 'force 0.8', 'force quake.rupture 0.2 1'],
        drivenBy: ['pressure', 'intensity', 'rupture'],
      },
      compress: {
        name: 'compress',
        summary: 'dynamic regulation / signal clamp',
        detail: 'Turns incoming pressure into compression behavior. It can make the system feel held down, squeezed, or mechanically governed.',
        use: 'higher drive = more grip, flattening, density, or pressure-control',
        drivenBy: ['pressure', 'density', 'intensity'],
      },
      space: {
        name: 'space',
        summary: 'room send / spatial bloom',
        detail: 'Opens reverberant space around the block. Coupling this surface lets the environment expand, contract, or smear around the source.',
        use: 'higher drive = wider room, longer tail, more atmospheric spread',
        audio: 'Block wet send into delay/reverb-like space.',
        range: '0..1 or modes memory/weather/room/horizon',
        examples: ['space 0.25', 'space room', 'space *~'],
        drivenBy: ['intensity', 'tension', 'volatility'],
      },
      body: {
        name: 'body',
        summary: 'resonant mass / embodied color',
        detail: 'Adds mass, chamber, or object-like coloration. It makes a signal feel housed inside something physical.',
        use: 'higher drive = thicker resonance, stronger object-color, heavier body',
        drivenBy: ['pressure', 'intensity', 'tension'],
      },
      pitch: {
        name: 'pitch',
        summary: 'frequency target / harmonic address',
        detail: 'Controls tonal height or pitch selection. In coupled patches, pitch is where tension can become harmonic strain.',
        use: 'higher drive = brighter register, wider pitch pull, sharper harmonic motion',
        drivenBy: ['tension', 'volatility'],
      },
      filter: {
        name: 'filter',
        summary: 'spectral gate / brightness contour',
        detail: 'Shapes the brightness and spectral aperture of a block. It is the main surface for weather, pressure, and tone-color steering.',
        use: 'higher drive = more open spectrum, sharper contour, stronger color shift',
        drivenBy: ['tension', 'pressure', 'intensity'],
      },
      color: {
        name: 'color',
        summary: 'timbre stain / spectral identity',
        detail: 'Marks the block with source-derived tone color. It is a broad surface for making control feel visible in the sound.',
        use: 'higher drive = stronger coloration, more source identity, less neutrality',
        drivenBy: ['pressure', 'tension', 'intensity'],
      },
      decay: {
        name: 'decay',
        summary: 'release length / tail behavior',
        detail: 'Changes how long a gesture remains after articulation. Useful for turning density and tension into lingering or clipped behavior.',
        use: 'higher drive = longer tails, stretched release, or more unstable endings',
        audio: 'Envelope release/tail duration.',
        range: 'seconds, clamped 0.4..8 for DSL rows; voice may narrow internally',
        examples: ['decay 0.8', 'decay 3.5', 'decay *'],
        drivenBy: ['tension', 'density', 'intensity'],
      },
      tone: {
        name: 'tone',
        summary: 'brightness / harmonic emphasis',
        detail: 'Tilts the block toward darker or brighter harmonic behavior. It is a compact surface for timbral pressure.',
        use: 'higher drive = brighter edge, stronger tone focus, more harmonic bite',
        audio: 'Filter brightness and harmonic aperture.',
        range: 'dark/bright or 0..1; default 0.6',
        examples: ['tone dark', 'tone 0.75', 'tone weather.pressure 0.2 0.9'],
        drivenBy: ['tension', 'pressure'],
      },
      crush: {
        name: 'crush',
        summary: 'bit depth / amplitude resolution',
        detail: 'Quantizes amplitude to a literal bit depth. Resolution is separate: a filter/EQ aperture, not a crusher.',
        use: 'lower bits = more quantization; 16 is nearly clean, 4 is severe',
        audio: 'Amplitude bit-depth reduction after voice envelope/filter.',
        range: 'off/0 or integer 4..16; default off',
        examples: ['crush off', 'crush 8', 'crush 4'],
        drivenBy: ['pressure', 'rupture', 'tension'],
      },
      resolution: {
        name: 'resolution',
        summary: 'detail aperture / filter EQ',
        detail: 'Opens a linear filter/EQ aperture for perceived detail. It does not quantize amplitude and does not downsample.',
        use: 'higher values = more open top end and clearer transient detail',
        audio: 'Low-pass aperture after voice envelope/filter; independent from crush.',
        range: 'off/0..1; default off',
        examples: ['resolution 0.35', 'resolution 1', 'resolution mic.rupture 0 1'],
        drivenBy: ['rupture', 'pressure', 'density'],
      },
      rate: {
        name: 'rate',
        summary: 'sample speed / playback motion',
        detail: 'Changes sample playback speed and direction-like behavior. It lets unstable sources bend sample motion directly.',
        use: 'higher drive = faster playback, pitch-linked motion, or sample instability',
        audio: 'Sample playbackRate only; does not change phrase timing.',
        range: 'number/ratio 0.25..4; default 1',
        examples: ['rate 1/2', 'rate 2', 'rate *~'],
        drivenBy: ['volatility', 'density', 'tension'],
      },
      start: {
        name: 'start',
        summary: 'sample entry point / cut location',
        detail: 'Moves where sample playback begins. This surface turns rupture into cuts, skips, and re-articulations inside recorded material.',
        use: 'higher drive = more displacement, sharper cuts, less stable sample origin',
        audio: 'Sample buffer start offset.',
        range: 'seconds or normalized-like number, clamped to buffer length',
        examples: ['start 0', 'start 0.4', 'start mic.rupture 0 0.8'],
        drivenBy: ['rupture', 'volatility'],
      },
      sample: {
        name: 'sample',
        summary: 'archive choice / material selection',
        detail: 'Selects or biases which sample material appears. It is the surface for turning a signal into curatorial pressure.',
        use: 'higher drive = more active selection, tighter bias, or denser archive behavior',
        drivenBy: ['density', 'rupture', 'intensity'],
      },
      kit: {
        name: 'kit',
        summary: 'drum lane map / curated hit pool',
        detail: 'Selects the manifest-defined drum kit used by drum lane tokens (k/s/h/o/t/r/c/*). It is the curatorial surface for deterministic lane hits and wildcard pool behavior.',
        use: 'change kit id = new lane pools while timing and pattern stay unchanged',
        audio: 'Routes drum lane tokens to kit sample pools; does not change timing.',
        range: 'manifest kit ids, e.g. breakcore',
        examples: ['kit breakcore'],
        drivenBy: ['sample', 'density'],
      },
      variance: {
        name: 'variance',
        summary: 'drum sample diversity / lane stability blend',
        detail: 'Controls how much drum lane picks vary from the lane anchor. 0 locks each lane to a stable sample; 1 re-picks from the lane pool on every hit.',
        use: 'lower = stable lane identity; higher = more per-hit variation',
        audio: 'Sample selection diversity for drum lanes only; does not alter event timing.',
        range: 'off/0..1; default 1',
        examples: ['variance 0', 'variance 0.35', 'variance 1'],
        drivenBy: ['density', 'sample', 'rupture'],
      },
      opacity: {
        name: 'opacity',
        summary: 'video layer alpha / stage presence',
        detail: 'Sets how strongly a video layer appears in the compositor.',
        use: 'higher = more visible video layer',
        range: '0..1; default 1',
        examples: ['opacity 0.9', 'opacity camera.motion 0.2 1'],
        drivenBy: ['motion', 'presence'],
      },
      threshold: {
        name: 'threshold',
        summary: 'luma cutoff / binary segmentation',
        detail: 'Cuts image values around a moving threshold for hard masks and high-contrast silhouettes.',
        use: 'higher = fewer bright pixels survive',
        range: '0..1; default 0',
        examples: ['threshold 0.35', 'threshold mic.intensity 0.2 0.7'],
        drivenBy: ['rupture', 'brightness'],
      },
      edges: {
        name: 'edges',
        summary: 'edge emphasis / contour extraction',
        detail: 'Accents image boundaries and contour activity.',
        use: 'higher = stronger contour visibility',
        range: '0..1; default 0',
        examples: ['edges 0.4', 'edges camera.motion 0.1 0.8'],
        drivenBy: ['motion', 'contrast'],
      },
      posterize: {
        name: 'posterize',
        summary: 'color quantization / tone steps',
        detail: 'Reduces tonal gradation into discrete levels.',
        use: 'higher = fewer tone levels',
        range: '0..1; default 0',
        examples: ['posterize 0.5', 'posterize *'],
        drivenBy: ['rupture', 'density'],
      },
      invert: {
        name: 'invert',
        summary: 'polarity inversion / negative image',
        detail: 'Crossfades between normal and inverted image polarity.',
        use: 'higher = stronger negative inversion',
        range: '0..1; default 0',
        examples: ['invert 1', 'invert camera.flicker 0 1'],
        drivenBy: ['flicker', 'rupture'],
      },
      contrast: {
        name: 'contrast',
        summary: 'contrast gain / value spread',
        detail: 'Expands or compresses visual dynamic range.',
        use: 'higher = harder value separation',
        range: '0..1; default 0',
        examples: ['contrast 0.6', 'contrast camera.contrast 0 1'],
        drivenBy: ['contrast', 'pressure'],
      },
      saturate: {
        name: 'saturate',
        summary: 'chroma gain / color intensity',
        detail: 'Boosts or suppresses color intensity.',
        use: 'higher = stronger color saturation',
        range: '0..1; default 0',
        examples: ['saturate 0.4', 'saturate weather.dew 0.1 0.8'],
        drivenBy: ['presence', 'density'],
      },
      displace: {
        name: 'displace',
        summary: 'spatial warp / motion distortion',
        detail: 'Warps pixel positions with lightweight displacement fields.',
        use: 'higher = stronger geometric warp',
        range: '0..1; default 0',
        examples: ['displace 0.3', 'displace camera.flowx 0 1'],
        drivenBy: ['flowx', 'flowy'],
      },
      feedback: {
        name: 'feedback',
        summary: 'frame recursion / memory smear',
        detail: 'Feeds prior frame state back into current layer.',
        use: 'higher = longer visual memory trails',
        range: '0..1; default 0',
        examples: ['feedback 0.25', 'feedback camera.stillness 0.1 0.8'],
        drivenBy: ['stillness', 'density'],
      },
      delay: {
        name: 'delay',
        summary: 'frame lag / temporal offset',
        detail: 'Mixes delayed frame history against current frame.',
        use: 'higher = more delayed ghosts',
        range: '0..1; default 0',
        examples: ['delay 0.2', 'delay camera.motion 0 0.6'],
        drivenBy: ['motion', 'rupture'],
      },
      slitscan: {
        name: 'slitscan',
        summary: 'temporal slicing / scan remap',
        detail: 'Recombines current image from staggered historical strips.',
        use: 'higher = deeper temporal striping',
        range: '0..1; default 0',
        examples: ['slitscan 0.45', 'slitscan camera.flowy 0 1'],
        drivenBy: ['flowx', 'flowy'],
      },
      trail: {
        name: 'trail',
        summary: 'history trail / persistence',
        detail: 'Accumulates short frame history as translucent trails.',
        use: 'higher = longer persistence tails',
        range: '0..1; default 0',
        examples: ['trail 0.5', 'trail camera.stillness 0.1 0.85'],
        drivenBy: ['stillness', 'motion'],
      },
      mask: {
        name: 'mask',
        summary: 'mask amount / visibility gate',
        detail: 'Controls secondary mask influence in the compositor layer.',
        use: 'higher = stronger mask gating',
        range: '0..1; default 0',
        examples: ['mask 0.35', 'mask camera.edges 0 1'],
        drivenBy: ['edges', 'presence'],
      },
      key: {
        name: 'key',
        summary: 'key strength / cutout pressure',
        detail: 'Controls cutout/key aggressiveness for layer compositing.',
        use: 'higher = harder keyed isolation',
        range: '0..1; default 0',
        examples: ['key 0.3', 'key camera.brightness 0 1'],
        drivenBy: ['brightness', 'contrast'],
      },
      color: {
        name: 'color',
        summary: 'hue bias / chroma steering',
        detail: 'Offsets global hue and color cast for the layer.',
        use: 'higher = stronger hue shift',
        range: '0..1; default 0',
        examples: ['color 0.7', 'color weather.dew 0 1'],
        drivenBy: ['pressure', 'presence'],
      },
      blend: {
        name: 'blend',
        summary: 'composite operator / layer arithmetic',
        detail: 'Selects how a video layer combines with the stage buffer.',
        use: 'choose normal/screen/multiply/overlay/difference/lighter',
        range: 'named mode or 0..1',
        examples: ['blend difference', 'blend screen'],
        drivenBy: ['rupture', 'density'],
      },
      fade: {
        name: 'fade',
        summary: 'entry-exit envelope / presence gate',
        detail: 'Controls whether a block enters, leaves, or holds in place. It makes presence itself a performable surface.',
        use: 'higher drive = clearer entrances, exits, holds, or threshold behavior',
        audio: 'Block presence envelope after event gain/effects.',
        range: 'fade in/out/inout/outin seconds, hold, clear',
        examples: ['fade in 30s', 'fade inout 20s', 'fade clear'],
        drivenBy: ['intensity', 'rupture'],
      },
      harm: {
        name: 'harm',
        summary: 'harmonic selection / partial emphasis',
        detail: 'Bends harmonic emphasis inside pitched material. It turns control streams into changes in intervallic color.',
        use: 'higher drive = stronger harmonic pull, brighter partials, altered interval color',
        audio: 'Partial/harmonic count or mode for pitched voices.',
        range: 'simple/pair/triad/rich or 1..5; default pair',
        examples: ['harm simple', 'harm 4', 'harm *'],
        drivenBy: ['tension', 'pressure'],
      },
      octave: {
        name: 'octave',
        summary: 'register displacement / octave pressure',
        detail: 'Moves material between octave bands. This surface keeps pitch identity while changing scale and register.',
        use: 'higher drive = broader register jumps, more vertical displacement',
        audio: 'Integer octave transposition for pitched voices.',
        range: 'integer -2..2; default 0',
        examples: ['octave -1', 'octave 1', 'octave *'],
        drivenBy: ['tension', 'volatility'],
      },
      resonance: {
        name: 'resonance',
        summary: 'filter peak / ringing emphasis',
        detail: 'Adds focused ringing around spectral contours. It can make tension feel like a point of acoustic stress.',
        use: 'higher drive = sharper peaks, more whistle, more unstable focus',
        drivenBy: ['tension', 'pressure'],
      },
      comb: {
        name: 'comb',
        summary: 'delay teeth / resonant interference',
        detail: 'Creates tight delay-based coloration and notched resonance. It is a surface for making space feel mechanical or striated.',
        use: 'higher drive = stronger interference, metallic teeth, tighter coloration',
        drivenBy: ['volatility', 'tension'],
      },
      grain: {
        name: 'grain',
        summary: 'granular texture / particle behavior',
        detail: 'Breaks material into smaller pieces and controls particle activity. It turns density into audible particulate motion.',
        use: 'higher drive = more particles, finer texture, denser fragmentation',
        audio: 'Granular/particle density for sample and texture behavior.',
        range: '0..1 or modes memory/scatter/freeze',
        examples: ['grain 0.25', 'grain scatter', 'grain mic.noisiness 0 0.7'],
        drivenBy: ['density', 'volatility', 'rupture'],
      },
      chorus: {
        name: 'chorus',
        summary: 'detuned doubling / unstable plurality',
        detail: 'Adds moving duplicate voices around the source. It is a surface for widening and destabilizing identity.',
        use: 'higher drive = wider doubling, more shimmer, less single-body certainty',
        drivenBy: ['volatility', 'tension'],
      },
      excite: {
        name: 'excite',
        summary: 'added brightness / activation energy',
        detail: 'Injects extra high-frequency activation into the block. It makes the source feel sparked or chemically awake.',
        use: 'higher drive = brighter attack, more activation, more edge',
        drivenBy: ['intensity', 'rupture', 'tension'],
      },
      blur: {
        name: 'blur',
        summary: 'edge smear / temporal softening',
        detail: 'Softens articulation and smears boundaries. It is the opposite of rupture: a surface for loss of contour.',
        use: 'higher drive = more smear, softer attacks, less precise edges',
        drivenBy: ['volatility', 'density'],
      },
      scar: {
        name: 'scar',
        summary: 'cut memory / accumulated damage',
        detail: 'Leaves marks from discontinuities and attacks. It lets rupture become a remembered texture instead of a one-time event.',
        use: 'higher drive = more cuts, marks, hard edits, and historical damage',
        audio: 'Cut/residue amount in sample and texture behavior.',
        range: '0..1 or modes memory/rupture/ghost',
        examples: ['scar 0.2', 'scar rupture', 'scar *'],
        drivenBy: ['rupture', 'pressure'],
      },
      literal: {
        name: 'literal',
        summary: 'fixed value / uncoupled surface',
        detail: 'This block has no exposed surface chips yet. Its values are being read as written rather than bent by an attractor or control stream.',
        use: 'literal = stable score behavior with no active surface legend',
        drivenBy: ['score'],
      },
    };

    const SURFACE_STATE_META = {
      speed: {
        label: 'SPEED',
        role: 'playback rate / beat division',
        bends: ['beat', 'rate', 'time'],
        units: ['number', 'ratio', 'pattern'],
        cues: [
          { test: (item) => item.kind === 'pattern', text: 'patterned playback clock' },
          { test: (item) => numericAverage(item.values) > 1.25, text: 'fast playback pressure' },
          { test: (item) => numericAverage(item.values) > 0 && numericAverage(item.values) < 0.85, text: 'slowed time / stretched pacing' },
        ],
      },
      pan: {
        label: 'PAN',
        role: 'stereo or spatial placement',
        bends: ['space', 'motion', 'field'],
        units: ['left', 'right', 'center', 'modulation'],
        cues: [
          { test: (item) => item.kind === 'field' || item.kind === 'modulation', text: 'stereo motion field' },
          { test: (item) => item.rawLower.includes('right') && item.rawLower.includes('left'), text: 'right/left pan alternation' },
        ],
      },
      gain: {
        label: 'GAIN',
        role: 'amplitude scalar',
        bends: ['loudness', 'presence'],
        units: ['0–1', 'number', 'signal'],
        cues: [
          { test: (item) => numericAverage(item.values) >= 0.75, text: 'strong presence / forward level' },
          { test: (item) => numericAverage(item.values) > 0 && numericAverage(item.values) < 0.4, text: 'quiet level / recessed presence' },
          { test: (item) => numericAverage(item.values) > 0, text: 'moderate amplitude scalar' },
        ],
      },
      compress: {
        label: 'COMPRESS',
        role: 'dynamic pressure / transient containment',
        bends: ['body', 'density', 'force'],
        units: ['number', 'symbol', 'signal'],
        cues: [{ test: () => true, text: 'dynamic clamp / pressure control' }],
      },
      force: {
        label: 'FORCE',
        role: 'physical pressure applied to the patch',
        bends: ['body', 'compress', 'trigger'],
        units: ['pp', 'p', 'mp', 'mf', 'f', 'ff'],
        cues: [
          { test: (item) => item.displayText.includes('MF'), text: 'medium-force body pressure' },
          { test: (item) => numericAverage(item.values) >= 0.7, text: 'heavy physical push' },
          { test: (item) => numericAverage(item.values) > 0, text: 'body pressure / trigger force' },
        ],
      },
      decay: {
        label: 'DECAY',
        role: 'tail length / release memory',
        bends: ['space', 'resonance', 'memory'],
        units: ['seconds', 'ratio', 'number'],
        cues: [
          { test: (item) => numericAverage(item.values) >= 2, text: 'long tail / release memory' },
          { test: (item) => numericAverage(item.values) > 0, text: 'shortened release contour' },
        ],
      },
      pitch: {
        label: 'PITCH',
        role: 'frequency displacement / harmonic position',
        bends: ['tone', 'tension', 'resonance'],
        units: ['number', 'ratio', 'symbol'],
        cues: [{ test: () => true, text: 'harmonic displacement / pitch pull' }],
      },
      filter: {
        label: 'FILTER',
        role: 'spectral gate / color aperture',
        bends: ['tone', 'brightness', 'pressure'],
        units: ['hz', 'word', 'number'],
        cues: [{ test: () => true, text: 'spectral aperture / brightness contour' }],
      },
      color: {
        label: 'COLOR',
        role: 'timbre tint / spectral identity',
        bends: ['tone', 'surface', 'source'],
        units: ['word', 'symbol', 'signal'],
        cues: [{ test: () => true, text: 'timbre stain / source color' }],
      },
      crush: {
        label: 'CRUSH',
        role: 'amplitude bit depth',
        bends: ['rupture', 'scar', 'body'],
        units: ['off', '4-16', 'signal'],
        cues: [
          { test: (item) => numericAverage(item.values) > 0 && numericAverage(item.values) <= 6, text: 'severe bit-depth quantization' },
          { test: (item) => numericAverage(item.values) > 0 && numericAverage(item.values) < 12, text: 'audible bit-depth crunch' },
          { test: () => true, text: 'amplitude resolution control' },
        ],
      },
      resolution: {
        label: 'RESOLUTION',
        role: 'sample-hold time reduction',
        bends: ['rupture', 'pressure', 'density'],
        units: ['off', '0-1', 'signal'],
        cues: [
          { test: (item) => numericAverage(item.values) >= 0.75, text: 'coarse sample-hold stepping' },
          { test: (item) => numericAverage(item.values) > 0, text: 'reduced time resolution' },
        ],
      },
      rate: {
        label: 'RATE',
        role: 'sample playback speed',
        bends: ['sample', 'pitch', 'motion'],
        units: ['number', 'ratio', 'pattern'],
        cues: [{ test: () => true, text: 'sample motion / playback rate' }],
      },
      start: {
        label: 'START',
        role: 'sample entry point / cut location',
        bends: ['rupture', 'sample', 'scar'],
        units: ['seconds', 'number', 'signal'],
        cues: [{ test: () => true, text: 'sample cut-point displacement' }],
      },
      sample: {
        label: 'SAMPLE',
        role: 'archive choice / material selection',
        bends: ['archive', 'density', 'rupture'],
        units: ['selector', 'word', 'signal'],
        cues: [{ test: () => true, text: 'archive selection pressure' }],
      },
      kit: {
        label: 'KIT',
        role: 'drum lane mapping / curated hit pool',
        bends: ['sample', 'density', 'selection'],
        units: ['kit id'],
        cues: [{ test: () => true, text: 'drum lane pool selection' }],
      },
      variance: {
        label: 'VARIANCE',
        role: 'drum lane sample diversity',
        bends: ['sample', 'density', 'identity'],
        units: ['off', '0-1', 'signal'],
        cues: [
          { test: (item) => numericAverage(item.values) <= 0.1, text: 'stable lane anchors (minimal variation)' },
          { test: (item) => numericAverage(item.values) >= 0.75, text: 'high lane variance (frequent repicks)' },
          { test: () => true, text: 'probabilistic blend of anchors and fresh picks' },
        ],
      },
      fade: {
        label: 'FADE',
        role: 'entry-exit envelope / presence gate',
        bends: ['presence', 'threshold', 'time'],
        units: ['mode', 'seconds'],
        cues: [{ test: () => true, text: 'presence envelope / entrance gate' }],
      },
      harm: {
        label: 'HARM',
        role: 'harmonic selection / partial emphasis',
        bends: ['pitch', 'tone', 'color'],
        units: ['number', 'symbol'],
        cues: [{ test: () => true, text: 'harmonic color selection' }],
      },
      octave: {
        label: 'OCTAVE',
        role: 'register displacement',
        bends: ['pitch', 'scale', 'register'],
        units: ['integer', 'pattern'],
        cues: [{ test: () => true, text: 'register shift / scale displacement' }],
      },
      resonance: {
        label: 'RESONANCE',
        role: 'resonant emphasis / ringing body',
        bends: ['body', 'tone', 'decay'],
        units: ['number', 'mode'],
        cues: [{ test: () => true, text: 'ringing body emphasis' }],
      },
      comb: {
        label: 'COMB',
        role: 'delay-line coloration',
        bends: ['space', 'filter', 'body'],
        units: ['number', 'mode'],
        cues: [{ test: () => true, text: 'mechanical comb coloration' }],
      },
      grain: {
        label: 'GRAIN',
        role: 'granular spray / microscopic density',
        bends: ['density', 'sample', 'time'],
        units: ['number', 'mode'],
        cues: [{ test: () => true, text: 'grain cloud / microscopic density' }],
      },
      chorus: {
        label: 'CHORUS',
        role: 'duplicate voice spread',
        bends: ['space', 'blur', 'motion'],
        units: ['number', 'mode'],
        cues: [{ test: () => true, text: 'widened duplicate-voice field' }],
      },
      excite: {
        label: 'EXCITE',
        role: 'activation energy / brightness injection',
        bends: ['attack', 'tone', 'rupture'],
        units: ['number', 'mode'],
        cues: [{ test: () => true, text: 'sparked attack / added brightness' }],
      },
      blur: {
        label: 'BLUR',
        role: 'edge smear / temporal softening',
        bends: ['time', 'density', 'contour'],
        units: ['number', 'mode'],
        cues: [{ test: () => true, text: 'smeared contour / softened articulation' }],
      },
      scar: {
        label: 'SCAR',
        role: 'cut memory / accumulated damage',
        bends: ['rupture', 'sample', 'history'],
        units: ['number', 'mode'],
        cues: [{ test: () => true, text: 'remembered cuts / historical damage' }],
      },
      body: {
        label: 'BODY',
        role: 'resonant mass / embodied color',
        bends: ['pressure', 'tone', 'space'],
        units: ['number', 'mode'],
        cues: [{ test: () => true, text: 'resonant mass / object color' }],
      },
        mallet: {
          label: 'MALLET',
          role: 'marimba mallet family / attack material',
          bends: ['attack', 'tone', 'body'],
          units: ['yarn', 'cord', 'rubber'],
          cues: [
            { test: (item) => item.displayText.includes('RUBBER'), text: 'hard mallet / bright attack' },
            { test: (item) => item.displayText.includes('CORD'), text: 'medium mallet / balanced attack' },
            { test: (item) => item.displayText.includes('YARN'), text: 'soft mallet / warm attack' },
            { test: () => true, text: 'marimba mallet selection' },
          ],
        },
        deadstroke: {
          label: 'DEADSTROKE',
          role: 'bar damping / stopped resonance',
          bends: ['damping', 'attack', 'decay'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.7, text: 'strongly damped dead stroke' },
            { test: (item) => numericAverage(item.values) > 0, text: 'partial damping / shortened bar resonance' },
            { test: () => true, text: 'open ringing stroke' },
          ],
        },
        roll: {
          label: 'ROLL',
          role: 'marimba roll density / tremolo sustain',
          bends: ['density', 'time', 'resonance'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.7, text: 'dense sustained roll' },
            { test: (item) => numericAverage(item.values) > 0, text: 'light roll / tremolo sustain' },
            { test: () => true, text: 'single strike / no roll' },
          ],
        },
        spread: {
          label: 'SPREAD',
          role: 'four-mallet chord timing spread',
          bends: ['gesture', 'human', 'time'],
          units: ['0–1', 'seconds'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.05, text: 'wide hand-spread chord gesture' },
            { test: (item) => numericAverage(item.values) > 0, text: 'small four-mallet timing spread' },
            { test: () => true, text: 'vertical chord attack' },
          ],
        },
        motor: {
          label: 'MOTOR',
          role: 'rotating resonator tremolo / vibraphone motor',
          bends: ['motion', 'shimmer', 'time'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.7, text: 'fast mechanical shimmer' },
            { test: (item) => numericAverage(item.values) > 0, text: 'motor tremolo active' },
            { test: () => true, text: 'motor off / static bars' },
          ],
        },
        depth: {
          label: 'DEPTH',
          role: 'motor tremolo depth',
          bends: ['amplitude', 'motion', 'shimmer'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.7, text: 'deep motor gating' },
            { test: (item) => numericAverage(item.values) > 0, text: 'subtle amplitude shimmer' },
            { test: () => true, text: 'no motor depth' },
          ],
        },
        damp: {
          label: 'DAMP',
          role: 'manual damping / stopped metal bar',
          bends: ['damping', 'pedal', 'decay'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.7, text: 'strong stopped-bar damping' },
            { test: (item) => numericAverage(item.values) > 0, text: 'partial hand damping' },
            { test: () => true, text: 'open undamped bar' },
          ],
        },
        bowpressure: {
          label: 'BOWPRESSURE',
          role: 'bowed metal pressure / spectral edge',
          bends: ['attack', 'scrape', 'brightness'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.7, text: 'high bow pressure / bright scrape' },
            { test: (item) => numericAverage(item.values) > 0, text: 'bowed-bar pressure' },
            { test: () => true, text: 'light bowed-bar contact' },
          ],
        },
        vowel: {
          label: 'VOWEL',
          role: 'voice vowel / mouth shape',
          bends: ['mouth', 'tone', 'body'],
          units: ['ah', 'eh', 'ee', 'oh', 'oo'],
          cues: [{ test: () => true, text: 'vowel material / sung mouth state' }],
        },
        syllable: {
          label: 'SYLLABLE',
          role: 'controlled robot-mouth token',
          bends: ['mouth', 'signal', 'word'],
          units: ['ah', 'ma', 'null', 'input', 'error'],
          cues: [{ test: () => true, text: 'machine syllable / token source' }],
        },
        carrier: {
          label: 'CARRIER',
          role: 'synthetic source / corpus fallback mode',
          bends: ['oscillator', 'sample', 'tone'],
          units: ['sample', 'sine', 'saw', 'square', 'pulse', 'noise'],
          cues: [{ test: () => true, text: 'robot voice carrier source' }],
        },
        robot: {
          label: 'ROBOT',
          role: 'mechanical stepping / quantized mouth motion',
          bends: ['stepping', 'roughness', 'machine'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.7, text: 'hard machine-mouth stepping' },
            { test: (item) => numericAverage(item.values) > 0, text: 'light robot stepping' },
            { test: () => true, text: 'smooth formant voice' },
          ],
        },
        breath: {
          label: 'BREATH',
          role: 'air/noise layer / breath pressure',
          bends: ['air', 'noise', 'fragility'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.65, text: 'high breath/noise presence' },
            { test: (item) => numericAverage(item.values) > 0, text: 'audible breath layer' },
            { test: () => true, text: 'clean voice tone' },
          ],
        },
        mouth: {
          label: 'MOUTH',
          role: 'vowel openness / brightness',
          bends: ['formant', 'tone', 'body'],
          units: ['0–1', 'off', 'on'],
          cues: [{ test: () => true, text: 'mouth brightness / openness' }],
        },
        formant: {
          label: 'FORMANT',
          role: 'approximate voice tract shift',
          bends: ['body', 'mouth', 'register'],
          units: ['-1–1'],
          cues: [
            { test: (item) => numericAverage(item.values) > 0.15, text: 'smaller/brighter voice tract approximation' },
            { test: (item) => numericAverage(item.values) < -0.15, text: 'larger/darker voice tract approximation' },
            { test: () => true, text: 'natural formant region' },
          ],
        },
        roughness: {
          label: 'ROUGHNESS',
          role: 'instability / fry / voice edge',
          bends: ['noise', 'rate', 'crush'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.65, text: 'strong voice instability' },
            { test: (item) => numericAverage(item.values) > 0, text: 'subtle roughness / edge' },
            { test: () => true, text: 'clean emission' },
          ],
        },
        ensemble: {
          label: 'ENSEMBLE',
          role: 'stacked synthetic mouths / machine choir',
          bends: ['human', 'spread', 'chorus'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.6, text: 'stacked machine choir' },
            { test: (item) => numericAverage(item.values) > 0, text: 'light synthetic doubling' },
            { test: () => true, text: 'single robot mouth' },
          ],
        },
        vocoder: {
          label: 'VOCODER',
          role: 'banded metallic speech color',
          bends: ['bands', 'metal', 'mouth'],
          units: ['0–1', 'off', 'on'],
          cues: [
            { test: (item) => numericAverage(item.values) >= 0.6, text: 'strong vocoder-ish banding' },
            { test: (item) => numericAverage(item.values) > 0, text: 'subtle banded machine color' },
            { test: () => true, text: 'unbanded robot voice' },
          ],
        },
    };

    const SIGNALS = Object.entries(SIGNAL_META).map(([abbr, meta]) => [abbr, meta.key, meta.name]);

    function classifySlotForViz(node) {
      if (!node) return 'rest';
      if (node.kind === 'group') return 'group';
      if (node.kind === 'leaf') {
        const t = node.token;
        if (t.kind === 'rest') return 'rest';
        if (t.kind === 'sample' || t.kind === 'sample-selector') return 'sample';
        if (t.kind === 'noise') return 'sample';
        if (t.kind === 'pulse') return 'sample';
        if (t.kind === 'drum') return 'sample';
        if (t.kind === 'voice') return 'sample';
        return 'note';
      }
      return 'rest';
    }

    function hasParamControlStream(stream) {
      if (!stream) return false;
      if (stream.kind === 'scalar') return isParamOp(stream.value);
      if (stream.kind === 'vector') return stream.values.some(isParamOp);
      return false;
    }

    function isParamOp(v) {
      return v && typeof v === 'object' && v.kind === 'param-op';
    }

    function surfaceStateMetaFor(name) {
      const key = String(name || '').toLowerCase();
      const fallback = surfaceMetaFor(key);
      return SURFACE_STATE_META[key] || {
        label: key.toUpperCase(),
        role: fallback.summary || 'exposed behavior surface',
        bends: fallback.drivenBy || ['score'],
        units: ['value'],
        cues: [{ test: () => true, text: fallback.use || `${key} behavior surface` }],
      };
    }

    function numericAverage(values) {
      if (!Array.isArray(values)) return 0;
      const nums = values.map((v) => Number(v)).filter(Number.isFinite);
      if (!nums.length) return 0;
      return nums.reduce((sum, v) => sum + v, 0) / nums.length;
    }

    function paramStreamValues(stream) {
      if (!stream) return [];
      const raw = stream.kind === 'vector' ? stream.values : [stream.value];
      return raw.map((value) => {
        if (isParamOp(value)) return value.raw || value.op || '*';
        if (typeof value === 'number') return value;
        if (value && typeof value === 'object') return value.raw || value.name || value.kind || 'object';
        return value;
      });
    }

    function rawParamLineForBlock(block, name) {
      if (!block || !block.paramLines || !editorAPI) return '';
      const lineNumber = block.paramLines[name];
      if (!lineNumber) return '';
      const lines = String(editorAPI.getValue() || '').split(/\r?\n/);
      const line = lines[lineNumber - 1] || '';
      const trimmed = line.trim();
      const pattern = new RegExp('^' + String(name).replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\b\\s*', 'i');
      return trimmed.replace(pattern, '').trim();
    }

    function escapeTooltipText(value) {
      const div = document.createElement('div');
      div.textContent = value == null ? '' : String(value);
      return div.innerHTML;
    }

    function displayTokensFromRaw(raw) {
      const text = String(raw || '').trim();
      if (!text) return [];
      const normalized = text
        .replace(/\bpi\b/gi, 'π')
        .replace(/\b([0-9]+)\s*\*\s*π\b/g, '$1π')
        .replace(/[()]/g, ' ')
        .replace(/[|]/g, ' | ')
        .replace(/\s+/g, ' ')
        .trim();
      return normalized ? normalized.split(' ').filter(Boolean) : [];
    }

    function classifySurfaceState(name, raw, stream) {
      const text = String(raw || '').trim();
      const lower = text.toLowerCase();
      const values = paramStreamValues(stream);
      const tokenCount = displayTokensFromRaw(text).filter((token) => token !== '|').length || values.length;

      if (/\*|~|_/.test(text)) {
        if (/\bleft\b|\bright\b|\bcenter\b/.test(lower)) return 'field';
        return 'modulation';
      }
      if (/[()|]/.test(text) || tokenCount > 1 || (stream && stream.kind === 'vector')) return 'pattern';
      if (/^(ppp|pp|p|mp|mf|f|ff|fff|quiet|half|full|loud|dark|bright|left|right|center|off|on)$/i.test(text)) return 'symbol';
      if (values.length && values.every((v) => Number.isFinite(Number(v)))) return 'number';
      if (/^-?(?:\d+(?:\.\d+)?|π|pi)(?:[*/]-?(?:\d+(?:\.\d+)?|π|pi))*$/i.test(text)) return 'number';
      if (/^[a-z][a-z0-9_.:-]*$/i.test(text)) return 'word';
      return 'unknown';
    }

    function surfaceStateDisplayText(raw, values) {
      const tokens = displayTokensFromRaw(raw);
      if (tokens.length) return tokens.join(' · ');
      if (Array.isArray(values) && values.length) {
        return values.map((v) => {
          if (typeof v === 'number') return Number.isInteger(v) ? String(v) : String(Number(v.toFixed(3))).replace(/^0\./, '.');
          return String(v);
        }).join(' · ');
      }
      return 'default';
    }


    function formatSurfaceNumber(value) {
      const n = Number(value);
      if (!Number.isFinite(n)) return String(value == null ? '' : value);
      if (Math.abs(n) >= 10) return String(Math.round(n * 10) / 10);
      if (Number.isInteger(n)) return String(n);
      return String(Math.round(n * 100) / 100).replace(/^0\./, '.').replace(/^-0\./, '-.');
    }

    function liveSurfaceValueFor(name, liveState) {
      if (!liveState) return undefined;
      const key = String(name || '').toLowerCase();
      if (key === 'speed') return liveState.speed;
      if (key === 'fade') return undefined;
      if (liveState.params && Object.prototype.hasOwnProperty.call(liveState.params, key)) return liveState.params[key];
      if (liveState.effects) {
        const rawKey = '_raw' + key.charAt(0).toUpperCase() + key.slice(1);
        if (Object.prototype.hasOwnProperty.call(liveState.effects, rawKey)) return liveState.effects[rawKey];
        if (Object.prototype.hasOwnProperty.call(liveState.effects, key)) return liveState.effects[key];
      }
      return undefined;
    }

    function displayTextForLiveSurface(name, liveValue, fallback) {
      if (liveValue === undefined || liveValue === null || liveValue === '') return fallback;
      const key = String(name || '').toLowerCase();
      if (typeof liveValue === 'number') {
        if (key === 'pan') {
          if (liveValue > 0.08) return `R ${formatSurfaceNumber(liveValue)}`;
          if (liveValue < -0.08) return `L ${formatSurfaceNumber(Math.abs(liveValue))}`;
          return 'CENTER';
        }
        return formatSurfaceNumber(liveValue);
      }
      if (typeof liveValue === 'string') return liveValue.toUpperCase();
      if (liveValue && typeof liveValue === 'object') return String(liveValue.raw || liveValue.name || liveValue.kind || fallback || 'ON').toUpperCase();
      return String(liveValue).toUpperCase();
    }

    function streamForSurface(block, name) {
      if (!block) return null;
      if (name === 'speed') return block.speed || null;
      if (name === 'fade') return block.fade || null;
      if (block.params && block.params[name]) return block.params[name];
      if (block.effects && block.effects[name]) return block.effects[name];
      return null;
    }

    function activeSurfaceStateItems(block, liveState) {
      if (!block || !block.paramLines) return [];
      const items = [];
      const seen = new Set();
      const keys = Object.keys(block.paramLines)
        .filter((name) => SURFACE_STATE_META[name] || SURFACE_META[name] || name === 'fade')
        .sort((a, b) => (block.paramLines[a] || 0) - (block.paramLines[b] || 0));

      for (const name of keys) {
        if (seen.has(name)) continue;
        seen.add(name);
        const stream = streamForSurface(block, name);
        if (!stream && name !== 'fade') continue;
        const raw = rawParamLineForBlock(block, name);
        const values = paramStreamValues(stream);
        const kind = classifySurfaceState(name, raw, stream);
        const meta = surfaceStateMetaFor(name);
        const fallbackText = surfaceStateDisplayText(raw, values);
        const liveValue = liveSurfaceValueFor(name, liveState);
        const displayText = displayTextForLiveSurface(name, liveValue, fallbackText);
        const item = {
          name,
          meta,
          kind,
          raw,
          rawLower: String(raw || '').toLowerCase(),
          values: liveValue !== undefined && liveValue !== null && Number.isFinite(Number(liveValue)) ? [Number(liveValue)] : values,
          liveValue,
          displayText,
          behavior: meta.role,
        };
        const cue = (meta.cues || []).find((candidate) => {
          try { return candidate.test(item); } catch (_) { return false; }
        });
        if (cue && cue.text) item.behavior = cue.text;
        items.push(item);
      }
      return items;
    }

    function surfaceStateTokens(item) {
      const tokens = String(item && item.displayText ? item.displayText : '')
        .split(' · ')
        .map((token) => token.trim())
        .filter(Boolean)
        .filter((token) => token !== '|');
      if (tokens.length) return tokens;
      if (item && Array.isArray(item.values) && item.values.length) {
        return item.values.map((value) => String(value)).filter(Boolean);
      }
      return ['default'];
    }

    function compactSurfaceStateValue(item) {
      const tokens = surfaceStateTokens(item);
      const upper = tokens.map((token) => token.toUpperCase());
      if (item.kind === 'field') {
        const hasLeft = upper.some((token) => token.includes('LEFT'));
        const hasRight = upper.some((token) => token.includes('RIGHT'));
        const hasCenter = upper.some((token) => token.includes('CENTER'));
        if (hasLeft && hasRight) return 'R ↔ L';
        if (hasLeft) return 'LEFT';
        if (hasRight) return 'RIGHT';
        if (hasCenter) return 'CENTER';
      }
      if (item.kind === 'pattern' || item.kind === 'modulation') {
        const visible = tokens.filter((token) => !/^[*~_\-]+$/.test(token)).slice(0, 4);
        return visible.join(' ').replace(/\bpi\b/gi, 'π') || item.kind.toUpperCase();
      }
      const joined = tokens.slice(0, 3).join(' ');
      if (joined.length > 18) return `${joined.slice(0, 15)}…`;
      return joined || 'default';
    }

    function surfaceHudKind(item) {
      const name = String(item && item.name ? item.name : '').toLowerCase();
      if (name === 'speed' || name === 'rate') return 'clock';
      if (name === 'pan') return 'pan';
      if (name === 'gain') return 'level';
      if (name === 'compress' || name === 'crush' || name === 'resolution' || name === 'variance' || name === 'threshold' || name === 'edges' || name === 'mask' || name === 'key') return 'clamp';
      if (name === 'force') return 'pressure';
      if (name === 'decay' || name === 'fade') return 'tail';
      if (name === 'space' || name === 'blur' || name === 'chorus' || name === 'trail' || name === 'feedback' || name === 'delay' || name === 'slitscan') return 'field';
      if (name === 'pitch' || name === 'octave' || name === 'harm') return 'pitch';
      if (name === 'grain' || name === 'density') return 'particle';
      if (name === 'sample' || name === 'start' || name === 'kit') return 'tape';
      if (name === 'scar' || name === 'rupture') return 'cut';
      if (name === 'tone' || name === 'filter' || name === 'color' || name === 'body' || name === 'blend' || name === 'posterize' || name === 'invert' || name === 'contrast' || name === 'saturate' || name === 'displace' || name === 'opacity' || name === 'monitor' || name === 'listen') return 'stamp';
      if (item.kind === 'number') return 'level';
      if (item.kind === 'pattern' || item.kind === 'modulation') return 'clock';
      return 'stamp';
    }

    function normalizedSurfaceNumber(item) {
      const nums = (item && Array.isArray(item.values) ? item.values : [])
        .map((value) => Number(value))
        .filter(Number.isFinite);
      if (nums.length) {
        const avg = nums.reduce((sum, value) => sum + value, 0) / nums.length;
        if (item && item.name === 'crush') return avg <= 0 ? 0 : Math.max(0, Math.min(1, (16 - avg) / 12));
        return Math.max(0, Math.min(1, avg));
      }
      const text = String(item && item.raw ? item.raw : '').trim();
      const n = Number(text);
      if (!Number.isFinite(n)) return 0.5;
      if (item && item.name === 'crush') return n <= 0 ? 0 : Math.max(0, Math.min(1, (16 - n) / 12));
      if (n > 1) return Math.max(0, Math.min(1, n / 8));
      return Math.max(0, Math.min(1, n));
    }

    function meterCellsHTML(count, active, className = 'surface-hud-cell') {
      const total = Math.max(1, count | 0);
      const filled = Math.max(0, Math.min(total, active | 0));
      let html = '';
      for (let i = 0; i < total; i += 1) {
        html += `<span class="${className}${i < filled ? ' is-on' : ''}"></span>`;
      }
      return html;
    }

    function clockHudHTML(item) {
      const tokens = surfaceStateTokens(item).filter((token) => token !== '|').slice(0, 4);
      const filled = Math.max(1, Math.min(4, tokens.length || 1));
      return `<span class="surface-hud-clock" aria-hidden="true">${meterCellsHTML(4, filled)}</span>`;
    }

    function pressureHudHTML(item) {
      const symbols = { ppp: 1, pp: 1, p: 2, mp: 3, mf: 4, f: 5, ff: 6, fff: 6 };
      const key = String(compactSurfaceStateValue(item)).toLowerCase().trim();
      const filled = symbols[key] || Math.max(1, Math.round(normalizedSurfaceNumber(item) * 6));
      return `<span class="surface-hud-ladder" aria-hidden="true">${meterCellsHTML(6, filled, 'surface-hud-step')}</span>`;
    }

    function tailHudHTML(item) {
      const filled = Math.max(1, Math.round(normalizedSurfaceNumber(item) * 6));
      return `<span class="surface-hud-tail" aria-hidden="true">${meterCellsHTML(6, filled)}</span>`;
    }

    function panHudHTML(item) {
      const text = String(item.raw || item.displayText || '').toLowerCase();
      const hasLeft = /left/.test(text);
      const hasRight = /right/.test(text);
      const hasCenter = /center/.test(text) || (!hasLeft && !hasRight);
      return `
        <span class="surface-hud-pan" aria-hidden="true">
          <span>L</span>
          <span class="surface-hud-pan-cell${hasLeft ? ' is-on' : ''}"></span>
          <span class="surface-hud-pan-cell${hasCenter ? ' is-on' : ''}"></span>
          <span class="surface-hud-pan-cell${hasRight ? ' is-on' : ''}"></span>
          <span>R</span>
        </span>`;
    }

    function levelHudHTML(item, cells = 6) {
      const filled = Math.max(0, Math.min(cells, Math.round(normalizedSurfaceNumber(item) * cells)));
      return `<span class="surface-hud-level" aria-hidden="true">${meterCellsHTML(cells, filled)}</span>`;
    }

    function fieldHudHTML(item) {
      const filled = Math.max(1, Math.round(normalizedSurfaceNumber(item) * 5));
      return `<span class="surface-hud-field" aria-hidden="true">${meterCellsHTML(5, filled)}</span>`;
    }

    function pitchHudHTML(item) {
      const n = normalizedSurfaceNumber(item);
      const active = Math.max(1, Math.min(5, Math.round(n * 5)));
      return `<span class="surface-hud-pitch" aria-hidden="true">${meterCellsHTML(5, active)}</span>`;
    }

    function particleHudHTML(item) {
      const active = Math.max(1, Math.min(7, Math.round(normalizedSurfaceNumber(item) * 7)));
      return `<span class="surface-hud-particles" aria-hidden="true">${meterCellsHTML(7, active, 'surface-hud-dot')}</span>`;
    }

    function tapeHudHTML(item) {
      return `<span class="surface-hud-tape" aria-hidden="true"><span></span><span></span><span></span></span>`;
    }

    function cutHudHTML(item) {
      const active = Math.max(1, Math.min(5, Math.round(normalizedSurfaceNumber(item) * 5)));
      return `<span class="surface-hud-cut" aria-hidden="true">${meterCellsHTML(5, active)}</span>`;
    }

    function stampHudHTML(item) {
      const value = escapeTooltipText(compactSurfaceStateValue(item).toUpperCase());
      return `<span class="surface-hud-stamp" aria-hidden="true">${value || 'ON'}</span>`;
    }

    function surfaceHudVizHTML(item) {
      switch (surfaceHudKind(item)) {
        case 'clock': return clockHudHTML(item);
        case 'pressure': return pressureHudHTML(item);
        case 'tail': return tailHudHTML(item);
        case 'pan': return panHudHTML(item);
        case 'level': return levelHudHTML(item);
        case 'clamp': return levelHudHTML(item, 5);
        case 'field': return fieldHudHTML(item);
        case 'pitch': return pitchHudHTML(item);
        case 'particle': return particleHudHTML(item);
        case 'tape': return tapeHudHTML(item);
        case 'cut': return cutHudHTML(item);
        case 'stamp':
        default: return stampHudHTML(item);
      }
    }

    function surfaceStateHudHTML(item) {
      const label = escapeTooltipText(item.meta.label || item.name.toUpperCase());
      const value = escapeTooltipText(compactSurfaceStateValue(item).toUpperCase());
      const kind = escapeTooltipText(surfaceHudKind(item).toUpperCase());
      const aria = `${label}: ${compactSurfaceStateValue(item)}. ${item.behavior || item.meta.role || 'active surface parameter'}.`;
      return `
        <button class="surface-hud" type="button" data-surface="${escapeTooltipText(item.name)}" data-kind="${escapeTooltipText(item.kind)}" data-hud-kind="${kind}" aria-label="${escapeTooltipText(aria)}">
          <span class="surface-hud-top"><span class="surface-hud-label">${label}</span><span class="surface-hud-kind">${kind}</span></span>
          <span class="surface-hud-value">${value || 'ON'}</span>
          ${surfaceHudVizHTML(item)}
        </button>`;
    }

    function renderSurfaceStatePanel(el, block, liveState) {
      if (!el) return [];
      const items = activeSurfaceStateItems(block, liveState);
      if (!items.length) {
        if (el.classList && el.classList.contains('block-surface-state')) {
          el.innerHTML = '';
          el.hidden = true;
        } else {
          el.innerHTML = '<div class="surface-state-empty">no active surface instruments</div>';
          el.hidden = false;
        }
        return [];
      }
      el.hidden = false;
      el.innerHTML = items.map(surfaceStateHudHTML).join('');
      return items.map((item) => item.name);
    }

    function surfaceMetaFor(name) {
      const key = String(name || 'literal').toLowerCase();
      return SURFACE_META[key] || {
        name: key,
        summary: 'exposed parameter surface',
        detail: 'This chip marks a block surface that can be written literally, automated by control streams, or bent by an attractor.',
        use: `${key} = active behavior surface`,
        drivenBy: ['signal', 'score'],
      };
    }

    function surfaceAriaLabel(name) {
      const meta = surfaceMetaFor(name);
      return `${meta.name}: ${meta.summary}. Driven by ${meta.drivenBy.join(', ')}.`;
    }

    function ensureSurfaceTooltip() {
      let tooltip = document.getElementById('surface-tooltip');
      if (tooltip) return tooltip;

      tooltip = document.createElement('aside');
      tooltip.id = 'surface-tooltip';
      tooltip.className = 'surface-tooltip';
      tooltip.setAttribute('role', 'tooltip');
      tooltip.setAttribute('aria-hidden', 'true');
      document.body.appendChild(tooltip);
      return tooltip;
    }

    function surfaceTooltipHTML(name) {
      const meta = surfaceMetaFor(name);
      const label = escapeTooltipText(String(name || 'literal').toUpperCase());
      const chips = meta.drivenBy.map((item) => `<span>${escapeTooltipText(item)}</span>`).join('');
      const specs = [
        ['audio', meta.audio],
        ['range', meta.range],
        ['examples', Array.isArray(meta.examples) ? meta.examples.join(' / ') : meta.examples],
      ]
        .filter((item) => item[1])
        .map(([key, value]) => `<div class="surface-tooltip-spec"><strong>${escapeTooltipText(key)}</strong><span>${escapeTooltipText(value)}</span></div>`)
        .join('');

      return `
        <div class="surface-tooltip-stamp"><span class="surface-tooltip-mark" aria-hidden="true"></span> SURFACE / ${label}</div>
        <div class="surface-tooltip-title">${escapeTooltipText(meta.name)}</div>
        <div class="surface-tooltip-summary">${escapeTooltipText(meta.summary)}</div>
        <div class="surface-tooltip-detail">${escapeTooltipText(meta.detail)}</div>
        ${specs}
        <div class="surface-tooltip-use">${escapeTooltipText(meta.use)}</div>
        <div class="surface-tooltip-modulates"><strong>driven by</strong><div>${chips}</div></div>
      `;
    }

    function positionFloatingTooltip(tooltip, target, clientX, clientY) {
      if (!tooltip) return;

      const viewportPad = 12;
      const cursorGap = 16;
      const targetGap = 10;
      const shadowPad = 10;

      const targetRect = target && target.getBoundingClientRect
        ? target.getBoundingClientRect()
        : null;

      let anchorX = Number.isFinite(clientX) ? clientX : null;
      let anchorY = Number.isFinite(clientY) ? clientY : null;

      if ((anchorX === null || anchorY === null) && targetRect) {
        anchorX = targetRect.left + targetRect.width / 2;
        anchorY = targetRect.top + targetRect.height / 2;
      }

      if (anchorX === null) anchorX = window.innerWidth / 2;
      if (anchorY === null) anchorY = window.innerHeight / 2;

      tooltip.style.left = '0px';
      tooltip.style.top = '0px';

      const tooltipRect = tooltip.getBoundingClientRect();
      const tooltipWidth = tooltipRect.width || tooltip.offsetWidth || 304;
      const tooltipHeight = tooltipRect.height || tooltip.offsetHeight || 220;

      let left = anchorX + cursorGap;
      let top = anchorY + cursorGap;

      if (targetRect) {
        const preferRight = targetRect.right + targetGap + tooltipWidth + shadowPad <= window.innerWidth - viewportPad;
        const preferLeft = targetRect.left - targetGap - tooltipWidth - shadowPad >= viewportPad;

        if (preferRight) {
          left = targetRect.right + targetGap;
        } else if (preferLeft) {
          left = targetRect.left - targetGap - tooltipWidth;
        } else {
          left = anchorX - tooltipWidth / 2;
        }

        const below = targetRect.bottom + targetGap;
        const above = targetRect.top - targetGap - tooltipHeight;

        if (below + tooltipHeight + shadowPad <= window.innerHeight - viewportPad) {
          top = below;
        } else if (above >= viewportPad) {
          top = above;
        } else {
          top = anchorY + cursorGap;
        }
      }

      left = Math.max(
        viewportPad,
        Math.min(left, window.innerWidth - tooltipWidth - shadowPad - viewportPad)
      );

      top = Math.max(
        viewportPad,
        Math.min(top, window.innerHeight - tooltipHeight - shadowPad - viewportPad)
      );

      tooltip.style.left = `${Math.round(left)}px`;
      tooltip.style.top = `${Math.round(top)}px`;
    }

    function positionSignalTooltip(tooltip, target, clientX, clientY) {
      positionFloatingTooltip(tooltip, target, clientX, clientY);
    }

    function positionSurfaceTooltip(tooltip, target, clientX, clientY) {
      positionFloatingTooltip(tooltip, target, clientX, clientY);
    }

    function showSurfaceTooltip(target, clientX, clientY) {
      const name = target && target.dataset ? target.dataset.surface : '';
      if (!name) return;

      const tooltip = ensureSurfaceTooltip();
      tooltip.dataset.surface = name;
      tooltip.innerHTML = surfaceTooltipHTML(name);
      tooltip.setAttribute('aria-hidden', 'false');
      tooltip.classList.add('visible');
      target.setAttribute('aria-describedby', 'surface-tooltip');
      positionSurfaceTooltip(tooltip, target, clientX, clientY);
    }

    function hideSurfaceTooltip(target) {
      const tooltip = document.getElementById('surface-tooltip');
      if (!tooltip) return;

      tooltip.classList.remove('visible');
      tooltip.setAttribute('aria-hidden', 'true');
      if (target && target.removeAttribute) target.removeAttribute('aria-describedby');
    }

    function bindSurfaceTooltipEvents() {
      if (!transportVizEl) return;

      transportVizEl.addEventListener('mousemove', (event) => {
        const target = event.target.closest('.surface-chip[data-surface], .surface-hud[data-surface]');
        if (!target || !transportVizEl.contains(target)) return;
        showSurfaceTooltip(target, event.clientX, event.clientY);
      });

      transportVizEl.addEventListener('mouseleave', (event) => {
        hideSurfaceTooltip(event.target);
      });

      transportVizEl.addEventListener('focusin', (event) => {
        const target = event.target.closest('.surface-chip[data-surface], .surface-hud[data-surface]');
        if (!target || !transportVizEl.contains(target)) return;
        const rect = target.getBoundingClientRect();
        showSurfaceTooltip(target, rect.left + rect.width / 2, rect.top);
      });

      transportVizEl.addEventListener('focusout', (event) => {
        const target = event.target.closest('.surface-chip[data-surface], .surface-hud[data-surface]');
        if (target) hideSurfaceTooltip(target);
      });

      window.addEventListener('scroll', () => hideSurfaceTooltip(document.activeElement), true);
      window.addEventListener('resize', () => hideSurfaceTooltip(document.activeElement));
    }

    bindSurfaceTooltipEvents();
    bindSignalTooltipEvents();

    function renderSurfaceChips(el, surfaces, active, activeSurfaceNames) {
      if (!el) return;
      el.innerHTML = '';

      if (!surfaces || surfaces.length === 0) {
        const empty = document.createElement('span');
        empty.className = 'surface-chip';
        empty.textContent = 'literal';
        empty.dataset.surface = 'literal';
        empty.tabIndex = 0;
        empty.setAttribute('role', 'button');
        empty.setAttribute('aria-label', surfaceAriaLabel('literal'));
        el.appendChild(empty);
        return;
      }

      const activeSet = activeSurfaceNames instanceof Set ? activeSurfaceNames : new Set(activeSurfaceNames || []);
      for (const surface of surfaces) {
        const isActiveSurface = active || activeSet.has(surface);
        const chip = document.createElement('span');
        chip.className = 'surface-chip' + (isActiveSurface ? ' active' : '');
        chip.textContent = surface;
        chip.dataset.surface = surface;
        chip.tabIndex = 0;
        chip.setAttribute('role', 'button');
        chip.setAttribute('aria-label', surfaceAriaLabel(surface));
        el.appendChild(chip);
      }
    }

    function walkSlots(slots, fn) {
      if (!Array.isArray(slots)) return;
      for (const node of slots) {
        if (!node) continue;
        fn(node);
        if (node.kind === 'group') walkSlots(node.children, fn);
      }
    }

    function blockHasTokenKind(block, predicate) {
      let found = false;
      walkSlots(block && block.slots, (node) => {
        if (found || node.kind !== 'leaf') return;
        if (predicate(node.token)) found = true;
      });
      return found;
    }

    function surfacesForBlock(block) {
      const surfaces = [];
      if (!block) return surfaces;

      const params = block.params || {};
      const effects = block.effects || {};
      const push = (name) => {
        if (name && !surfaces.includes(name)) surfaces.push(name);
      };

      if (block.fade && block.fade.mode && block.fade.mode !== 'clear') push('fade');
      if (block.speed && (hasParamControlStream(block.speed) || block.speed.kind === 'vector')) push('speed');

        for (const name of ['pan', 'gain', 'rate', 'start', 'crush', 'resolution', 'variance', 'force', 'decay', 'tone', 'harm', 'octave', 'pedal', 'una', 'lid', 'sympathetic', 'release', 'human', 'stretch', 'layer', 'poly', 'articulation', 'sul', 'vibrato', 'vibratorate', 'vibratoonset', 'tremolo', 'tremolorate', 'bow', 'wood', 'mallet', 'deadstroke', 'roll', 'spread', 'motor', 'depth', 'damp', 'bowpressure', 'vowel', 'syllable', 'carrier', 'robot', 'breath', 'mouth', 'formant', 'roughness', 'vocoder', 'ensemble']) {
        if (hasParamControlStream(params[name])) push(name);
      }
      for (const name of ['opacity', 'threshold', 'edges', 'posterize', 'invert', 'contrast', 'saturate', 'displace', 'feedback', 'delay', 'slitscan', 'trail', 'mask', 'key', 'color', 'blend', 'monitor', 'listen']) {
        if (hasParamControlStream(params[name])) push(name);
      }

      for (const name of ['compress', 'space', 'resonance', 'comb', 'grain', 'chorus', 'excite', 'blur', 'scar', 'body']) {
        if (effects[name]) push(name);
      }

        if (block.voice === 'string' || block.voice === 'sine' || block.voice === 'osc' || block.voice === 'pluck' || block.voice === 'drone' || block.voice === 'piano' || block.voice === 'violin' || block.voice === 'cello' || block.voice === 'marimba' || block.voice === 'vibraphone' || block.voice === 'voice') {
        const hasRandomPitch = blockHasTokenKind(block, (tok) => tok && tok.kind === 'note-random');
        if (hasRandomPitch) push('pitch');
      }

      if (block.voice === 'sample') {
        const hasSelector = blockHasTokenKind(block, (tok) => {
          return tok && (tok.kind === 'sample-selector' || (tok.kind === 'sample' && tok.gated));
        });
        if (hasSelector) push('sample');
      }

      if (block.voice === 'drum') {
        push('kit');
        push('sample');
      }

      if (block.voice === 'marimba') {
        push('mallet');
        push('force');
        push('resonance');
        push('body');
        push('deadstroke');
        push('roll');
        push('spread');
        push('human');
      }

      if (block.voice === 'vibraphone') {
        push('articulation');
        push('pedal');
        push('motor');
        push('depth');
        push('damp');
        push('bowpressure');
        push('body');
        push('sympathetic');
        push('spread');
        push('human');
      }
        if (block.voice === 'voice') {
          push('vowel');
          push('syllable');
          push('carrier');
          push('robot');
          push('mouth');
          push('formant');
          push('breath');
          push('roughness');
          push('vocoder');
          push('ensemble');
          push('body');
          push('sympathetic');
        }
if (block.voice === 'video' || block.voice === 'video-gen') {
        for (const name of ['opacity', 'threshold', 'edges', 'posterize', 'invert', 'contrast', 'saturate', 'displace', 'feedback', 'delay', 'slitscan', 'trail', 'mask', 'key', 'color', 'blend', 'monitor', 'listen']) {
          if (params[name]) push(name);
        }
      }

      // Attractors color the medium even when patch values are literal.
      if (block.attractor) {
        push('filter');
        push('space');
        push('body');
        push('color');
        push('gain');
        push('pan');

          if (block.voice === 'string' || block.voice === 'sine' || block.voice === 'osc' || block.voice === 'pluck' || block.voice === 'drone' || block.voice === 'piano' || block.voice === 'violin' || block.voice === 'cello' || block.voice === 'marimba' || block.voice === 'vibraphone' || block.voice === 'voice') {
          push('decay');
          push('tone');
          push('crush');
          push('resolution');
          push('pitch');
          if (block.voice === 'piano') {
            push('pedal');
            push('sympathetic');
            push('body');
            push('lid');
          }
          if (block.voice === 'violin') {
            push('vibrato');
            push('bow');
            push('wood');
            push('sympathetic');
          }
          if (block.voice === 'cello') {
            push('articulation');
            push('sul');
            push('vibrato');
            push('bow');
            push('wood');
            push('sympathetic');
            push('release');
            push('human');
          }
          if (block.voice === 'vibraphone') {
            push('articulation');
            push('pedal');
            push('motor');
            push('depth');
            push('damp');
            push('bowpressure');
            push('body');
            push('sympathetic');
            push('spread');
            push('human');
          }
              if (block.voice === 'marimba') {
                push('mallet');
                push('force');
                push('resonance');
                push('body');
                push('deadstroke');
                push('roll');
                push('spread');
                push('human');
              }
        } else if (block.voice === 'noise' || block.voice === 'pulse') {
          push('decay');
          push('tone');
          push('crush');
          push('resolution');
          push('scar');
          push('grain');
        } else if (block.voice === 'sample' || block.voice === 'drum') {
          push('rate');
          push('start');
          push('crush');
          push('resolution');
          push('sample');
          if (block.voice === 'drum') {
            push('kit');
            push('variance');
          }
        } else if (block.voice === 'video' || block.voice === 'video-gen') {
          push('opacity');
          push('threshold');
          push('edges');
          push('feedback');
          push('trail');
          push('blend');
          push('color');
          push('monitor');
          push('listen');
        }

        if (block.speed) push('speed');
      }

      return surfaces;
    }

    function attractorStateForBlock(block) {
      if (!block || !block.attractor) return null;
      if (window.ReplAttractors && typeof window.ReplAttractors.peek === 'function') {
        try {
          return window.ReplAttractors.peek(block.attractor);
        } catch (_) {
          return null;
        }
      }
      return null;
    }

    function formatDecimal(v) {
      const n = Number(v);
      if (!Number.isFinite(n)) return '.00';
      const clamped = Math.max(0, Math.min(1, n));
      return clamped.toFixed(2).replace(/^0/, '');
    }

    function formatConfidence(state) {
      if (!state) return '';
      return `confidence ${formatDecimal(state.confidence)}`;
    }

    function formatSourceStatus(state) {
      if (!state) return '';
      const source = String(state.source || 'fallback');
      const confidence = formatConfidence(state);
      return `${source}${confidence ? ' · ' + confidence : ''}`;
    }

    function sourceClass(state) {
      if (!state) return '';
      if (String(state.status || '') === 'error') return 'source-error';
      return String(state.source || '') === 'live' ? 'source-live' : 'source-fallback';
    }

    function sourceLabelForBlock(block) {
      if (!block || !block.attractor) return '';
      const source = block.source || block.attractor.source || {};
      const parts = [];

      if (source.station) parts.push(source.station);
      if (source.feed) parts.push(source.feed);
      if (source.coords) parts.push(source.coords);
      if (source.city) parts.push(source.city);
      if (source.region) parts.push(source.region);
      if (source.body) parts.push(source.body);

      return parts.join(' · ');
    }

    function couplingLabel(block, state) {
      if (!block || !block.attractor) return 'none';
      const name = block.attractor.raw || 'attractor';
      const sourceLabel = sourceLabelForBlock(block);
      const status = block.voice === 'input' ? formatInputBlockStatus(block) : formatSourceStatus(state);
      return [name, sourceLabel, status].filter(Boolean).join(' · ');
    }

    function formatFadeLevel(v) {
      const n = Number(v);
      if (!Number.isFinite(n)) return '.00';
      return Math.max(0, Math.min(1, n)).toFixed(2).replace(/^0/, '');
    }

    function fadeLabel(block, fadeState) {
      if (!block || !block.fade || !block.fade.mode || block.fade.mode === 'clear') return '';
      const mode = block.fade.mode;

      if (!fadeState) {
        if (mode === 'hold') return 'fade hold';
        return `fade ${mode}`;
      }

      if (fadeState.held) return `fade hold · ${formatFadeLevel(fadeState.level)}`;

      if (fadeState.completed && fadeState.latched) {
        if (mode === 'in') return 'fade in · complete';
        if (mode === 'out') return 'fade out · latched';
      }

      return `fade ${mode} · ${formatFadeLevel(fadeState.level)}`;
    }

    function blockStatusLabel(block, attractorState, fadeState) {
      const parts = [];
      if (block && block.attractor) parts.push(couplingLabel(block, attractorState));
      const fade = fadeLabel(block, fadeState);
      if (fade) parts.push(fade);
      return parts.join(' · ');
    }

    function signalAriaLabel(abbr, value) {
      const meta = SIGNAL_META[abbr];
      if (!meta) return `Signal ${abbr}: ${formatDecimal(value)}`;
      return `${meta.name}: ${meta.summary}. Modulates ${meta.modulates.join(', ')}.`;
    }

    function signalHTML(state) {
      if (!state) return '';
      return SIGNALS.map(([abbr, key]) => {
        const value = Math.max(0, Math.min(1, Number(state[key]) || 0));
        const level = String(value.toFixed(3));
        const ariaLabel = signalAriaLabel(abbr, value).replace(/&/g, '&amp;').replace(/"/g, '&quot;');
        return `<span class="signal-token" style="--signal:${level}" data-signal="${abbr}" data-signal-value="${level}" tabindex="0" role="button" aria-label="${ariaLabel}"><abbr>${abbr}</abbr>${formatDecimal(value)}</span>`;
      }).join('');
    }
    
    function ensureSignalTooltip() {
      let tooltip = document.getElementById('signal-tooltip');
      if (tooltip) return tooltip;

      tooltip = document.createElement('aside');
      tooltip.id = 'signal-tooltip';
      tooltip.className = 'signal-tooltip';
      tooltip.setAttribute('role', 'tooltip');
      tooltip.setAttribute('aria-hidden', 'true');
      document.body.appendChild(tooltip);
      return tooltip;
    }

    function signalTooltipHTML(abbr, value) {
      const meta = SIGNAL_META[abbr] || {
        name: `Signal ${abbr}`,
        summary: 'live control signal',
        detail: 'This telemetry value is available as a live control source for coupled score behavior.',
        use: `${abbr} = live signal value`,
        modulates: ['surface'],
      };

      const label = escapeTooltipText(String(abbr || '?').toUpperCase());
      const displayValue = formatDecimal(value);
      const chips = (meta.modulates || ['surface'])
        .map((item) => `<span>${escapeTooltipText(item)}</span>`)
        .join('');

      return `
        <div class="signal-tooltip-stamp">
          <span class="signal-tooltip-mark" aria-hidden="true"></span>
          SIGNAL / ${label}
          <b>${escapeTooltipText(displayValue)}</b>
        </div>
        <div class="signal-tooltip-title">${escapeTooltipText(meta.name)}</div>
        <div class="signal-tooltip-summary">${escapeTooltipText(meta.summary)}</div>
        <div class="signal-tooltip-detail">${escapeTooltipText(meta.detail)}</div>
        <div class="signal-tooltip-use">${escapeTooltipText(meta.use)}</div>
        <div class="signal-tooltip-modulates"><strong>modulates</strong><div>${chips}</div></div>
      `;
    }

    function showSignalTooltip(target, clientX, clientY) {
      const abbr = target && target.dataset ? target.dataset.signal : '';
      if (!abbr) return;

      const value = Math.max(0, Math.min(1, Number(target.dataset.signalValue) || 0));
      const tooltip = ensureSignalTooltip();

      tooltip.dataset.signal = abbr;
      tooltip.innerHTML = signalTooltipHTML(abbr, value);
      tooltip.setAttribute('aria-hidden', 'false');
      tooltip.classList.add('visible');

      target.setAttribute('aria-describedby', 'signal-tooltip');
      positionSignalTooltip(tooltip, target, clientX, clientY);
    }

    function hideSignalTooltip(target) {
      const tooltip = document.getElementById('signal-tooltip');
      if (!tooltip) return;

      tooltip.classList.remove('visible');
      tooltip.setAttribute('aria-hidden', 'true');
      if (target && target.removeAttribute) target.removeAttribute('aria-describedby');
    }

    function bindSignalTooltipEvents() {
      if (!transportVizEl) return;

      transportVizEl.addEventListener('mousemove', (event) => {
        const target = event.target.closest('.signal-token[data-signal]');
        if (!target || !transportVizEl.contains(target)) return;
        showSignalTooltip(target, event.clientX, event.clientY);
      });

      transportVizEl.addEventListener('mouseleave', (event) => {
        hideSignalTooltip(event.target);
      });

      transportVizEl.addEventListener('focusin', (event) => {
        const target = event.target.closest('.signal-token[data-signal]');
        if (!target || !transportVizEl.contains(target)) return;
        const rect = target.getBoundingClientRect();
        showSignalTooltip(target, rect.left + rect.width / 2, rect.top);
      });

      transportVizEl.addEventListener('focusout', (event) => {
        const target = event.target.closest('.signal-token[data-signal]');
        if (target) hideSignalTooltip(target);
      });

      window.addEventListener('scroll', () => hideSignalTooltip(document.activeElement), true);
      window.addEventListener('resize', () => hideSignalTooltip(document.activeElement));
    }

    function primaryCoupledBlockState(t) {
      if (!t || !Array.isArray(t.blockStates)) return null;

      const live = t.blockStates.find((state) => {
        return state && state.attractor && state.attractorState && state.attractorState.source === 'live';
      });
      if (live) return live;

      return t.blockStates.find((state) => state && state.attractor) || null;
    }

    function blockFromStateIndex(index) {
      return lastGoodProgram && lastGoodProgram.blocks ? lastGoodProgram.blocks[index] : null;
    }

    function updateCouplingSummary(t) {
      if (!couplingSummaryEls) return;

      const state = primaryCoupledBlockState(t);
      if (!state) {
        couplingSummaryEls.couplingRow.hidden = true;
        couplingSummaryEls.signalsRow.hidden = true;
        couplingSummaryEls.surfacesRow.hidden = true;
        couplingSummaryEls.separator.hidden = true;
        return;
      }

      const block = blockFromStateIndex(state.blockIndex);
      const attractorState = state.attractorState || attractorStateForBlock(block);
      const surfaces = surfacesForBlock(block);

      couplingSummaryEls.couplingRow.hidden = false;
      couplingSummaryEls.signalsRow.hidden = false;
      couplingSummaryEls.surfacesRow.hidden = false;
      couplingSummaryEls.separator.hidden = false;

      couplingSummaryEls.couplingValue.textContent = couplingLabel(block, attractorState);
      couplingSummaryEls.couplingValue.className = 'coupling-value ' + sourceClass(attractorState);
      couplingSummaryEls.signalsValue.innerHTML = signalHTML(attractorState);
      renderSurfaceChips(couplingSummaryEls.surfacesValue, surfaces, false);
    }

    function renderTransportShell(program) {
      if (!beatDotsEl || !blockRowsEl) return;

      // Hide the entire beat row when the patch is in free-time mode (no
      // explicit tempo/meter) — there's nothing for it to count.
      const beatRowEl = beatDotsEl.closest('.beat-row');
      if (beatRowEl) beatRowEl.hidden = Boolean(program && program.freeTime);

      // Beat dots — one per beat in the meter.
      beatDotsEl.innerHTML = '';
      beatDotEls = [];
      const beats = program.meter.num;
      for (let i = 0; i < beats; i++) {
        const d = document.createElement('span');
        d.className = 'dot beat';
        d.title = `beat ${i + 1} of ${beats}`;
        d.setAttribute('aria-label', `beat ${i + 1}`);
        beatDotsEl.appendChild(d);
        beatDotEls.push(d);
      }

      // Block rows + coupling summary.
      blockRowsEl.innerHTML = '';
      blockRowEls = [];
      couplingSummaryEls = null;

      if (program.blocks.length === 0) {
        const empty = document.createElement('div');
        empty.className = 'empty-msg';
        empty.textContent = '(no voices yet — add a string, sine, drone, drum, pulse, noise, sample, or video line)';
        blockRowsEl.appendChild(empty);
        return;
      }

      const couplingRow = document.createElement('div');
      couplingRow.className = 'coupling-row';
      couplingRow.hidden = true;

      const couplingLabelEl = document.createElement('div');
      couplingLabelEl.className = 'coupling-label';
      couplingLabelEl.textContent = 'coupling';

      const couplingSpacer = document.createElement('div');
      couplingSpacer.className = 'slot-dots';

      const couplingValue = document.createElement('div');
      couplingValue.className = 'coupling-value';

      const couplingTail = document.createElement('div');

      couplingRow.appendChild(couplingLabelEl);
      couplingRow.appendChild(couplingSpacer);
      couplingRow.appendChild(couplingValue);
      couplingRow.appendChild(couplingTail);

      const signalsRow = document.createElement('div');
      signalsRow.className = 'coupling-row';
      signalsRow.hidden = true;

      const signalsLabel = document.createElement('div');
      signalsLabel.className = 'coupling-label';
      signalsLabel.textContent = 'signals';

      const signalsSpacer = document.createElement('div');

      const signalsValue = document.createElement('div');
      signalsValue.className = 'coupling-value';

      const signalsTail = document.createElement('div');

      signalsRow.appendChild(signalsLabel);
      signalsRow.appendChild(signalsSpacer);
      signalsRow.appendChild(signalsValue);
      signalsRow.appendChild(signalsTail);

      const surfacesRow = document.createElement('div');
      surfacesRow.className = 'coupling-row';
      surfacesRow.hidden = true;

      const surfacesLabel = document.createElement('div');
      surfacesLabel.className = 'coupling-label';
      surfacesLabel.textContent = 'surfaces';

      const surfacesSpacer = document.createElement('div');

      const surfacesValue = document.createElement('div');
      surfacesValue.className = 'surface-chips';

      const surfacesTail = document.createElement('div');

      surfacesRow.appendChild(surfacesLabel);
      surfacesRow.appendChild(surfacesSpacer);
      surfacesRow.appendChild(surfacesValue);
      surfacesRow.appendChild(surfacesTail);

      const separator = document.createElement('div');
      separator.className = 'coupling-separator';
      separator.hidden = true;

      blockRowsEl.appendChild(couplingRow);
      blockRowsEl.appendChild(signalsRow);
      blockRowsEl.appendChild(surfacesRow);
      blockRowsEl.appendChild(separator);

      couplingSummaryEls = {
        couplingRow,
        signalsRow,
        surfacesRow,
        separator,
        couplingValue,
        signalsValue,
        surfacesValue,
      };

      program.blocks.forEach((block) => {
        const row = document.createElement('div');
        row.className = 'block-row';

        const label = document.createElement('div');
        label.className = 'block-label';
        label.textContent = block.voice === 'input' && block.input
          ? `input ${block.input.kind}`
          : (block.voice === 'video-gen' ? 'video gen' : `${block.voice}`);

        const slotsWrap = document.createElement('div');
        slotsWrap.className = 'slot-dots';

        const slotEls = [];
        // Bars may hold different slot counts under the equal-time bar
        // protocol, so place separators using cumulative barSlotCounts
        // rather than every Nth slot.
        const barSlotCounts = Array.isArray(block.barSlotCounts) && block.barSlotCounts.length > 0
          ? block.barSlotCounts
          : [block.slots.length];
        const barEnds = new Set();
        let acc = 0;
        for (let b = 0; b < barSlotCounts.length - 1; b++) {
          acc += barSlotCounts[b];
          barEnds.add(acc);
        }
        for (let i = 0; i < block.slots.length; i++) {
          const dot = document.createElement('span');
          dot.className = 'dot ' + classifySlotForViz(block.slots[i]);
          dot.title = `slot ${i + 1} of ${block.slots.length}`;
          slotsWrap.appendChild(dot);
          slotEls.push(dot);

          if (barEnds.has(i + 1) && i + 1 < block.slots.length) {
            const sep = document.createElement('span');
            sep.style.width = '0';
            sep.style.borderLeft = '1px solid #aaa';
            sep.style.height = '0.9em';
            sep.style.margin = '0 2px';
            slotsWrap.appendChild(sep);
          }
        }

        const surfaceStateEl = document.createElement('div');
        surfaceStateEl.className = 'surface-state-stack block-surface-state';
        renderSurfaceStatePanel(surfaceStateEl, block, null);

        const couplingEl = document.createElement('div');
        couplingEl.className = 'block-coupling';
          const initialState = attractorStateForBlock(block);
          couplingEl.textContent = blockStatusLabel(block, initialState, null);
        const surfacesEl = document.createElement('div');
        surfacesEl.className = 'surface-chips';
        renderSurfaceChips(surfacesEl, surfacesForBlock(block), false);

        const everyEl = document.createElement('span');
        everyEl.className = 'silent-tag';
        everyEl.style.marginLeft = '0.6em';
        if (block.every) {
          everyEl.textContent = `every ${block.every.count} ${block.every.unit}`;
        }

        row.appendChild(label);
        row.appendChild(slotsWrap);
        row.appendChild(surfaceStateEl);
        row.appendChild(couplingEl);
        row.appendChild(surfacesEl);
        if (block.every) row.appendChild(everyEl);

        blockRowsEl.appendChild(row);
        blockRowEls.push({ row, slotEls, everyEl, couplingEl, surfacesEl, surfaceStateEl, block });
      });

      // Show any parsed/warmed attractor state even before play starts.
      updateCouplingSummary({
        blockStates: program.blocks.map((block, i) => ({
          blockIndex: i,
          attractor: block.attractor,
          attractorState: attractorStateForBlock(block),
        })),
      });
    }

    function clearActiveClasses() {
      if (transportVizEl) transportVizEl.dataset.running = 'false';
      for (const d of beatDotEls) {
        d.classList.remove('active');
        d.style.removeProperty('--beat-progress');
      }
      for (const blk of blockRowEls) {
        if (blk.row) blk.row.classList.remove('active', 'silent', 'live', 'fallback', 'muted', 'mute-pending');
        for (const d of blk.slotEls) d.classList.remove('active', 'live', 'fallback');
      }
    }

    function updateVisualizer() {
      if (!scheduler || !lastGoodProgram || !scheduler.isRunning()) {
        clearActiveClasses();
        if (lastGoodProgram) {
          updateCouplingSummary({
            blockStates: lastGoodProgram.blocks.map((block, i) => ({
              blockIndex: i,
              attractor: block.attractor,
              attractorState: attractorStateForBlock(block),
            })),
          });
        }
        return;
      }

      const t = scheduler.now();
      syncEditorBlockMuteLines();
      if (transportVizEl) {
        transportVizEl.dataset.running = 'true';
        transportVizEl.style.setProperty('--beat-progress', String(Math.max(0, Math.min(1, Number(t.beatProgress) || 0))));
      }

      // Beat dot: highlight whichever beat we're in, and expose beat progress for the light fill.
      const beatInBar = Number.isFinite(t.beatIndex) ? t.beatIndex : (Math.floor(t.beat) % lastGoodProgram.meter.num);
      for (let i = 0; i < beatDotEls.length; i++) {
        const active = i === beatInBar;
        beatDotEls[i].classList.toggle('active', active);
        if (active) {
          beatDotEls[i].style.setProperty('--beat-progress', String(Math.max(0, Math.min(1, Number(t.beatProgress) || 0))));
        } else {
          beatDotEls[i].style.removeProperty('--beat-progress');
        }
      }

      updateCouplingSummary(t);

      // Per-block: highlight currently-active slot and update coupling readouts.
      for (let i = 0; i < blockRowEls.length; i++) {
        const blk = blockRowEls[i];
        const state = t.blockStates[i];
        const block = lastGoodProgram.blocks[i];

        for (const d of blk.slotEls) d.classList.remove('active', 'live', 'fallback');
        if (blk.row) blk.row.classList.remove('active', 'silent', 'live', 'fallback', 'muted', 'mute-pending');
        if (!state || !block) continue;

        const attractorState = state.attractorState || attractorStateForBlock(block);
        const isMuted = Boolean(state.muted);
        if (blk.row) {
          blk.row.classList.toggle('silent', Boolean(state.silent) || isMuted);
          blk.row.classList.toggle('muted', isMuted);
          blk.row.classList.toggle('mute-pending', Boolean(state.mutePending));
          blk.row.classList.toggle('active', !state.silent && !isMuted && state.inBlockIdx >= 0);
          blk.row.classList.toggle('live', Boolean(attractorState && attractorState.source === 'live'));
          blk.row.classList.toggle('fallback', Boolean(attractorState && attractorState.source && attractorState.source !== 'live'));
        }
        if (blk.couplingEl) {
            blk.couplingEl.textContent = blockStatusLabel(block, attractorState, state.fadeState);
            blk.couplingEl.className = 'block-coupling ' + sourceClass(attractorState);
        }

        if (blk.surfaceStateEl) {
          renderSurfaceStatePanel(blk.surfaceStateEl, block, state.surfaceState || null);
        }

        if (blk.surfacesEl) {
            renderSurfaceChips(
              blk.surfacesEl,
              surfacesForBlock(block),
              Boolean(
                (!state.silent && !isMuted && state.inBlockIdx >= 0) ||
                block.attractor ||
                (block.effects && Object.keys(block.effects).length) ||
                (block.fade && block.fade.mode && block.fade.mode !== 'clear')
              )
            );
        }

        if (blk.everyEl) {
          if (isMuted || state.silent) {
            blk.everyEl.style.color = '#bbb';
          } else if (state.every) {
            blk.everyEl.style.color = '#0000cc';
          }
        }

        if (!state.silent && !isMuted && state.inBlockIdx >= 0 && state.inBlockIdx < blk.slotEls.length) {
          const activeDot = blk.slotEls[state.inBlockIdx];
          activeDot.classList.add('active');

          if (attractorState && attractorState.source === 'live') {
            activeDot.classList.add('live');
          } else if (attractorState) {
            activeDot.classList.add('fallback');
          }
        }
      }
    }

    function vizFrame() {
      try {
        updateVisualizer();
      } catch (err) {
        // Keep the transport sidebar alive even if an unexpected program state slips through.
        if (!vizFrame._lastWarn || performance.now() - vizFrame._lastWarn > 1500) {
          vizFrame._lastWarn = performance.now();
          // eslint-disable-next-line no-console
          console.warn('[repl transport viz] update failed:', err);
        }
      } finally {
        requestAnimationFrame(vizFrame);
      }
    }
    requestAnimationFrame(vizFrame);



  // ---------------- live input panel ----------------

  function inputKind() {
    return inputKindSelect ? String(inputKindSelect.value || 'mic') : 'mic';
  }

  function formatInputBlockStatus(block) {
    if (!window.InputVoice || !window.InputVoice.getState || !block || !block.input) return 'input unavailable';
    const state = window.InputVoice.getState()[block.input.kind] || null;
    if (!state) return `${block.input.kind} disconnected`;
    if (state.status === 'live') return `${block.input.kind} live · ${state.label || 'audio input'}`;
    if (state.status === 'requesting') return `${block.input.kind} requesting permission`;
    if (state.status === 'error') return `${block.input.kind} error · ${state.error || 'permission failed'}`;
    return `${block.input.kind} disconnected`;
  }

  function renderInputPanelState(snapshot) {
    if (!inputStatusEl || !inputMeterFill) return;
    const kind = inputKind();
    const state = snapshot && snapshot[kind] ? snapshot[kind] : null;

    if (!state) {
      inputStatusEl.textContent = 'input unavailable';
      inputStatusEl.className = 'input-status source-error';
      inputMeterFill.style.width = '0%';
      return;
    }

    const pieces = [kind, state.status];
    if (state.label && state.status === 'live') pieces.push(state.label);
    if (state.error && state.status === 'error') pieces.push(state.error);
    inputStatusEl.textContent = pieces.join(' · ');
    inputStatusEl.className = 'input-status ' + (state.status === 'live' ? 'source-live' : state.status === 'error' ? 'source-error' : 'source-fallback');
    inputMeterFill.style.width = `${Math.round(Math.max(0, Math.min(1, Number(state.level) || 0)) * 100)}%`;
  }


  function inputKindsForProgram(program) {
    const kinds = new Set();
    const blocks = program && Array.isArray(program.blocks) ? program.blocks : [];
    for (const block of blocks) {
      if (!block || block.voice !== 'input' || !block.input || !block.input.kind) continue;
      kinds.add(String(block.input.kind).toLowerCase());
    }
    return Array.from(kinds).filter(Boolean);
  }

  async function armInputsForProgram(program) {
    const kinds = inputKindsForProgram(program);
    if (!kinds.length) return true;

    if (!window.InputVoice || !window.InputVoice.enable) {
      showWarning('this patch uses input, but the live input module is unavailable');
      return false;
    }

    if (!scheduler) bootScheduler();
    const audioCtx = window.StringVoice && window.StringVoice.ensureAudio ? window.StringVoice.ensureAudio() : null;
    if (!audioCtx) {
      showWarning('this browser does not support Web Audio input');
      return false;
    }

    setInputPanelOpen(true);

    const state = window.InputVoice.getState ? window.InputVoice.getState() : {};
    for (const kind of kinds) {
      if (state[kind] && state[kind].status === 'live') continue;

      if (inputKindSelect) {
        inputKindSelect.value = kind;
        if (inputDeviceSelect) inputDeviceSelect.disabled = kind === 'tab';
        if (inputEnableBtn) inputEnableBtn.textContent = kind === 'tab' ? 'capture tab audio' : 'enable audio input';
      }

      const deviceId = inputDeviceSelect && kind !== 'tab' ? inputDeviceSelect.value : '';
      try {
        showWarning(kind === 'tab' ? 'choose a tab and enable audio to play this patch' : 'allow audio input to play this patch');
        await window.InputVoice.enable(kind, { audioCtx, deviceId });
        if (kind !== 'tab') await refreshInputDevices();
        clearErrors();
      } catch (err) {
        showWarning(err && err.message ? err.message : `could not enable ${kind} input`);
        return false;
      }
    }

    return true;
  }

  function videoSourcesForProgram(program) {
    const kinds = new Set();
    const blocks = program && Array.isArray(program.blocks) ? program.blocks : [];
    for (const block of blocks) {
      if (!block || (block.voice !== 'video' && block.voice !== 'video-gen')) continue;
      const source = block.voice === 'video-gen'
        ? (block.videoGen && block.videoGen.source ? String(block.videoGen.source).toLowerCase() : 'camera')
        : (block.video && block.video.kind ? String(block.video.kind).toLowerCase() : 'camera');
      if (source === 'tab') kinds.add('screen');
      else if (source === 'camera' || source === 'screen' || source === 'file') kinds.add(source);
      else if (source === 'gen' || source.startsWith('vgen-')) {
        // local generated clips do not need capture permissions
      } else {
        kinds.add('camera');
      }
    }
    return Array.from(kinds);
  }

  async function armVideoForProgram(program) {
    const sources = videoSourcesForProgram(program);
    if (!sources.length) return true;
    if (!videoDebugEnabled()) {
      showWarning('video blocks are disabled (enable with ?debug-video=1)');
      return false;
    }
    if (!window.VideoVoice || !window.VideoVoice.enableSource) {
      showWarning('this patch uses video, but the video module is unavailable');
      return false;
    }

    if (videoPanel) videoPanel.hidden = false;
    if (videoToggleBtn) videoToggleBtn.setAttribute('aria-expanded', 'true');

    if (window.VideoVoice.setStageCanvas && videoStageCanvas) {
      window.VideoVoice.setStageCanvas(videoStageCanvas);
    }

    for (const source of sources) {
      if (source === 'file') {
        if (videoKindSelect) videoKindSelect.value = 'file';
        if (videoFileWrap) videoFileWrap.hidden = false;
        showWarning('choose a file in the video panel to arm video file source');
        continue;
      }
      try {
        await window.VideoVoice.enableSource(source, {});
      } catch (err) {
        showWarning(err && err.message ? err.message : `could not enable ${source} video source`);
        return false;
      }
    }
    refreshVideoStatus();
    return true;
  }

  async function refreshInputDevices() {
    if (!inputDeviceSelect || !window.InputVoice || !window.InputVoice.listDevices) return;
    const current = inputDeviceSelect.value;
    const devices = await window.InputVoice.listDevices();
    inputDeviceSelect.innerHTML = '';

    const def = document.createElement('option');
    def.value = '';
    def.textContent = 'default';
    inputDeviceSelect.appendChild(def);

    for (const device of devices) {
      const opt = document.createElement('option');
      opt.value = device.deviceId || '';
      opt.textContent = device.label || 'audio input';
      inputDeviceSelect.appendChild(opt);
    }

    if (current && Array.from(inputDeviceSelect.options).some((opt) => opt.value === current)) {
      inputDeviceSelect.value = current;
    }
  }

  function setOutputPanelStatus(text, className) {
    if (!outputStatusEl) return;
    outputStatusEl.textContent = text || 'output · system default';
    outputStatusEl.className = `input-status ${className || 'source-fallback'}`;
  }

  function outputDeviceLabelById(deviceId) {
    if (!deviceId) return 'system default';
    if (!outputDeviceSelect) return 'selected output';
    const match = Array.from(outputDeviceSelect.options).find((opt) => opt.value === deviceId);
    return match ? String(match.textContent || 'selected output') : 'selected output';
  }

  async function refreshOutputDevices() {
    if (!outputDeviceSelect || !outputApplyBtn || !outputRefreshBtn) return;
    if (!window.StringVoice) {
      outputDeviceSelect.disabled = true;
      outputApplyBtn.disabled = true;
      outputRefreshBtn.disabled = true;
      setOutputPanelStatus('output unavailable', 'source-error');
      return;
    }

    const supported = window.StringVoice.outputRoutingSupported
      ? window.StringVoice.outputRoutingSupported() === true
      : false;

    const previous = outputDeviceSelect.value;
    outputDeviceSelect.innerHTML = '';

    const defaultOpt = document.createElement('option');
    defaultOpt.value = '';
    defaultOpt.textContent = 'system default';
    outputDeviceSelect.appendChild(defaultOpt);

    if (!supported || !window.StringVoice.listOutputDevices || !window.StringVoice.getOutputRoutingState) {
      outputDeviceSelect.disabled = true;
      outputApplyBtn.disabled = true;
      outputRefreshBtn.disabled = true;
      setOutputPanelStatus('output selection unsupported in this browser', 'source-fallback');
      return;
    }

    let devices = [];
    try {
      devices = await window.StringVoice.listOutputDevices();
    } catch (_) {
      devices = [];
    }

    for (const device of devices) {
      if (!device || !device.deviceId) continue;
      if (String(device.deviceId) === 'default') continue;
      const opt = document.createElement('option');
      opt.value = String(device.deviceId);
      const label = String(device.label || '').trim();
      opt.textContent = label || 'audio output';
      outputDeviceSelect.appendChild(opt);
    }

    const state = window.StringVoice.getOutputRoutingState();
    const sinkId = state && typeof state.sinkId === 'string' ? state.sinkId : '';
    const hasSinkOption = Array.from(outputDeviceSelect.options).some((opt) => opt.value === sinkId);
    const hasPreviousOption = Array.from(outputDeviceSelect.options).some((opt) => opt.value === previous);
    outputDeviceSelect.value = hasSinkOption ? sinkId : (hasPreviousOption ? previous : '');

    outputDeviceSelect.disabled = false;
    outputApplyBtn.disabled = false;
    outputRefreshBtn.disabled = false;

    if (state && state.error) {
      setOutputPanelStatus(`output error · ${state.error}`, 'source-error');
      return;
    }
    if (outputDeviceSelect.options.length <= 1 && !sinkId) {
      setOutputPanelStatus('output · system default (enable input permission to list more devices)', 'source-fallback');
      return;
    }
    setOutputPanelStatus(`output · ${outputDeviceLabelById(outputDeviceSelect.value)}`, sinkId ? 'source-live' : 'source-fallback');
  }

  async function applySelectedOutputDevice() {
    if (!outputDeviceSelect || !window.StringVoice || !window.StringVoice.setOutputDevice) {
      setOutputPanelStatus('output routing unavailable', 'source-error');
      return;
    }

    if (!scheduler) bootScheduler();
    if (window.StringVoice.resume) {
      try { await window.StringVoice.resume(); } catch (_) {}
    }

    const target = String(outputDeviceSelect.value || '');
    try {
      await window.StringVoice.setOutputDevice(target);
      setOutputPanelStatus(`output · ${outputDeviceLabelById(target)}`, target ? 'source-live' : 'source-fallback');
      clearErrors();
    } catch (err) {
      const message = err && err.message ? err.message : 'could not switch output device';
      showWarning(message);
      setOutputPanelStatus(`output error · ${message}`, 'source-error');
    }
  }

  async function enableSelectedInput() {
    if (!window.InputVoice || !window.InputVoice.enable) {
      showWarning('live input module is unavailable');
      return;
    }

    if (!scheduler) bootScheduler();
    const audioCtx = window.StringVoice && window.StringVoice.ensureAudio ? window.StringVoice.ensureAudio() : null;
    const kind = inputKind();
    const deviceId = inputDeviceSelect && kind !== 'tab' ? inputDeviceSelect.value : '';

    try {
      await window.InputVoice.enable(kind, { audioCtx, deviceId });
      await refreshInputDevices();
      clearErrors();
    } catch (err) {
      showWarning(err && err.message ? err.message : 'input permission failed');
    }
  }

  function stopSelectedInput() {
    if (!window.InputVoice || !window.InputVoice.stop) return;
    window.InputVoice.stop(inputKind());
  }

  function setInputPanelOpen(shouldOpen) {
    if (!inputToggleBtn || !inputPanel) return;
    const open = Boolean(shouldOpen);
    inputPanel.hidden = !open;
    inputToggleBtn.setAttribute('aria-expanded', String(open));
    if (open) {
      refreshInputDevices();
      refreshOutputDevices();
    }
  }

  function toggleInputPanel(forceState) {
    if (!inputToggleBtn || !inputPanel) return;
    if (typeof forceState === 'boolean') {
      setInputPanelOpen(forceState);
      return;
    }
    setInputPanelOpen(inputPanel.hidden);
  }

  function bindInputPanel() {
    if (!inputToggleBtn || !inputPanel) return;

    inputToggleBtn.addEventListener('click', () => toggleInputPanel());

    if (inputKindSelect) {
      inputKindSelect.addEventListener('change', () => {
        const kind = inputKind();
        if (inputDeviceSelect) inputDeviceSelect.disabled = kind === 'tab';
        if (inputEnableBtn) inputEnableBtn.textContent = kind === 'tab' ? 'capture tab audio' : 'enable audio input';
        renderInputPanelState(window.InputVoice && window.InputVoice.getState ? window.InputVoice.getState() : null);
      });
    }

    if (inputEnableBtn) inputEnableBtn.addEventListener('click', enableSelectedInput);
    if (inputStopBtn) inputStopBtn.addEventListener('click', stopSelectedInput);
    if (outputApplyBtn) outputApplyBtn.addEventListener('click', applySelectedOutputDevice);
    if (outputRefreshBtn) outputRefreshBtn.addEventListener('click', refreshOutputDevices);

    if (window.InputVoice && window.InputVoice.onStateChange) {
      window.InputVoice.onStateChange(renderInputPanelState);
    }

    if (!mediaDeviceChangeBound && navigator.mediaDevices && typeof navigator.mediaDevices.addEventListener === 'function') {
      navigator.mediaDevices.addEventListener('devicechange', () => {
        refreshInputDevices();
        refreshOutputDevices();
      });
      mediaDeviceChangeBound = true;
    }

    refreshInputDevices();
    refreshOutputDevices();
  }

  function selectedVideoKind() {
    return videoKindSelect ? String(videoKindSelect.value || 'camera') : 'camera';
  }

  function refreshVideoStatus() {
    if (!videoDebugEnabled()) return;
    if (!videoStatusEl) return;
    if (!window.VideoVoice || !window.VideoVoice.getState) {
      videoStatusEl.textContent = 'video unavailable';
      videoStatusEl.className = 'input-status source-error';
      return;
    }
    const snap = window.VideoVoice.getState();
    const kind = selectedVideoKind();
    const state = snap && snap.sources ? snap.sources[kind] : null;
    if (!state) {
      videoStatusEl.textContent = 'idle';
      videoStatusEl.className = 'input-status source-fallback';
      return;
    }
    const bits = [kind, state.status];
    if (state.label && state.status === 'live') bits.push(state.label);
    if (state.error && state.status === 'error') bits.push(state.error);
    videoStatusEl.textContent = bits.join(' · ');
    videoStatusEl.className = 'input-status ' + (state.status === 'live' ? 'source-live' : state.status === 'error' ? 'source-error' : 'source-fallback');
  }

  async function enableSelectedVideoSource() {
    if (!videoDebugEnabled()) return;
    if (!window.VideoVoice || !window.VideoVoice.enableSource) {
      showWarning('video module is unavailable');
      return;
    }
    if (!scheduler) bootScheduler();
    const kind = selectedVideoKind();
    if (kind === 'file') {
      const file = videoFileInput && videoFileInput.files ? videoFileInput.files[0] : null;
      if (!file) {
        showWarning('choose a video file first');
        return;
      }
      try {
        window.VideoVoice.attachFile(file);
        clearErrors();
      } catch (err) {
        showWarning(err && err.message ? err.message : 'video file load failed');
      }
      refreshVideoStatus();
      return;
    }

    try {
      await window.VideoVoice.enableSource(kind, {});
      clearErrors();
    } catch (err) {
      showWarning(err && err.message ? err.message : `could not enable ${kind} video source`);
    }
    refreshVideoStatus();
  }

  function stopSelectedVideoSource() {
    if (!videoDebugEnabled()) return;
    if (!window.VideoVoice || !window.VideoVoice.stopSource) return;
    window.VideoVoice.stopSource(selectedVideoKind());
    refreshVideoStatus();
  }

  function toggleVideoPanel(forceOpen) {
    if (!videoDebugEnabled()) return;
    if (!videoPanel || !videoToggleBtn) return;
    const next = forceOpen == null ? videoPanel.hidden : Boolean(forceOpen);
    videoPanel.hidden = !next;
    videoToggleBtn.setAttribute('aria-expanded', String(next));
    if (next && window.VideoVoice && window.VideoVoice.setStageCanvas && videoStageCanvas) {
      window.VideoVoice.setStageCanvas(videoStageCanvas);
    }
    refreshVideoStatus();
  }

  function bindVideoPanel() {
    if (!videoDebugEnabled()) return;
    if (!videoPanel || !videoToggleBtn) return;
    videoToggleBtn.addEventListener('click', () => toggleVideoPanel());
    if (videoKindSelect) {
      videoKindSelect.addEventListener('change', () => {
        const kind = selectedVideoKind();
        if (videoFileWrap) videoFileWrap.hidden = kind !== 'file';
        if (window.VideoVoice && window.VideoVoice.setSourcePreference) {
          window.VideoVoice.setSourcePreference(kind);
        }
        refreshVideoStatus();
      });
    }
    if (videoEnableBtn) videoEnableBtn.addEventListener('click', enableSelectedVideoSource);
    if (videoStopBtn) videoStopBtn.addEventListener('click', stopSelectedVideoSource);
    if (videoFileInput) {
      videoFileInput.addEventListener('change', () => {
        if (selectedVideoKind() !== 'file') return;
        enableSelectedVideoSource();
      });
    }
    if (videoPopoutBtn) {
      videoPopoutBtn.addEventListener('click', () => {
        if (!window.VideoVoice || !window.VideoVoice.openFloatingStageWindow) return;
        const ok = window.VideoVoice.openFloatingStageWindow();
        if (!ok) showWarning('popup blocked — allow popups to detach stage');
      });
    }
    refreshVideoStatus();
  }

  // ---------------- samples browse panel ----------------

  let samplesGroupsCache = null;
  let samplesPanelRendered = false;

  function sampleVoiceSupportsOverlay() {
    return Boolean(
      window.SampleVoice
      && typeof window.SampleVoice.setOverlayBank === 'function'
      && typeof window.SampleVoice.clearOverlayBank === 'function'
    );
  }

  function canUseLocalSampleFolders() {
    return typeof window.showDirectoryPicker === 'function'
      && typeof window.indexedDB !== 'undefined'
      && sampleVoiceSupportsOverlay();
  }

  function invalidateSamplesPanel() {
    samplesGroupsCache = null;
    samplesPanelRendered = false;
  }

  function refreshSamplesPanelIfOpen() {
    if (!samplesPanel || samplesPanel.hasAttribute('hidden')) return;
    renderSamplesPanel(samplesFilterInput ? samplesFilterInput.value : '');
  }

  function setLocalSamplesStatus(text) {
    if (!samplesLocalStatus) return;
    samplesLocalStatus.textContent = text || '';
  }

  function updateLocalSamplesControls() {
    const supported = canUseLocalSampleFolders();
    const busy = localSamplesBusy;
    if (samplesLinkBtn) samplesLinkBtn.disabled = !supported || busy;
    if (samplesRelinkBtn) samplesRelinkBtn.disabled = !supported || busy;
    if (samplesUnlinkBtn) samplesUnlinkBtn.disabled = !supported || busy || !localSamplesDirHandle;
  }

  function revokeLocalSampleObjectUrls() {
    for (const url of localSampleObjectUrls) {
      if (!url) continue;
      try { URL.revokeObjectURL(url); } catch (_) {}
    }
    localSampleObjectUrls = [];
  }

  function clearLocalSampleOverlay() {
    revokeLocalSampleObjectUrls();
    if (sampleVoiceSupportsOverlay()) {
      window.SampleVoice.clearOverlayBank();
    }
    invalidateSamplesPanel();
    refreshSamplesPanelIfOpen();
  }

  async function openLocalSamplesDb() {
    if (typeof window.indexedDB === 'undefined') return null;
    if (localSamplesDbPromise) return localSamplesDbPromise;

    localSamplesDbPromise = new Promise((resolve, reject) => {
      const req = window.indexedDB.open(LOCAL_SAMPLES_DB_NAME, LOCAL_SAMPLES_DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(LOCAL_SAMPLES_STORE)) {
          db.createObjectStore(LOCAL_SAMPLES_STORE);
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error || new Error('could not open local samples database'));
      req.onblocked = () => reject(new Error('local samples database is blocked'));
    }).catch((err) => {
      localSamplesDbPromise = null;
      throw err;
    });

    return localSamplesDbPromise;
  }

  async function readSavedSamplesHandle() {
    const db = await openLocalSamplesDb();
    if (!db) return null;
    return new Promise((resolve, reject) => {
      const tx = db.transaction(LOCAL_SAMPLES_STORE, 'readonly');
      const store = tx.objectStore(LOCAL_SAMPLES_STORE);
      const req = store.get(LOCAL_SAMPLES_HANDLE_KEY);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => reject(req.error || new Error('could not read local sample folder handle'));
      tx.onabort = () => reject(tx.error || new Error('local samples read transaction aborted'));
    });
  }

  async function saveSamplesHandle(handle) {
    const db = await openLocalSamplesDb();
    if (!db) return;
    await new Promise((resolve, reject) => {
      const tx = db.transaction(LOCAL_SAMPLES_STORE, 'readwrite');
      const store = tx.objectStore(LOCAL_SAMPLES_STORE);
      const req = store.put(handle, LOCAL_SAMPLES_HANDLE_KEY);
      req.onerror = () => reject(req.error || new Error('could not save local sample folder handle'));
      tx.oncomplete = () => resolve();
      tx.onabort = () => reject(tx.error || new Error('local samples write transaction aborted'));
    });
  }

  async function deleteSavedSamplesHandle() {
    const db = await openLocalSamplesDb();
    if (!db) return;
    await new Promise((resolve, reject) => {
      const tx = db.transaction(LOCAL_SAMPLES_STORE, 'readwrite');
      const store = tx.objectStore(LOCAL_SAMPLES_STORE);
      const req = store.delete(LOCAL_SAMPLES_HANDLE_KEY);
      req.onerror = () => reject(req.error || new Error('could not delete local sample folder handle'));
      tx.oncomplete = () => resolve();
      tx.onabort = () => reject(tx.error || new Error('local samples delete transaction aborted'));
    });
  }

  async function queryReadPermission(handle) {
    if (!handle || typeof handle.queryPermission !== 'function') return 'denied';
    try {
      const state = await handle.queryPermission({ mode: 'read' });
      if (state === 'granted' || state === 'prompt' || state === 'denied') return state;
      return 'denied';
    } catch (_) {
      return 'denied';
    }
  }

  async function requestReadPermission(handle) {
    if (!handle || typeof handle.requestPermission !== 'function') return 'denied';
    try {
      const state = await handle.requestPermission({ mode: 'read' });
      if (state === 'granted' || state === 'prompt' || state === 'denied') return state;
      return 'denied';
    } catch (_) {
      return 'denied';
    }
  }

  function isAudioFilename(name) {
    const raw = String(name || '');
    const idx = raw.lastIndexOf('.');
    if (idx <= 0 || idx >= raw.length - 1) return false;
    const ext = raw.slice(idx + 1).toLowerCase();
    return LOCAL_SAMPLES_EXTENSIONS.has(ext);
  }

  async function collectAudioFilesRecursive(dirHandle, pathParts, out) {
    for await (const entry of dirHandle.values()) {
      if (!entry || !entry.name) continue;
      if (entry.kind === 'directory') {
        await collectAudioFilesRecursive(entry, pathParts.concat([entry.name]), out);
        continue;
      }
      if (entry.kind !== 'file' || !isAudioFilename(entry.name)) continue;
      const file = await entry.getFile();
      if (!file) continue;
      out.push({
        relPath: pathParts.concat([entry.name]).join('/'),
        file,
      });
    }
  }

  function slugifyLocalSamplePath(relPath) {
    const lowered = String(relPath || '').toLowerCase().replace(/\\/g, '/');
    const noExt = lowered.replace(/\.[^./]+$/, '');
    const slug = noExt
      .replace(/[^a-z0-9_-]+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^[-_]+|[-_]+$/g, '');
    return slug || 'sample';
  }

  function buildLocalOverlayFromFiles(files) {
    const sorted = files.slice().sort((a, b) => String(a.relPath || '').localeCompare(String(b.relPath || '')));
    const used = new Set();
    const samples = [];
    const groupSamples = [];
    const createdUrls = [];

    for (const item of sorted) {
      if (!item || !item.file) continue;
      const base = `local-${slugifyLocalSamplePath(item.relPath)}`;
      let name = base;
      let suffix = 2;
      while (used.has(name)) {
        name = `${base}-${suffix}`;
        suffix += 1;
      }
      used.add(name);
      const url = URL.createObjectURL(item.file);
      createdUrls.push(url);
      samples.push({
        name,
        url,
        file: item.file.name || '',
        source: `local:${item.relPath}`,
        group: LOCAL_SAMPLE_GROUP_ID,
      });
      groupSamples.push(name);
    }

    const groups = groupSamples.length
      ? [{ id: LOCAL_SAMPLE_GROUP_ID, label: LOCAL_SAMPLE_GROUP_LABEL, samples: groupSamples }]
      : [];

    return { samples, groups, createdUrls };
  }

  async function applyLocalSamplesFromHandle(handle, options) {
    if (!canUseLocalSampleFolders() || !handle) return false;
    const opts = options && typeof options === 'object' ? options : {};
    const requireGranted = Boolean(opts.requireGranted);
    const statusWhenPrompt = opts.statusWhenPrompt || 'local folder saved — click relink to grant access';
    const statusPrefix = opts.statusPrefix || 'local folder';

    const permission = await queryReadPermission(handle);
    if (permission === 'denied') {
      clearLocalSampleOverlay();
      localSamplesDirHandle = handle;
      setLocalSamplesStatus(`${statusPrefix} access denied — relink to grant access`);
      updateLocalSamplesControls();
      return false;
    }
    if (permission !== 'granted') {
      if (requireGranted) {
        const requested = await requestReadPermission(handle);
        if (requested !== 'granted') {
          clearLocalSampleOverlay();
          localSamplesDirHandle = handle;
          setLocalSamplesStatus(statusWhenPrompt);
          updateLocalSamplesControls();
          return false;
        }
      } else {
        clearLocalSampleOverlay();
        localSamplesDirHandle = handle;
        setLocalSamplesStatus(statusWhenPrompt);
        updateLocalSamplesControls();
        return false;
      }
    }

    const files = [];
    await collectAudioFilesRecursive(handle, [], files);
    const overlay = buildLocalOverlayFromFiles(files);
    clearLocalSampleOverlay();
    localSampleObjectUrls = overlay.createdUrls;
    window.SampleVoice.setOverlayBank({
      samples: overlay.samples,
      groups: overlay.groups,
    });
    localSamplesDirHandle = handle;
    invalidateSamplesPanel();
    refreshSamplesPanelIfOpen();
    setLocalSamplesStatus(`${statusPrefix}: ${overlay.samples.length} loaded`);
    updateLocalSamplesControls();
    return true;
  }

  function setLocalSamplesBusy(nextBusy) {
    localSamplesBusy = Boolean(nextBusy);
    updateLocalSamplesControls();
  }

  async function chooseLocalSamplesFolder() {
    if (typeof window.showDirectoryPicker !== 'function') return null;
    return window.showDirectoryPicker({ id: 'repl-samples', mode: 'read' });
  }

  async function linkLocalSamplesFolder() {
    if (!canUseLocalSampleFolders()) return;
    setLocalSamplesBusy(true);
    setLocalSamplesStatus('linking local folder...');
    try {
      const handle = await chooseLocalSamplesFolder();
      if (!handle) {
        setLocalSamplesStatus('local folder link canceled');
        return;
      }
      const linked = await applyLocalSamplesFromHandle(handle, {
        requireGranted: true,
        statusPrefix: `local folder "${handle.name || 'linked'}"`,
      });
      if (linked) {
        try {
          await saveSamplesHandle(handle);
        } catch (err) {
          showWarning(err && err.message ? err.message : 'could not persist local sample folder link');
          setLocalSamplesStatus(`local folder "${handle.name || 'linked'}" loaded (not persisted)`);
        }
      }
    } catch (err) {
      const name = err && err.name ? String(err.name) : '';
      if (name === 'AbortError') {
        setLocalSamplesStatus('local folder link canceled');
      } else {
        showWarning(err && err.message ? err.message : 'could not link local sample folder');
        setLocalSamplesStatus('local folder link failed');
      }
    } finally {
      setLocalSamplesBusy(false);
    }
  }

  async function unlinkLocalSamplesFolder() {
    setLocalSamplesBusy(true);
    try {
      clearLocalSampleOverlay();
      localSamplesDirHandle = null;
      if (canUseLocalSampleFolders()) {
        try {
          await deleteSavedSamplesHandle();
        } catch (err) {
          showWarning(err && err.message ? err.message : 'could not clear saved local sample folder');
        }
      }
      setLocalSamplesStatus('local folder unlinked');
    } finally {
      setLocalSamplesBusy(false);
    }
  }

  async function initLocalSamplesFromSavedHandle() {
    if (!canUseLocalSampleFolders()) {
      if (!sampleVoiceSupportsOverlay()) {
        setLocalSamplesStatus('local folder samples unavailable in this build');
      } else {
        setLocalSamplesStatus('local folder linking not supported in this browser');
      }
      updateLocalSamplesControls();
      return;
    }

    setLocalSamplesBusy(true);
    setLocalSamplesStatus('checking saved local folder...');
    try {
      const handle = await readSavedSamplesHandle();
      if (!handle) {
        setLocalSamplesStatus('no local folder linked');
        localSamplesDirHandle = null;
        clearLocalSampleOverlay();
        return;
      }
      await applyLocalSamplesFromHandle(handle, {
        requireGranted: false,
        statusPrefix: `local folder "${handle.name || 'saved'}"`,
        statusWhenPrompt: 'saved local folder needs permission — click relink',
      });
    } catch (err) {
      showWarning(err && err.message ? err.message : 'could not restore local sample folder link');
      clearLocalSampleOverlay();
      localSamplesDirHandle = null;
      setLocalSamplesStatus('local folder restore failed');
    } finally {
      setLocalSamplesBusy(false);
    }
  }

  function renderSamplesPanel(filter) {
    if (!samplesGroupsEl) return;
    if (!samplesGroupsCache && window.SampleVoice) {
      samplesGroupsCache = window.SampleVoice.groups();
    }
    samplesGroupsEl.innerHTML = '';
    const groups = samplesGroupsCache || [];
    const f = (filter || '').trim().toLowerCase();
    let total = 0;
    for (const group of groups) {
      const filtered = f ? group.samples.filter((n) => n.toLowerCase().includes(f)) : group.samples;
      if (filtered.length === 0) continue;
      total += filtered.length;
      const groupEl = document.createElement('div');
      groupEl.className = 'samples-group';
      const head = document.createElement('div');
      head.className = 'samples-group-head';
      head.textContent = `${group.label} — ${filtered.length}${f && filtered.length !== group.samples.length ? ` of ${group.samples.length}` : ''}`;
      groupEl.appendChild(head);
      const pills = document.createElement('div');
      pills.className = 'samples-pills';
      for (const name of filtered) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'samples-pill';
        btn.textContent = name;
        btn.dataset.name = name;
        pills.appendChild(btn);
      }
      groupEl.appendChild(pills);
      samplesGroupsEl.appendChild(groupEl);
    }
    if (total === 0) {
      const empty = document.createElement('div');
      empty.className = 'samples-empty';
      empty.textContent = (groups.length === 0)
        ? 'sample bank not loaded yet — try again in a moment'
        : `no samples match "${filter}"`;
      samplesGroupsEl.appendChild(empty);
    }
    samplesPanelRendered = true;
  }

  function insertAtCursor(text) {
    if (!editorAPI) return;
    const value = typeof text === 'string' ? text : '';
    if (!value) return;

    const doc = (typeof editorAPI.getValue === 'function')
      ? String(editorAPI.getValue() || '')
      : '';
    const rawCursor = (typeof editorAPI.getCursor === 'function')
      ? editorAPI.getCursor()
      : 0;
    const cursor = Number.isFinite(rawCursor)
      ? Math.max(0, Math.min(doc.length, rawCursor | 0))
      : 0;

    // Collapse to one caret before insertion so a stale selection range
    // cannot redirect edits away from the user's intended cursor point.
    if (typeof editorAPI.setCursor === 'function') editorAPI.setCursor(cursor);
    editorAPI.focus();

    if (typeof editorAPI.dispatchTextChange !== 'function') {
      editorAPI.insertText(value);
      return;
    }

    const before = cursor > 0 ? doc.slice(cursor - 1, cursor) : '';
    const after = cursor < doc.length ? doc.slice(cursor, cursor + 1) : '';
    const needLead = before && !/\s|\(/.test(before);
    const needTrail = after && !/\s|\)/.test(after);
    const insert = `${needLead ? ' ' : ''}${value}${needTrail ? ' ' : ''}`;
    editorAPI.dispatchTextChange(cursor, cursor, insert);
    if (typeof editorAPI.setCursor === 'function') {
      editorAPI.setCursor(cursor + insert.length);
    }
  }

  const COMMAND_INSERT_VOICE_HEADS = new Set([
    'string', 'sample', 'drum', 'piano', 'violin', 'cello', 'marimba',
    'vibraphone', 'vibes', 'voice', 'vox', 'input', 'sine', 'osc', 'noise',
    'pluck', 'pulse', 'drone', 'video',
  ]);
  const COMMAND_INSERT_GLOBAL_HEADS = new Set([
    'tempo', 'meter', 'tuning', 'source', 'attractor', 'every', 'enter', 'exit',
  ]);
  const COMMAND_INSERT_PARAM_HEADS = new Set([
    'gain', 'pan', 'force', 'speed', 'rate', 'start', 'decay', 'space', 'body',
    'sympathetic', 'compress', 'crush', 'resolution', 'tone', 'filter', 'color',
    'mallet', 'roll', 'deadstroke', 'pedal', 'motor', 'depth', 'damp',
    'bowpressure', 'articulation', 'sul', 'vibrato', 'carrier', 'syllable',
    'vocoder', 'robot', 'mouth', 'formant', 'roughness', 'kit', 'variance',
    'listen', 'monitor', 'opacity', 'feedback', 'edges', 'blend', 'vowel',
    'human', 'wood', 'release', 'lid', 'una', 'resonance',
  ]);

  function commandLineRanges(doc) {
    const text = String(doc || '');
    const lines = text.split(/\n/);
    const ranges = [];
    let pos = 0;
    for (let i = 0; i < lines.length; i += 1) {
      const line = lines[i];
      ranges.push({ index: i, start: pos, end: pos + line.length, text: line });
      pos += line.length + 1;
    }
    return ranges;
  }

  function commandLineIndexAt(ranges, pos) {
    const cursor = Math.max(0, Number(pos) || 0);
    for (let i = 0; i < ranges.length; i += 1) {
      const line = ranges[i];
      if (cursor >= line.start && cursor <= line.end) return i;
      if (cursor === line.end + 1 && i + 1 < ranges.length) return i + 1;
    }
    return Math.max(0, ranges.length - 1);
  }

  function commandRowHead(line) {
    const text = String(line || '').trim();
    if (!text || text.startsWith('//') || text.startsWith('#')) return '';
    return String(text.split(/\s+/, 1)[0] || '').toLowerCase();
  }

  function commandIsBlankish(line) {
    const text = String(line || '').trim();
    return !text || text.startsWith('//') || text.startsWith('#');
  }

  function commandIsVoiceHead(line) {
    return COMMAND_INSERT_VOICE_HEADS.has(commandRowHead(line));
  }

  function commandIsGlobalHead(line) {
    return COMMAND_INSERT_GLOBAL_HEADS.has(commandRowHead(line));
  }

  function commandSelectionRange(doc) {
    if (!editorAPI) return null;
    const max = String(doc || '').length;
    const normalize = (from, to) => {
      const a = Number(from);
      const b = Number(to);
      if (!Number.isFinite(a) || !Number.isFinite(b) || a === b) return null;
      return {
        from: Math.max(0, Math.min(max, Math.min(a, b) | 0)),
        to: Math.max(0, Math.min(max, Math.max(a, b) | 0)),
      };
    };
    try {
      if (typeof editorAPI.getSelectionRange === 'function') {
        const r = editorAPI.getSelectionRange();
        const out = r && normalize(r.from, r.to);
        if (out) return out;
      }
      if (typeof editorAPI.getSelectedRange === 'function') {
        const r = editorAPI.getSelectedRange();
        const out = r && normalize(r.from, r.to);
        if (out) return out;
      }
      if (typeof editorAPI.getSelection === 'function') {
        const r = editorAPI.getSelection();
        if (r && typeof r === 'object') {
          const out = normalize(r.from, r.to);
          if (out) return out;
        }
      }
    } catch (_) {}
    return null;
  }

  function commandBlockAtLine(ranges, lineIndex) {
    if (!ranges || !ranges.length) return null;
    const idx = Math.max(0, Math.min(ranges.length - 1, Number(lineIndex) || 0));
    let start = -1;
    for (let i = idx; i >= 0; i -= 1) {
      const line = ranges[i].text;
      if (commandIsBlankish(line)) break;
      if (commandIsVoiceHead(line)) {
        start = i;
        break;
      }
    }
    if (start < 0) return null;
    let end = start;
    for (let i = start + 1; i < ranges.length; i += 1) {
      const line = ranges[i].text;
      if (commandIsBlankish(line) || commandIsVoiceHead(line) || commandIsGlobalHead(line)) break;
      end = i;
    }
    return {
      startLine: start,
      endLine: end,
      start: ranges[start].start,
      end: ranges[end].end,
      head: commandRowHead(ranges[start].text),
    };
  }

  function commandLastMusicalBlock(ranges) {
    let last = null;
    for (let i = 0; i < ranges.length; i += 1) {
      if (commandIsVoiceHead(ranges[i].text)) {
        last = commandBlockAtLine(ranges, i) || last;
      }
    }
    return last;
  }

  function commandDocumentEndAfterHeader(doc, ranges) {
    if (!ranges || !ranges.length) return String(doc || '').length;
    for (const line of ranges) {
      if (commandIsVoiceHead(line.text)) return line.start;
    }
    return String(doc || '').length;
  }

  function commandInsertionRole(subject, text) {
    const item = subject || {};
    const group = String(item.group || '').toLowerCase();
    const kind = String(item.kind || '').toLowerCase();
    const first = commandRowHead(String(text || '').split(/\r?\n/, 1)[0] || '');
    if (group === 'params' || kind === 'param' || COMMAND_INSERT_PARAM_HEADS.has(first)) return 'param';
    if (group === 'voices' || group === 'instruments' || group === 'kits') return 'block';
    if (group === 'samples' || kind === 'sample') return 'block';
    if (group === 'syntax' || kind === 'syntax' || COMMAND_INSERT_GLOBAL_HEADS.has(first)) return 'inline';
    return String(text || '').includes('\n') || COMMAND_INSERT_VOICE_HEADS.has(first) ? 'block' : 'inline';
  }

  function commandInsertionTextForPosition(doc, pos, text, role) {
    const value = String(text || '').trim();
    if (!value) return '';
    const before = doc.slice(0, pos);
    const after = doc.slice(pos);
    if (role === 'param') {
      const lead = before && !before.endsWith('\n') ? '\n' : '';
      const trail = after && !after.startsWith('\n') ? '\n' : '';
      return `${lead}${value}${trail}`;
    }
    const lead = before.trim() ? (before.endsWith('\n\n') ? '' : before.endsWith('\n') ? '\n' : '\n\n') : '';
    const trail = after.trim() ? (after.startsWith('\n\n') ? '' : after.startsWith('\n') ? '\n' : '\n\n') : '';
    return `${lead}${value}${trail}`;
  }

  function insertCommandSelection(subject, text) {
    if (!editorAPI) return;
    const value = typeof text === 'string' ? text : '';
    if (!value) return;

    const doc = (typeof editorAPI.getValue === 'function') ? String(editorAPI.getValue() || '') : '';
    const selection = commandSelectionRange(doc);
    if (selection && typeof editorAPI.dispatchTextChange === 'function') {
      editorAPI.dispatchTextChange(selection.from, selection.to, value);
      if (typeof editorAPI.setCursor === 'function') editorAPI.setCursor(selection.from + value.length);
      editorAPI.focus();
      return;
    }

    const role = commandInsertionRole(subject, value);
    if (role === 'inline' || typeof editorAPI.dispatchTextChange !== 'function') {
      insertAtCursor(value);
      return;
    }

    const rawCursor = typeof editorAPI.getCursor === 'function' ? editorAPI.getCursor() : doc.length;
    const cursor = Number.isFinite(rawCursor) ? Math.max(0, Math.min(doc.length, rawCursor | 0)) : doc.length;
    const ranges = commandLineRanges(doc);
    const lineIndex = commandLineIndexAt(ranges, cursor);
    const currentBlock = commandBlockAtLine(ranges, lineIndex);
    const lastBlock = commandLastMusicalBlock(ranges);
    const line = ranges[lineIndex] ? ranges[lineIndex].text : '';
    const cursorLooksGlobal = !currentBlock && (commandIsBlankish(line) || commandIsGlobalHead(line));

    let target = doc.length;
    if (role === 'param') {
      const block = currentBlock || lastBlock;
      target = block ? block.end : commandDocumentEndAfterHeader(doc, ranges);
    } else if (currentBlock && !cursorLooksGlobal) {
      target = currentBlock.end;
    } else if (lastBlock) {
      target = lastBlock.end;
    } else {
      target = commandDocumentEndAfterHeader(doc, ranges);
    }

    const insert = commandInsertionTextForPosition(doc, target, value, role);
    editorAPI.dispatchTextChange(target, target, insert);
    if (typeof editorAPI.setCursor === 'function') editorAPI.setCursor(target + insert.length);
    editorAPI.focus();
  }
    
    // ---------------- command palette / surface index ----------------

    const COMMAND_GROUPS = [
      { id: 'actions', label: 'actions' },
      { id: 'voices', label: 'voices' },
      { id: 'instruments', label: 'instruments' },
      { id: 'samples', label: 'samples' },
      { id: 'kits', label: 'kits' },
      { id: 'params', label: 'parameters' },
      { id: 'syntax', label: 'syntax' },
      { id: 'docs', label: 'docs' },
    ];

    const COMMAND_SURFACE_COPY = {
      actions: 'Transport, patch utilities, and browser actions. These cards run immediately or open a related surface.',
      voices: 'Core synthesis and playback rows. Pick one to insert a playable voice header into the score grid.',
      instruments: 'Modeled or manifest-backed instruments. These rows expect pitch cells and optional technique rows.',
      samples: 'Library browser for archive files, local files, instruments, and kit/sample sets. Folder tiles navigate; sample tiles insert or audition.',
      kits: 'Drum-kit grammar shortcuts. Use these when you want lane/cell-based kit behavior rather than a raw one-shot.',
      params: 'Modifier rows for force, gain, tone, routing, live input, and instrument technique.',
      syntax: 'Score-grid operators, grouping marks, and structural grammar for timing and repetition.',
      docs: 'Reference links and field-report surfaces for debugging, sharing, and reading the REPL language.',
    };

    function commandSurfaceCopy(id) {
      return COMMAND_SURFACE_COPY[String(id || '').toLowerCase()] || 'Command surface. Select a card to insert, run, open, or copy its associated REPL action.';
    }

    const COMMAND_PALETTE_LAYOUT_STYLE_ID = 'repl-command-palette-layout-fix';

    function ensureCommandPaletteLayoutStyles() {
      if (document.getElementById(COMMAND_PALETTE_LAYOUT_STYLE_ID)) return;
      const style = document.createElement('style');
      style.id = COMMAND_PALETTE_LAYOUT_STYLE_ID;
      style.textContent = `
        #command-popover .command-surface-note {
          margin: 0.36rem 0 0.48rem;
          padding: 0.42rem 0.54rem;
          border-top: 2px solid var(--cs-line, #070707);
          border-bottom: 2px solid var(--cs-line, #070707);
          background: rgba(255, 255, 255, 0.72);
          font-size: clamp(0.72rem, 0.9vw, 0.88rem);
          line-height: 1.22;
          max-width: 100%;
        }

        /* Only voice/instrument command cards need a readable row repair.
           This must resize the actual .example-popover-item shell, not only the
           inner copy column, otherwise the border/shadow/accent stripe stay short. */
        #command-popover .example-popover-item.command-card-voices,
        #command-popover .example-popover-item.command-card-instruments {
          display: grid;
          grid-template-columns: clamp(4.2rem, 7.2vw, 5.15rem) minmax(0, 1fr) clamp(1.05rem, 2vw, 1.32rem);
          align-items: stretch;
          min-height: 6.55rem !important;
          height: auto !important;
          max-height: none !important;
          overflow: hidden;
        }

        #command-popover .example-popover-item.command-card-voices::before,
        #command-popover .example-popover-item.command-card-instruments::before {
          top: 0;
          bottom: 0;
          height: auto;
        }

        #command-popover .example-popover-item.command-card-voices .example-popover-num,
        #command-popover .example-popover-item.command-card-instruments .example-popover-num {
          position: static;
          min-width: 0;
          width: auto;
          height: auto;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 0.42rem 0.34rem 0.5rem;
          writing-mode: horizontal-tb;
          transform: none;
          text-align: center;
          white-space: normal;
          word-break: break-word;
          overflow-wrap: anywhere;
          overflow: visible;
        }

        #command-popover .example-popover-item.command-card-voices .command-popover-rail-label,
        #command-popover .example-popover-item.command-card-instruments .command-popover-rail-label {
          display: inline-block;
          line-height: 1.34;
          padding-top: 0.04em;
          padding-bottom: 0.18em;
          overflow: visible;
          transform: translateY(-0.02em);
        }

        #command-popover .example-popover-item.command-card-voices .example-popover-copy,
        #command-popover .example-popover-item.command-card-instruments .example-popover-copy {
          min-width: 0;
          display: grid;
          grid-template-rows: auto auto auto auto;
          align-content: center;
          gap: 0.12rem;
          padding: 0.54rem 0.62rem 0.6rem;
          overflow: hidden;
        }

        #command-popover .example-popover-item.command-card-voices .example-popover-detail,
        #command-popover .example-popover-item.command-card-instruments .example-popover-detail,
        #command-popover .example-popover-item.command-card-voices .command-popover-snippet,
        #command-popover .example-popover-item.command-card-instruments .command-popover-snippet,
        #command-popover .example-popover-item.command-card-voices .command-popover-paramline,
        #command-popover .example-popover-item.command-card-instruments .command-popover-paramline {
          display: block;
          min-width: 0;
          max-width: 100%;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
          box-sizing: border-box;
        }

        #command-popover .example-popover-item.command-card-voices .command-popover-paramline,
        #command-popover .example-popover-item.command-card-instruments .command-popover-paramline {
          line-height: 1.22;
          margin-top: 0.02rem;
          padding-bottom: 0.04em;
          opacity: 0.86;
        }

        #command-popover .example-popover-item.command-card-voices .example-popover-detail,
        #command-popover .example-popover-item.command-card-instruments .example-popover-detail {
          line-height: 1.32;
          padding-bottom: 0.08em;
        }

        #command-popover .example-popover-item.command-card-voices .command-popover-snippet,
        #command-popover .example-popover-item.command-card-instruments .command-popover-snippet {
          line-height: 1.28;
          margin-top: 0.08rem;
          padding-top: 0.26rem;
          padding-bottom: 0.3rem;
        }

        #command-popover .example-popover-item.command-card-voices .command-popover-paramline,
        #command-popover .example-popover-item.command-card-instruments .command-popover-paramline {
          line-height: 1.3;
          margin-top: 0.04rem;
          padding-bottom: 0.08em;
          opacity: 0.86;
        }

        #command-popover .example-popover-item.command-card-voices:focus-visible,
        #command-popover .example-popover-item.command-card-instruments:focus-visible {
          outline-offset: -4px;
        }
      
      `;
      document.head.appendChild(style);
    }

    const COMMAND_BASE_ENTRIES = [
      {
        id: 'action.evaluate',
        group: 'actions',
        kind: 'action',
        label: 'evaluate',
        detail: 'run current score · CMD ENTER',
        action: 'run',
        run: () => evaluateAndRun(),
      },
      {
        id: 'action.save-patch',
        group: 'actions',
        kind: 'action',
        label: 'save patch',
        detail: 'write current patch title/code to URL hash · CMD S',
        action: 'run',
        run: () => saveCurrentPatchToHash({ reason: 'save' }),
      },
      {
        id: 'action.rename-patch',
        group: 'actions',
        kind: 'action',
        label: 'rename patch',
        detail: 'edit the patch title plate and save hash identity',
        action: 'run',
        run: () => openPatchTitleEditor(),
      },
      {
        id: 'action.replay',
        group: 'actions',
        kind: 'action',
        label: 'replay',
        detail: 're-arm without unlocking frozen choices · CMD SHIFT ENTER',
        action: 'run',
        run: () => safePlay(),
      },
      {
        id: 'action.stop',
        group: 'actions',
        kind: 'action',
        label: 'stop',
        detail: 'red interrupt · stop all active voices · ESC',
        action: 'run',
        run: () => stop(),
      },
      {
        id: 'action.share',
        group: 'actions',
        kind: 'action',
        label: 'share patch',
        detail: 'copy persistent patch URL',
        action: 'run',
        run: () => shareCurrent(),
      },
      {
        id: 'action.open-patches',
        group: 'actions',
        kind: 'action',
        label: 'patch browser',
        detail: 'browse examples and my saved hash patches',
        action: 'run',
        run: () => openExamplePopover(),
      },
      {
        id: 'action.save-patch',
        group: 'actions',
        kind: 'action',
        label: 'save patch',
        detail: 'write current patch to URL hash · CMD S',
        action: 'run',
        run: () => saveCurrentPatchToHash({ reason: 'save' }),
      },
      {
        id: 'action.rename-patch',
        group: 'actions',
        kind: 'action',
        label: 'rename patch',
        detail: 'edit title plate and save hash identity',
        action: 'run',
        run: () => openPatchTitleEditor(),
      },
      {
        id: 'action.clear-patch',
        group: 'actions',
        kind: 'action',
        label: 'clear patch',
        detail: 'reset score scaffold · CMD SHIFT BACKSPACE',
        action: 'run',
        run: () => requestClearPatch(),
      },
      {
        id: 'action.sample-library',
        group: 'actions',
        kind: 'sample',
        label: 'browse samples',
        detail: 'open hierarchical library browser',
        action: 'open',
        run: () => {
          activeCommandGroupId = 'samples';
          commandBrowserState.mode = 'samples';
          renderCommandPalette();
          ensureCommandSampleLibraries().then(() => {
            if (!commandPopover || commandPopover.hidden) return;
            renderCommandPalette();
          }).catch(() => {});
        },
      },
      {
        id: 'action.examples',
        group: 'actions',
        kind: 'action',
        label: 'open examples',
        detail: 'open score-bank drawer',
        action: 'open',
        run: () => openExamplePopover(),
      },
      {
        id: 'action.io',
        group: 'actions',
        kind: 'action',
        label: 'open i/o',
        detail: 'arm live sources and output routing',
        action: 'open',
        run: () => inputToggleBtn && inputToggleBtn.click(),
      },
      {
        id: 'action.video',
        group: 'actions',
        kind: 'action',
        label: 'open video stage',
        detail: 'camera · screen · file · generated stage',
        action: 'open',
        run: () => videoToggleBtn && videoToggleBtn.click(),
      },
      {
        id: 'action.reference',
        group: 'actions',
        kind: 'action',
        label: 'open reference',
        detail: 'surface map and syntax rail',
        action: 'open',
        run: () => referenceToggleBtn && referenceToggleBtn.click(),
      },
      {
        id: 'action.docs',
        group: 'docs',
        kind: 'docs',
        label: 'open docs',
        detail: 'manual · language · voices · examples',
        action: 'open',
        run: () => {
          const btn = document.getElementById('docs-toggle');
          if (btn) btn.click();
        },
      },

      {
        id: 'voice.string',
        group: 'voices',
        kind: 'voice',
        label: 'string',
        detail: 'synthetic resonant pitched body',
        insert: 'string A3 C4 E4 G4\ngain .55\ndecay 4\nbody glass\nspace .25',
        params: 'GAIN · DECAY · BODY · SPACE · TONE',
      },
      {
        id: 'voice.sample',
        group: 'voices',
        kind: 'voice',
        label: 'sample',
        detail: 'archive object / material playback',
        insert: 'sample snm-* . tub-* .\ngain .55\nrate 1\nstart 0\nscar memory',
        params: 'GAIN · RATE · START · GRAIN · SCAR',
      },
      {
        id: 'voice.drum',
        group: 'voices',
        kind: 'voice',
        label: 'drum',
        detail: 'kit lanes / one-shot grammar',
        insert: 'drum k h s h | k h s h\nkit rock\nvariance .25\ngain .55',
        params: 'KIT · VARIANCE · GAIN · PAN · RATE',
      },
      {
        id: 'voice.piano',
        group: 'instruments',
        kind: 'instrument',
        label: 'piano',
        detail: 'keyed string body / Iowa Steinway',
        insert: 'piano C3 E3 G3 C4\npedal .65\nsympathetic .45\ngain .6',
        params: 'PEDAL · UNA · LID · SYMPATHETIC · HUMAN',
      },
      {
        id: 'voice.violin',
        group: 'instruments',
        kind: 'instrument',
        label: 'violin',
        detail: 'bowed soprano string state',
        insert: 'violin D4 ~ A4 .\narticulation arco\nsul auto\nbow .45\nvibrato .25\nhuman .05',
        params: 'ARTICULATION · SUL · BOW · VIBRATO · WOOD',
      },
      {
        id: 'voice.cello',
        group: 'instruments',
        kind: 'instrument',
        label: 'cello',
        detail: 'bowed tenor / bass string body',
        insert: 'cello C2 ~ G2 .\narticulation arco\nsul sulC\nbow .45\nwood .7\nrelease .8',
        params: 'ARTICULATION · SUL · BOW · WOOD · RELEASE',
      },
      {
        id: 'voice.marimba',
        group: 'instruments',
        kind: 'instrument',
        label: 'marimba',
        detail: 'struck wooden bars / mallet body',
        insert: 'marimba C3 E3 G3 C4\nmallet yarn\nresonance .65\nbody .45\nroll 0\ndeadstroke 0',
        params: 'MALLET · RESONANCE · BODY · ROLL · DEADSTROKE',
      },
      {
        id: 'voice.vibraphone',
        group: 'instruments',
        kind: 'instrument',
        label: 'vibraphone',
        detail: 'metal bar / pedal / motor shimmer',
        insert: 'vibraphone C3 E3 G3 C4\narticulation sustain\npedal .9\nmotor .35\ndepth .25\ndamp 0',
        params: 'PEDAL · MOTOR · DEPTH · DAMP · BOWPRESSURE',
      },
      {
        id: 'voice.voice',
        group: 'instruments',
        kind: 'instrument',
        label: 'voice / vox',
        detail: 'synthetic mouth machine / eSpeak corpus',
        insert: 'voice C3 E3 G3 C4\nvowel ah\nsyllable input\ncarrier sample\nrobot .35\nvocoder .35',
        params: 'VOWEL · SYLLABLE · CARRIER · ROBOT · VOCODER',
      },
      {
        id: 'voice.input',
        group: 'voices',
        kind: 'voice',
        label: 'input',
        detail: 'live source as material and sensor',
        insert: 'input mic\nlisten on\nmonitor off\ngain .7\nspace .25',
        params: 'LISTEN · MONITOR · GAIN · SPACE',
      },
      {
        id: 'voice.video',
        group: 'voices',
        kind: 'video',
        label: 'video',
        detail: 'camera / screen / file / generated image source',
        insert: 'video camera * . * .\nopacity .85\nfeedback .25\nedges .35\nblend screen',
        params: 'SOURCE · OPACITY · FEEDBACK · EDGES · BLEND',
      },

      {
        id: 'kit.rock',
        group: 'kits',
        kind: 'kit',
        label: 'rock',
        detail: 'acoustic drum kit lane map',
        insert: 'drum r h r h | r h s h\nkit rock\nvariance .25\ngain .48',
        params: 'K · S · H · O · T · R · C · VARIANCE',
      },
      {
        id: 'kit.breakcore',
        group: 'kits',
        kind: 'kit',
        label: 'breakcore',
        detail: 'breakcore one-shots / hard lane grammar',
        insert: 'drum k s h c | k t s *!\nkit breakcore\nvariance .6\ngain .55',
        params: 'K · S · H · O · T · R · C · WILDCARD',
      },

      {
        id: 'syntax.tempo',
        group: 'syntax',
        kind: 'syntax',
        label: 'tempo',
        detail: 'quarter-note BPM directive',
        insert: 'tempo 92',
        params: 'TOP DIRECTIVE',
      },
      {
        id: 'syntax.meter',
        group: 'syntax',
        kind: 'syntax',
        label: 'meter',
        detail: 'bar container / denominator-aware timing',
        insert: 'meter 12/8',
        params: 'TOP DIRECTIVE · NUMERATOR / DENOMINATOR',
      },
      {
        id: 'syntax.tuning',
        group: 'syntax',
        kind: 'syntax',
        label: 'tuning',
        detail: 'forward-scoped pitch system',
        insert: 'tuning kirnberger-3',
        params: 'EQUAL · JUST · KIRNBERGER-3',
      },
      {
        id: 'syntax.attractor',
        group: 'syntax',
        kind: 'syntax',
        label: 'attractor',
        detail: 'outside system leaning on a block',
        insert: 'attractor weather.dew',
        params: 'WEATHER · ARCHIVE · TUB · MIC · CAMERA',
      },
      {
        id: 'syntax.source',
        group: 'syntax',
        kind: 'syntax',
        label: 'source',
        detail: 'bind an attractor to a concrete feed',
        insert: 'source station KLAX',
        params: 'STATION · FEED · REGION · CITY · COORDS',
      },
      {
        id: 'syntax.every',
        group: 'syntax',
        kind: 'syntax',
        label: 'every',
        detail: 'periodic block behavior',
        insert: 'every 4 bars',
        params: 'BEATS · BARS',
      },
      {
        id: 'syntax.enter',
        group: 'syntax',
        kind: 'syntax',
        label: 'enter',
        detail: 'fade or introduce a block',
        insert: 'enter 2 bars',
        params: 'BEATS · BARS',
      },
      {
        id: 'syntax.exit',
        group: 'syntax',
        kind: 'syntax',
        label: 'exit',
        detail: 'fade or remove a block',
        insert: 'exit 2 bars',
        params: 'BEATS · BARS',
      },
      {
        id: 'syntax.feedback',
        group: 'syntax',
        kind: 'syntax',
        label: 'feedback',
        detail: 'system self-steering / memory pressure',
        insert: 'feedback .35',
        params: '0–1 · FIRST-ORDER CONTROL',
      },

      ...[
        ['gain', 'block loudness / amplitude surface', 'gain .55'],
        ['pan', 'left/right placement', 'pan -.25'],
        ['force', 'gesture pressure / dynamic intensity', 'force mf'],
        ['speed', 'pattern/signal speed multiplier', 'speed 1'],
        ['rate', 'sample playback rate', 'rate .5 1 2'],
        ['start', 'sample start offset', 'start .25'],
        ['decay', 'envelope tail / struck duration', 'decay 2'],
        ['space', 'room / memory send', 'space .25'],
        ['body', 'material bloom / resonant surface', 'body glass'],
        ['sympathetic', 'resonant string/body coupling', 'sympathetic .45'],
        ['compress', 'dynamics clamp / glue', 'compress .22'],
        ['crush', 'bit-depth damage', 'crush 8'],
        ['resolution', 'sample-rate / pixel-step reduction', 'resolution .25'],
        ['tone', 'dark/bright filter target', 'tone dark'],
        ['filter', 'filter color / spectral leaning', 'filter bright'],
        ['color', 'video color pressure', 'color .5'],
        ['mallet', 'marimba mallet family', 'mallet yarn'],
        ['roll', 'marimba repeated soft strike density', 'roll .55'],
        ['deadstroke', 'marimba damping after attack', 'deadstroke .8'],
        ['pedal', 'piano/vibes damper openness', 'pedal .85'],
        ['motor', 'vibraphone rotating resonator speed', 'motor .45'],
        ['depth', 'vibraphone motor/tremolo depth', 'depth .35'],
        ['damp', 'manual damping / stopped bar', 'damp .8'],
        ['bowpressure', 'bowed vibraphone pressure', 'bowpressure .45'],
        ['articulation', 'arco / pizz / sustain / bow family', 'articulation arco'],
        ['sul', 'string choice / string surface', 'sul sulC'],
        ['vibrato', 'bowed-string vibrato amount', 'vibrato .25'],
        ['carrier', 'voice source oscillator/material', 'carrier sample'],
        ['syllable', 'controlled machine-mouth token', 'syllable input'],
        ['vocoder', 'sample-driven carrier/corpus blend', 'vocoder .5'],
        ['robot', 'machine stepping / instability', 'robot .65'],
        ['mouth', 'vowel openness / brightness', 'mouth .55'],
        ['formant', 'approximate vocal tract shift', 'formant -.25'],
        ['roughness', 'circuit grit / unstable modulation', 'roughness .35'],
      ].map(([label, detail, insert]) => ({
        id: `param.${label}`,
        group: 'params',
        kind: 'param',
        label,
        detail,
        insert,
        params: 'PARAMETER ROW',
      })),
    ];

    function normalizeCommandText(value) {
      return String(value || '')
        .replace(/[\u2018\u2019]/g, "'")
        .replace(/[\u201c\u201d]/g, '"')
        .replace(/\s+/g, ' ')
        .trim();
    }

    function commandEscapeHtml(s) {
      return String(s).replace(/[&<>"']/g, (c) => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
      }[c]));
    }

    function commandContextVoice() {
      if (!editorAPI || typeof editorAPI.getValue !== 'function') return '';
      const doc = String(editorAPI.getValue() || '');
      const rawCursor = typeof editorAPI.getCursor === 'function' ? editorAPI.getCursor() : doc.length;
      const cursor = Number.isFinite(rawCursor) ? Math.max(0, Math.min(doc.length, rawCursor | 0)) : doc.length;
      const before = doc.slice(0, cursor).split(/\r?\n/);
      const heads = new Set(['string', 'sample', 'piano', 'violin', 'cello', 'marimba', 'vibraphone', 'vibes', 'voice', 'vox', 'input', 'sine', 'osc', 'noise', 'pluck', 'pulse', 'drone', 'drum', 'video']);
      for (let i = before.length - 1; i >= 0; i -= 1) {
        const head = String(before[i] || '').trim().split(/\s+/, 1)[0].toLowerCase();
        if (heads.has(head)) return head === 'vox' ? 'voice' : head === 'vibes' ? 'vibraphone' : head;
      }
      return '';
    }

    function contextWeightForCommand(entry) {
      const ctx = commandContextVoice();
      if (!ctx || !entry) return 0;

      const hay = `${entry.id || ''} ${entry.group || ''} ${entry.kind || ''} ${entry.label || ''} ${entry.detail || ''} ${entry.params || ''}`.toLowerCase();

      if (hay.includes(ctx)) return 12;
      if (ctx === 'marimba' && /(mallet|roll|deadstroke|resonance|body|spread|human)/.test(hay)) return 8;
      if (ctx === 'vibraphone' && /(pedal|motor|depth|damp|bowpressure|articulation|body|spread)/.test(hay)) return 8;
      if (ctx === 'voice' && /(vowel|syllable|carrier|vocoder|robot|mouth|formant|roughness|breath|ensemble)/.test(hay)) return 8;
      if ((ctx === 'violin' || ctx === 'cello') && /(articulation|sul|vibrato|bow|wood|sympathetic|release)/.test(hay)) return 8;
      if (ctx === 'drum' && /(kit|variance|rock|breakcore|lane)/.test(hay)) return 8;
      if (ctx === 'sample' && /(sample|rate|start|grain|scar)/.test(hay)) return 8;
      return 0;
    }

    function commandEntries() {
      // Samples are no longer flattened into command cards. The samples tab now
      // renders a hierarchical library browser, so command entries stay semantic.
      return COMMAND_BASE_ENTRIES;
    }
    
    const COMMAND_INSTRUMENT_MANIFESTS = [
      {
        id: 'piano',
        label: 'piano',
        accent: 'piano',
        kind: 'instrument',
        urls: [
          './public/instruments/iowa-piano/manifest.full.json',
          './public/instruments/iowa-piano/manifest.json',
          './public/instruments/piano/manifest.full.json',
          './public/instruments/piano/manifest.json',
        ],
        detail: 'Iowa piano · keyed string body',
      },
      {
        id: 'violin',
        label: 'violin',
        accent: 'violin',
        kind: 'instrument',
        urls: [
          './public/instruments/iowa-violin/manifest.full.json',
          './public/instruments/iowa-violin/manifest.json',
          './public/instruments/violin/manifest.full.json',
          './public/instruments/violin/manifest.json',
        ],
        detail: 'Iowa violin · bowed soprano string',
      },
      {
        id: 'cello',
        label: 'cello',
        accent: 'cello',
        kind: 'instrument',
        urls: [
          './public/instruments/iowa-cello/manifest.full.json',
          './public/instruments/iowa-cello/manifest.json',
          './public/instruments/cello/manifest.full.json',
          './public/instruments/cello/manifest.json',
        ],
        detail: 'Iowa cello · bowed tenor/bass body',
      },
      {
        id: 'marimba',
        label: 'marimba',
        accent: 'marimba',
        kind: 'instrument',
        urls: [
          './public/instruments/iowa-marimba/manifest.full.json',
          './public/instruments/iowa-marimba/manifest.json',
          './public/instruments/marimba/manifest.full.json',
          './public/instruments/marimba/manifest.json',
        ],
        detail: 'Iowa marimba · struck wood body',
      },
      {
        id: 'vibraphone',
        label: 'vibraphone',
        accent: 'vibraphone',
        kind: 'instrument',
        urls: [
          './public/instruments/iowa-vibraphone/manifest.full.json',
          './public/instruments/iowa-vibraphone/manifest.json',
          './public/instruments/vibraphone/manifest.full.json',
          './public/instruments/vibraphone/manifest.json',
        ],
        detail: 'Iowa vibraphone · metal bar / pedal / motor',
      },
      {
        id: 'voice',
        label: 'voice / vox',
        accent: 'voice',
        kind: 'instrument',
        urls: [
          './public/instruments/espeak-robotvoice/manifest.full.json',
          './public/instruments/espeak-robotvoice/manifest.json',
        ],
        detail: 'eSpeak corpus · synthetic mouth machine',
      },
    ];
    function noteMidiForBrowser(note) {
      const m = String(note || '').match(/^([A-Ga-g])([#b])?(-?\d{1,2})$/);
      if (!m) return 9999;
      const pc = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 }[m[1].toUpperCase()];
      const acc = m[2] === '#' ? 1 : m[2] === 'b' ? -1 : 0;
      return (Number(m[3]) + 1) * 12 + pc + acc;
    }
    function commandSampleCount(node) {
      if (!node) return 0;
      if (Number.isFinite(Number(node.count))) return Number(node.count);
      if (Array.isArray(node.children)) {
        return node.children.reduce((sum, child) => sum + commandSampleCount(child), 0);
      }
      return node.url || node.rawSample ? 1 : 0;
    }
    function commandNodeByPath(nodes, path) {
      let current = null;
      let children = Array.isArray(nodes) ? nodes : [];
      for (const part of path || []) {
        current = children.find((node) => node && node.id === part);
        if (!current) return null;
        children = Array.isArray(current.children) ? current.children : [];
      }
      return current || { id: 'samples-root', label: 'samples', children };
    }
    function uniqueSorted(values) {
      return Array.from(new Set(values.filter(Boolean))).sort((a, b) => {
        const am = noteMidiForBrowser(a);
        const bm = noteMidiForBrowser(b);
        if (am !== 9999 || bm !== 9999) return am - bm;
        return String(a).localeCompare(String(b));
      });
    }
    function inferCommandSampleFamily(spec, sample) {
      const raw = [
        sample.family,
        sample.mallet,
        sample.articulation,
        sample.material,
        sample.string,
        sample.token,
        sample.sourceFile,
        sample.url,
        sample.rawSample,
      ].join(' ').toLowerCase();
      if (spec.id === 'marimba') {
        if (raw.includes('yarn')) return 'yarn';
        if (raw.includes('cord')) return 'cord';
        if (raw.includes('rubber')) return 'rubber';
        return 'mallet';
      }
      if (spec.id === 'vibraphone') {
        if (raw.includes('shortsustain') || raw.includes('short-sustain')) return 'shortsustain';
        if (raw.includes('dampen') || raw.includes('damp')) return 'dampen';
        if (raw.includes('bow')) return 'bow';
        if (raw.includes('sustain')) return 'sustain';
        return 'sustain';
      }
      if (spec.id === 'violin' || spec.id === 'cello') {
        if (raw.includes('pizz')) return 'pizz';
        if (raw.includes('arco')) return 'arco';
        return String(sample.articulation || 'arco');
      }
      if (spec.id === 'voice') {
        return String(sample.material || 'vowel').toLowerCase();
      }
      if (raw.includes('sustain')) return 'sustain';
      return String(sample.family || sample.articulation || sample.material || 'samples').toLowerCase();
    }
    function inferCommandSampleSubfamily(spec, sample) {
      const raw = [
        sample.string,
        sample.sul,
        sample.sourceFile,
        sample.url,
        sample.rawSample,
      ].join(' ');
      if (spec.id === 'violin' || spec.id === 'cello') {
        const m = raw.match(/\bsul[CGDAE]\b/i);
        return m ? m[0] : 'auto';
      }
      if (spec.id === 'voice') {
        return String(sample.token || sample.vowel || 'token').toLowerCase();
      }
      return '';
    }
    function extractManifestSampleLeaves(manifest, spec, manifestUrl) {
      const out = [];
      const seen = new Set();
      function noteFromContext(context, obj) {
        if (obj && (obj.rootNote || obj.note)) return obj.rootNote || obj.note;
        for (let i = context.length - 1; i >= 0; i -= 1) {
          const part = String(context[i] || '');
          if (/^[A-G](?:#|b)?-?\d{1,2}$/i.test(part)) return part;
        }
        const raw = [
          obj && obj.url,
          obj && obj.sourceFile,
          obj && obj.file,
          obj && obj.name,
          obj && obj.id,
        ].join(' ');
        const m = raw.match(/\b([A-G](?:#|b)?-?\d{1,2})\b/i);
        return m ? m[1].replace(/^([a-g])/, (x) => x.toUpperCase()) : '';
      }
      function pushSample(obj, context) {
        if (!obj || typeof obj !== 'object') return;
        const url = obj.url || obj.path || obj.href || obj.src || obj.fileUrl || '';
        const sourceFile = obj.sourceFile || obj.file || obj.filename || obj.name || obj.id || '';
        const hasAudioishUrl = /\.(ogg|wav|aif|aiff|mp3|flac|m4a|aac)(?:[?#].*)?$/i.test(String(url || sourceFile));
        const hasManifestAudioShape = Boolean(url || sourceFile) && (
          obj.rootNote || obj.rootMidi || obj.midi || obj.frequency || obj.material || obj.articulation || obj.string || obj.sul
        );
        if (!hasAudioishUrl && !hasManifestAudioShape) return;
        const rootNote = noteFromContext(context, obj);
        const rawSample = sourceFile
          || (url ? String(url).split('/').pop().replace(/\.(ogg|wav|aif|aiff|mp3|flac|m4a|aac)$/i, '') : '')
          || rootNote;
        const key = [
          url,
          sourceFile,
          rawSample,
          rootNote,
          context.join('/'),
        ].join('|');
        if (seen.has(key)) return;
        seen.add(key);
        out.push({
          ...obj,
          note: rootNote,
          rootNote,
          url,
          baseUrl: manifestUrl,
          sourceFile,
          rawSample,
          context: context.slice(),
          family: obj.family || obj.articulation || obj.material || context[0] || '',
          subfamily: obj.string || obj.sul || obj.layer || context[1] || '',
        });
      }
      function walk(node, context) {
        if (!node) return;
        if (Array.isArray(node)) {
          node.forEach((item, index) => walk(item, context.concat(String(index))));
          return;
        }
        if (typeof node !== 'object') return;
        pushSample(node, context);
        for (const [key, value] of Object.entries(node)) {
          if (value == null) continue;
          if (typeof value !== 'object') continue;
          // Skip massive/non-sample metadata-looking keys only when they are simple.
          if (['format', 'engine', 'license', 'range'].includes(key)) continue;
          walk(value, context.concat(key));
        }
      }
      // Prefer notes when present, but also scan the whole manifest because piano,
      // violin, and cello manifests may use layers/articulations/variants/samples.
      if (manifest && manifest.notes && typeof manifest.notes === 'object') {
        for (const [noteName, entry] of Object.entries(manifest.notes)) {
          walk(entry, [noteName]);
        }
      }
      if (Array.isArray(manifest && manifest.samples)) {
        walk(manifest.samples, ['samples']);
      }
      if (Array.isArray(manifest && manifest.variants)) {
        walk(manifest.variants, ['variants']);
      }
      walk(manifest, []);
      return out;
    }
    function commandInstrumentInsert(spec, family, subfamily, note) {
      const n = note || 'C4';
      if (spec.id === 'marimba') {
        return `marimba ${n}\nmallet ${family || 'yarn'}`;
      }
      if (spec.id === 'vibraphone') {
        const articulation = family || 'sustain';
        if (articulation === 'bow') return `vibraphone ${n} ~ ~ .\narticulation bow\npedal 1`;
        if (articulation === 'dampen') return `vibraphone ${n}\narticulation dampen\ndamp .85`;
        return `vibraphone ${n}\narticulation ${articulation}\npedal .9`;
      }
      if (spec.id === 'violin' || spec.id === 'cello') {
        const articulation = family || 'arco';
        const sul = subfamily && subfamily !== 'auto' ? `\nsul ${subfamily}` : '';
        return `${spec.id} ${n}\narticulation ${articulation}${sul}`;
      }
      if (spec.id === 'voice') {
        const token = subfamily || family || 'ah';
        const isVowel = ['ah', 'eh', 'ee', 'oh', 'oo', 'uh', 'mm', 'nn'].includes(token);
        return `voice ${n}\nvowel ${isVowel ? token : 'ah'}\nsyllable ${token}\ncarrier sample`;
      }
      if (spec.id === 'piano') {
        return `piano ${n}\npedal .65\nsympathetic .45`;
      }
      return `${spec.id} ${n}`;
    }
    function buildInstrumentLibraryFromManifest(spec, manifest, manifestUrl) {
      const leaves = extractManifestSampleLeaves(manifest, spec, manifestUrl);
      const byFamily = new Map();
      for (const leaf of leaves) {
        const family = inferCommandSampleFamily(spec, leaf);
        const subfamily = inferCommandSampleSubfamily(spec, leaf);
        if (!byFamily.has(family)) byFamily.set(family, []);
        byFamily.get(family).push({ ...leaf, family, subfamily });
      }
      const familyNodes = Array.from(byFamily.entries()).map(([family, familyLeaves]) => {
        const subfamilies = uniqueSorted(familyLeaves.map((leaf) => leaf.subfamily).filter(Boolean));
        if (subfamilies.length > 1) {
          return {
            id: family,
            label: family,
            kind: 'folder',
            accent: spec.accent,
            detail: `${spec.label} · ${family}`,
            count: familyLeaves.length,
            chips: subfamilies.slice(0, 6),
            children: subfamilies.map((sub) => {
              const subLeaves = familyLeaves.filter((leaf) => leaf.subfamily === sub);
              const notes = uniqueSorted(subLeaves.map((leaf) => leaf.rootNote || leaf.note));
              return {
                id: sub,
                label: sub,
                kind: 'folder',
                accent: spec.accent,
                detail: `${family} · ${sub}`,
                count: subLeaves.length,
                children: notes.map((note) => {
                  const noteLeaf = subLeaves.find((leaf) => (leaf.rootNote || leaf.note) === note) || subLeaves[0];
                  return {
                    id: note,
                    label: note,
                    kind: 'sample',
                    accent: spec.accent,
                    detail: `${family} · ${sub} · exact sample`,
                    count: 1,
                    insert: commandInstrumentInsert(spec, family, sub, note),
                    rawInsert: noteLeaf.rawSample ? `sample ${noteLeaf.rawSample}` : '',
                    rawSample: noteLeaf.rawSample,
                    url: noteLeaf.url,
                    baseUrl: noteLeaf.baseUrl,
                    chips: ['insert instrument row', 'raw available'],
                  };
                }),
              };
            }),
          };
        }
        const notes = uniqueSorted(familyLeaves.map((leaf) => leaf.rootNote || leaf.note));
        return {
          id: family,
          label: family,
          kind: 'folder',
          accent: spec.accent,
          detail: `${spec.label} · ${family}`,
          count: familyLeaves.length,
          chips: notes.length ? [`${notes[0]}-${notes[notes.length - 1]}`] : [],
          children: notes.map((note) => {
            const noteLeaf = familyLeaves.find((leaf) => (leaf.rootNote || leaf.note) === note) || familyLeaves[0];
            return {
              id: note,
              label: note,
              kind: 'sample',
              accent: spec.accent,
              detail: `${family} · exact sample`,
              count: 1,
              insert: commandInstrumentInsert(spec, family, '', note),
              rawInsert: noteLeaf.rawSample ? `sample ${noteLeaf.rawSample}` : '',
              rawSample: noteLeaf.rawSample,
              url: noteLeaf.url,
              baseUrl: noteLeaf.baseUrl,
              chips: ['insert instrument row', 'raw available'],
            };
          }),
        };
      }).sort((a, b) => String(a.label).localeCompare(String(b.label)));
      return {
        id: spec.id,
        label: spec.label,
        kind: 'library',
        accent: spec.accent,
        detail: spec.detail,
        count: leaves.length,
        chips: familyNodes.map((node) => node.label).slice(0, 6),
        manifestUrl: manifestUrl || spec.url || (Array.isArray(spec.urls) ? spec.urls[0] : ''),
        children: familyNodes,
      };
    }
    async function fetchJsonQuiet(url) {
      try {
        const r = await fetch(url, { credentials: 'omit' });
        if (!r.ok) return null;
        const json = await r.json();
        return { json, url };
      } catch (_) {
        return null;
      }
    }
    async function fetchFirstJsonQuiet(urls) {
      const list = Array.isArray(urls) ? urls : [urls].filter(Boolean);
      for (const url of list) {
        const result = await fetchJsonQuiet(url);
        if (result && result.json) return result;
      }
      return null;
    }
    function normalizeCommandSampleName(value) {
      return String(value || '')
        .trim()
        .replace(/\.(ogg|wav|aif|aiff|mp3|flac|m4a|aac)(?:[?#].*)?$/i, '')
        .toLowerCase();
    }
    function commandSampleSlug(value) {
      return normalizeCommandSampleName(value)
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '');
    }
    function drumKitCellFromPrefix(prefix, raw) {
      if (['bk', 'bd', 'kd', 'kick'].includes(prefix) || /\b(kick|bassdrum|bass-drum|bass_drum|bd|kd)\b/.test(raw)) return ['k', 'kick / bass drum', 'bass drum'];
      if (['sn', 'sd', 'snr', 'rs', 'rim'].includes(prefix) || /\b(snare|rimshot|rim-shot|rim_shot|sd|sn)\b/.test(raw)) return ['s', 'snare', 'snare'];
      if (['ch', 'hh', 'hc', 'hat', 'pedal'].includes(prefix) || /\b(closed[ _-]?hat|closed|pedal|hihat|hi-hat|hat|hh)\b/.test(raw)) return ['h', 'hi-hat', 'closed / pedal'];
      if (['oh', 'ho', 'openhat'].includes(prefix) || /\b(open[ _-]?hat|open-hat)\b/.test(raw)) return ['o', 'hi-hat', 'open'];
      if (['rd', 'rb', 'ride', 'bell'].includes(prefix) || /\b(ride|ridebell|ride-bell|ride_bell|bell)\b/.test(raw)) return ['r', 'ride cymbal', 'ride / bell'];
      if (['cr', 'cy', 'cym', 'sp', 'china'].includes(prefix) || /\b(crash|splash|china|cymbal)\b/.test(raw)) return ['c', 'crash cymbal', 'crash / splash'];
      if (['tom', 'tm', 'lt', 'mt', 'ht', 'ft', 'flr'].includes(prefix) || /\b(tom|rack|floor)\b/.test(raw)) return ['t', 'toms', 'rack / floor'];
      return ['', 'other / unresolved', 'raw fallback'];
    }
    function classifyDrumLaneFromName(name, groupLabel) {
      const raw = `${groupLabel || ''} ${name || ''}`.toLowerCase();
      const slug = commandSampleSlug(name);
      const prefix = (slug.match(/^[a-z]+/) || [''])[0];
      const [cell, familyLabel] = drumKitCellFromPrefix(prefix, raw);
      return [cell, familyLabel];
    }
    function normalizeDrumKitAddress(sample) {
      const name = String(sample && sample.name ? sample.name : sample || '').trim();
      if (!name) return null;

      const groupId = String(sample && sample.groupId ? sample.groupId : '').trim();
      const groupLabel = String(sample && sample.groupLabel ? sample.groupLabel : groupId).trim();
      const raw = `${groupId} ${groupLabel} ${name}`.toLowerCase();
      const slug = commandSampleSlug(name);
      const prefix = (slug.match(/^[a-z]+/) || [''])[0];
      const [cell, family, subfamily] = drumKitCellFromPrefix(prefix, raw);
      const kit = 'rock';
      const sampleGroup = prefix || (cell ? cell : 'other');
      const sampleGroupLabel = sampleGroup === 'other' ? 'other / unresolved' : sampleGroup.toUpperCase();
      const corpus = /smd|sm[ _-]?drums/i.test(`${groupId} ${groupLabel}`) ? 'smdrums' : 'drum-kits';

      if (!cell) {
        return {
          resolved: false,
          library: 'drum-kits',
          corpus,
          kit,
          kitLabel: 'rock kit',
          family: 'other',
          familyLabel: 'other / unresolved',
          sampleGroup,
          sampleGroupLabel,
          subfamily,
          cell: '',
          token: '',
          sample: name,
          params: [],
          sourceGroupId: groupId,
          sourceGroupLabel: groupLabel,
          insertPlan: { resolved: false, voice: 'sample', sample: name },
        };
      }

      const insertPlan = {
        resolved: true,
        voice: 'drum',
        library: 'drum-kits',
        corpus,
        kit,
        kitLabel: 'rock kit',
        family,
        sampleGroup,
        sampleGroupLabel,
        subfamily,
        lane: cell,
        laneLabel: family,
        cell,
        token: `${cell}!`,
        sample: name,
        params: [
          ['kit', kit],
          ['sample', name],
          ['variance', 'off'],
        ],
      };

      return {
        resolved: true,
        library: 'drum-kits',
        corpus,
        kit,
        kitLabel: 'rock kit',
        family,
        familyLabel: family,
        sampleGroup,
        sampleGroupLabel,
        subfamily,
        lane: cell,
        laneLabel: family,
        cell,
        token: `${cell}!`,
        sample: name,
        params: insertPlan.params,
        sourceGroupId: groupId,
        sourceGroupLabel: groupLabel,
        insertPlan,
      };
    }
    function resolveRockKitSampleAddress(sample) {
      const address = normalizeDrumKitAddress(sample);
      return address ? address.insertPlan : null;
    }
    function commandInsertFromPlan(plan) {
      if (!plan || typeof plan !== 'object') return '';
      if (plan.voice === 'drum' && plan.kit && plan.token && plan.sample) {
        const lines = [`drum ${plan.token} . . .`];
        const params = Array.isArray(plan.params) ? plan.params : [];
        for (const pair of params) {
          if (!Array.isArray(pair) || pair.length < 2) continue;
          const key = String(pair[0] || '').trim();
          const value = String(pair[1] || '').trim();
          if (!key || !value) continue;
          lines.push(`${key} ${value}`);
        }
        return lines.join('\n');
      }
      if (plan.sample) return `sample ${plan.sample}`;
      return '';
    }
    function buildExactDrumSampleLeaf(address) {
      const name = String(address && address.sample ? address.sample : '').trim();
      if (!name) return null;
      const plan = address && address.insertPlan ? address.insertPlan : { resolved: false, voice: 'sample', sample: name };
      const insert = commandInsertFromPlan(plan) || `sample ${name}`;
      if (address && address.resolved) {
        return {
          id: name,
          label: name,
          kind: 'sample',
          accent: 'rock',
          detail: `${address.kitLabel || 'rock kit'} / ${address.sampleGroupLabel || address.sampleGroup || 'sample group'} / ${address.familyLabel || address.family} / cell ${address.cell} / sample ${name}`,
          count: 1,
          insert,
          insertPlan: plan,
          rawInsert: `sample ${name}`,
          rawSample: name,
          chips: [`kit ${address.kit}`, `${address.sampleGroupLabel || address.sampleGroup || 'group'}`, `cell ${address.cell}`, `sample ${name}`, 'variance off'],
        };
      }
      return {
        id: name,
        label: name,
        kind: 'sample',
        accent: 'rock',
        detail: `raw fallback only · ${name}`,
        count: 1,
        insert: `sample ${name}`,
        insertPlan: plan,
        rawInsert: `sample ${name}`,
        rawSample: name,
        chips: ['raw sample fallback'],
      };
    }
    function buildRawDrumSampleLeaf(address, opts) {
      const name = String(address && address.sample ? address.sample : '').trim();
      if (!name) return null;
      const options = opts || {};
      const groupLabel = String(options.groupLabel || address.sampleGroupLabel || address.sampleGroup || 'sample group');
      return {
        id: name,
        label: name,
        kind: 'sample',
        accent: 'rock',
        detail: options.detail || `${groupLabel} · chopped one-shot · raw sample ${name}`,
        count: 1,
        insert: `sample ${name}`,
        insertPlan: { resolved: false, voice: 'sample', sample: name },
        rawInsert: `sample ${name}`,
        rawSample: name,
        chips: options.chips || [groupLabel, 'raw sample', 'no drum cell'],
      };
    }

    function buildCommandSampleNodeFromPlan(sample, plan) {
      const name = String(sample && sample.name ? sample.name : sample || '').trim();
      const address = normalizeDrumKitAddress({
        ...(sample && typeof sample === 'object' ? sample : {}),
        name,
      });
      if (address && plan && plan.resolved) address.insertPlan = plan;
      return buildExactDrumSampleLeaf(address || { resolved: false, sample: name, insertPlan: plan || { resolved: false, voice: 'sample', sample: name } });
    }
    function drumFamilyOrderKey(family, cell) {
      const order = ['kick / bass drum', 'snare', 'hi-hat', 'ride cymbal', 'crash cymbal', 'toms', 'other / unresolved'];
      const i = order.indexOf(String(family || ''));
      return i < 0 ? 999 : i;
    }
    function buildDrumKitFamilyNode(family) {
      const children = family.addresses
        .slice()
        .sort((a, b) => String(a.sample).localeCompare(String(b.sample), undefined, { numeric: true, sensitivity: 'base' }))
        .map((address) => buildExactDrumSampleLeaf(address))
        .filter(Boolean);
      const resolved = family.addresses.some((address) => address && address.resolved);
      const firstResolved = family.addresses.find((address) => address && address.resolved);
      return {
        id: family.id,
        label: family.label,
        kind: 'folder',
        accent: 'rock',
        detail: resolved && firstResolved ? `${firstResolved.kitLabel || 'rock kit'} · drum/cymbal family · cell ${firstResolved.cell}` : 'raw fallback only',
        info: resolved && firstResolved
          ? `These samples share the ${firstResolved.familyLabel || firstResolved.family} surface and insert with cell ${firstResolved.cell}.`
          : 'These samples are not safely mapped to a drum cell; leaves insert as raw samples.',
        count: family.addresses.length,
        chips: resolved && firstResolved ? [`cell ${firstResolved.cell}`, firstResolved.subfamily || 'exact addressed'] : ['not guessed'],
        children,
      };
    }
    function drumKitFamilyNodesForAddresses(addresses) {
      const families = new Map();
      const list = Array.isArray(addresses) ? addresses.filter(Boolean) : [];
      for (const address of list) {
        const id = address.resolved ? (address.family || address.familyLabel || address.cell || 'other') : 'other-unresolved';
        const label = address.resolved ? (address.familyLabel || address.family || id) : 'other / unresolved';
        if (!families.has(id)) families.set(id, { id, label, cell: address.cell || '', addresses: [] });
        families.get(id).addresses.push(address);
      }
      return Array.from(families.values())
        .sort((a, b) => drumFamilyOrderKey(a.label, a.cell) - drumFamilyOrderKey(b.label, b.cell) || String(a.label).localeCompare(String(b.label)))
        .map((family) => buildDrumKitFamilyNode(family));
    }
    function drumKitSampleGroupOrderKey(group) {
      const raw = String(group || '').toLowerCase();
      const order = ['bk', 'bd', 'kd', 'kick', 'sn', 'sd', 'rs', 'rim', 'ch', 'hh', 'oh', 'rd', 'rb', 'cr', 'cy', 'tom', 'tm', 'lt', 'mt', 'ht', 'ft', 'other'];
      const i = order.indexOf(raw);
      return i < 0 ? 900 : i;
    }
    function drumKitSampleGroupNodesForAddresses(addresses) {
      const groups = new Map();
      const list = Array.isArray(addresses) ? addresses.filter(Boolean) : [];

      // This level is a prefix/sample-set chooser, not a full-kit preset clone.
      // BK contains only bk-* samples; ROCK contains only rock-* samples; SN
      // contains only sn-* samples, etc. Do not hydrate any one tile with the
      // complete rock-kit address map.
      for (const address of list) {
        const id = address.sampleGroup || (address.resolved ? address.cell : 'other') || 'other';
        const label = address.sampleGroupLabel || (id === 'other' ? 'other / unresolved' : String(id).toUpperCase());
        if (!groups.has(id)) {
          groups.set(id, {
            id: `sample-group-${id}`,
            rawId: id,
            label,
            kit: address.kit || 'rock',
            kitLabel: address.kitLabel || 'rock kit',
            corpus: address.corpus || 'drum-kits',
            addresses: [],
          });
        }
        groups.get(id).addresses.push(address);
      }

      return Array.from(groups.values())
        .sort((a, b) => drumKitSampleGroupOrderKey(a.rawId) - drumKitSampleGroupOrderKey(b.rawId) || String(a.label).localeCompare(String(b.label), undefined, { numeric: true, sensitivity: 'base' }))
        .map((group) => {
          const groupAddresses = group.addresses.slice();
          const isBreakcoreGroup = String(group.rawId || '').toLowerCase() === 'bk';
          if (isBreakcoreGroup) {
            const children = groupAddresses
              .slice()
              .sort((a, b) => String(a.sample).localeCompare(String(b.sample), undefined, { numeric: true, sensitivity: 'base' }))
              .map((address) => buildRawDrumSampleLeaf(address, {
                groupLabel: group.label,
                detail: `${group.label} kit · breakcore/chopped one-shot · raw sample ${address.sample}`,
                chips: [group.label, 'breakcore chop', 'raw sample'],
              }))
              .filter(Boolean);
            return {
              id: `kit-${group.rawId || group.id}`,
              rawId: group.rawId,
              label: group.label,
              kind: 'folder',
              accent: 'rock',
              detail: `${group.label} kit · chopped-and-screwed sample set · opens directly to samples`,
              info: 'BK is a breakcore/chop set, not a mapped drum-lane kit. Pick a sample directly; the card inserts a raw sample row instead of inventing a kick/snare/hat cell.',
              count: groupAddresses.length,
              chips: ['direct samples', 'no drum cells', 'raw insert'],
              children,
            };
          }
          const familyNodes = drumKitFamilyNodesForAddresses(groupAddresses);
          const resolved = groupAddresses.some((address) => address && address.resolved);
          const firstResolved = groupAddresses.find((address) => address && address.resolved);
          return {
            id: `kit-${group.rawId || group.id}`,
            rawId: group.rawId,
            label: group.label,
            kind: 'folder',
            accent: 'rock',
            detail: resolved && firstResolved
              ? `${group.label} kit · ${group.kitLabel} sample group · ${groupAddresses.length} samples`
              : `${group.label} kit · unresolved raw sample group`,
            info: resolved && firstResolved
              ? `${group.label} samples are routed through their resolved drum/cymbal family before you choose an exact one-shot.`
              : `${group.label} samples are unresolved; choosing a leaf inserts a raw sample row rather than guessed kit grammar.`,
            count: groupAddresses.length,
            chips: familyNodes.map((node) => node.label).slice(0, 7),
            children: familyNodes,
          };
        });
    }
    function buildDrumKitTree(addresses) {
      const list = Array.isArray(addresses) ? addresses.filter(Boolean) : [];
      const total = list.length;

      // DRUM KITS should present real selectable sample-set tiles at this
      // level. A tile must never be populated with another tile's samples:
      // BK -> only bk-* leaves, ROCK -> only rock-* leaves, SN -> only sn-* leaves.
      const kitGroupNodes = drumKitSampleGroupNodesForAddresses(list);

      return {
        id: 'drum-kits',
        label: 'drum kits',
        kind: 'library',
        accent: 'rock',
        detail: 'kit corpus · exact addressed drum/cymbal samples',
        info: 'Choose a kit/sample-set tile. BK opens directly to chopped samples; mapped sets continue through drum/cymbal families before leaves.',
        count: total,
        chips: kitGroupNodes.map((node) => node.label).slice(0, 8),
        children: kitGroupNodes,
      };
    }
    function buildSampleVoiceLibraries() {
      const libraries = [];
      if (!samplesGroupsCache && window.SampleVoice && typeof window.SampleVoice.groups === 'function') {
        try { samplesGroupsCache = window.SampleVoice.groups(); } catch (_) {}
      }
      const groups = Array.isArray(samplesGroupsCache) ? samplesGroupsCache : [];
      const allSamples = [];
      for (const group of groups) {
        const samples = Array.isArray(group.samples) ? group.samples : [];
        for (const sample of samples) {
          allSamples.push({
            name: String(sample),
            groupId: String(group.id || group.label || 'samples'),
            groupLabel: String(group.label || group.id || 'samples'),
          });
        }
      }
      const rockSamples = allSamples.filter((sample) => /rock|smd|drum|kit/i.test(`${sample.groupId} ${sample.groupLabel} ${sample.name}`));
      if (rockSamples.length) {
        const addresses = rockSamples
          .map((sample) => normalizeDrumKitAddress(sample))
          .filter(Boolean);
        const drumKitTree = buildDrumKitTree(addresses);
        if (drumKitTree && drumKitTree.count > 0) libraries.push(drumKitTree);
      }
      const nonRockGroups = groups.filter((group) => {
        const raw = `${group.id || ''} ${group.label || ''}`.toLowerCase();
        return !/rock|smd|drum|kit/.test(raw);
      });
      for (const group of nonRockGroups) {
        const samples = Array.isArray(group.samples) ? group.samples : [];
        if (!samples.length) continue;
        const id = String(group.id || group.label || 'archive').replace(/[^a-z0-9_-]+/gi, '-').toLowerCase();
        const isLocal = id.includes('local');
        libraries.push({
          id,
          label: group.label || group.id || 'archive samples',
          kind: 'library',
          accent: isLocal ? 'local' : 'archive',
          detail: isLocal ? 'linked local folder · raw samples' : 'archive sample group · raw samples',
          count: samples.length,
          chips: [`${samples.length} files`],
          children: samples.slice(0, 96).map((name) => ({
            id: String(name),
            label: String(name),
            kind: 'sample',
            accent: isLocal ? 'local' : 'archive',
            detail: `${group.label || group.id || 'sample group'} · raw sample`,
            count: 1,
            insert: `sample ${name}`,
            rawInsert: `sample ${name}`,
            rawSample: String(name),
            chips: ['raw sample id'],
          })),
        });
      }
      return libraries;
    }
    async function buildCommandSampleLibraries() {
      const runtimeLibraries = buildSampleVoiceLibraries();
      const instrumentResults = await Promise.all(COMMAND_INSTRUMENT_MANIFESTS.map(async (spec) => {
        const result = await fetchFirstJsonQuiet(spec.urls || spec.url);
        if (!result || !result.json) {
          return {
            id: spec.id,
            label: spec.label,
            kind: 'library',
            accent: spec.accent,
            detail: `${spec.detail} · manifest missing`,
            count: 0,
            missing: true,
            chips: ['manifest missing'],
            children: [],
          };
        }
        return buildInstrumentLibraryFromManifest(spec, result.json, result.url);
      }));
      const libraries = [
        ...runtimeLibraries,
        ...instrumentResults,
      ];
      return libraries.sort((a, b) => {
        const order = ['archive', 'local', 'drum-kits', 'rock', 'piano', 'violin', 'cello', 'marimba', 'vibraphone', 'voice'];
        const ai = order.indexOf(a.id);
        const bi = order.indexOf(b.id);
        if (ai >= 0 || bi >= 0) return (ai < 0 ? 999 : ai) - (bi < 0 ? 999 : bi);
        return String(a.label).localeCompare(String(b.label));
      });
    }
    function ensureCommandSampleLibraries() {
      if (commandSampleLibraryState.libraries) return Promise.resolve(commandSampleLibraryState.libraries);
      if (!commandSampleLibraryState.loading) {
        commandSampleLibraryState.loading = buildCommandSampleLibraries()
          .then((libs) => {
            commandSampleLibraryState.libraries = libs;
            commandSampleLibraryState.loading = null;
            return libs;
          })
          .catch((err) => {
            console.warn('[repl] sample library browser failed:', err);
            commandSampleLibraryState.libraries = buildSampleVoiceLibraries();
            commandSampleLibraryState.loading = null;
            return commandSampleLibraryState.libraries;
          });
      }
      return commandSampleLibraryState.loading;
    }
    function commandCurrentSampleNode() {
      const libs = commandSampleLibraryState.libraries || [];
      return commandNodeByPath(libs, commandBrowserState.samplePath);
    }
    function commandVisibleSampleChildren() {
      const libs = commandSampleLibraryState.libraries || [];
      const q = String(commandSearchQuery || '').trim().toLowerCase();
      if (q) {
        const flat = [];
        function walk(node, path) {
          if (!node) return;
          const hay = [
            node.id,
            node.label,
            node.detail,
            node.rawSample,
            node.insert,
            node.rawInsert,
            Array.isArray(node.chips) ? node.chips.join(' ') : '',
            path.join(' '),
          ].join(' ').toLowerCase();
          if (q.split(/\s+/).filter(Boolean).every((part) => hay.includes(part))) {
            flat.push({ ...node, _path: path.slice() });
          }
          for (const child of node.children || []) walk(child, path.concat(child.id));
        }
        for (const lib of libs) walk(lib, [lib.id]);
        return flat.slice(0, 80);
      }
      const node = commandCurrentSampleNode();
      return Array.isArray(node && node.children) ? node.children : libs;
    }
    function commandSampleBreadcrumbParts() {
      const libs = commandSampleLibraryState.libraries || [];
      const parts = [{ id: '', label: 'samples', path: [] }];
      let children = libs;
      const path = [];
      for (const segment of commandBrowserState.samplePath) {
        const node = children.find((item) => item.id === segment);
        if (!node) break;
        path.push(segment);
        parts.push({ id: node.id, label: node.label || node.id, path: path.slice() });
        children = Array.isArray(node.children) ? node.children : [];
      }
      return parts;
    }
    function commandSampleSurfaceInfoText() {
      const node = commandCurrentSampleNode();
      if (commandSearchQuery) return 'Search is flattening the library. Matching folders still navigate; matching sample leaves insert or audition directly.';
      if (!commandBrowserState.samplePath.length) {
        return 'Select a library surface. Instruments are pitch/technique aware; drum kits are sample-set aware; archive/local leaves can be auditioned directly.';
      }
      if (node && node.info) return String(node.info);
      if (node && node.kind === 'library') {
        return `${node.label || 'This library'} is a top-level sample surface. Open a folder to narrow the address before choosing a leaf.`;
      }
      if (node && Array.isArray(node.children) && node.children.length) {
        return `${node.label || 'This folder'} narrows the sample address. Folder cards keep browsing; leaf cards insert the exact row and expose the audition button.`;
      }
      if (node && node.kind === 'sample') {
        return `${node.label || 'This sample'} is an exact leaf. Click the card to insert it; click the speaker to audition without changing the patch.`;
      }
      return 'Browse downward until a card becomes an exact sample leaf; only leaves insert playable sample rows.';
    }

    function commandSampleSummaryText() {
      const libs = commandSampleLibraryState.libraries || [];
      const q = String(commandSearchQuery || '').trim();
      if (!libs.length && commandSampleLibraryState.loading) return 'LOADING SAMPLE LIBRARIES';
      const visible = commandVisibleSampleChildren();
      if (q) return `${visible.length} MATCH${visible.length === 1 ? '' : 'ES'} · FILTERED SAMPLE LIBRARY`;
      const node = commandCurrentSampleNode();
      if (!commandBrowserState.samplePath.length) {
        const files = libs.reduce((sum, lib) => sum + commandSampleCount(lib), 0);
        return `${libs.length} LIBRAR${libs.length === 1 ? 'Y' : 'IES'} · ${files} FILE${files === 1 ? '' : 'S'}`;
      }
      const count = commandSampleCount(node);
      return `${String(node.label || 'samples').toUpperCase()} · ${count} FILE${count === 1 ? '' : 'S'}`;
    }
    function commandManifestAssetBase(baseUrl) {
      try {
        return new URL('.', new URL(baseUrl || './', window.location.href)).toString();
      } catch (_) {
        return window.location.href;
      }
    }
    function absoluteCommandSampleUrl(url, baseUrl) {
      if (!url) return '';
      try {
        if (/^(blob:|data:|https?:|file:)/i.test(String(url))) {
          return String(url);
        }
        // Important: manifest-relative audio paths like "audio/arco/..."
        // must resolve relative to the manifest directory, not to
        // ".../manifest.full.json/audio/...".
        return new URL(url, commandManifestAssetBase(baseUrl)).toString();
      } catch (_) {
        return '';
      }
    }
    function commandSampleRawName(node) {
      if (!node) return '';
      if (node.rawSample) return String(node.rawSample);
      const rawInsert = String(node.rawInsert || node.insert || '').trim();
      const m = rawInsert.match(/^sample\s+(.+)$/i);
      return m ? m[1].trim() : '';
    }
    async function auditionCommandRawSample(node, audioCtx, masterBus) {
      const name = commandSampleRawName(node);
      if (!name || !window.SampleVoice || typeof window.SampleVoice.playSample !== 'function') return false;
      if (typeof window.SampleVoice.ready === 'function') {
        try { await window.SampleVoice.ready(); } catch (_) {}
      }
      if (typeof window.SampleVoice.has === 'function') {
        try {
          if (!window.SampleVoice.has(name)) return false;
        } catch (_) {
          return false;
        }
      }
      try {
        return window.SampleVoice.playSample({
          audioCtx,
          masterBus,
          time: audioCtx.currentTime + 0.01,
          name,
          gain: 0.72,
          pan: 0,
          rate: 1,
          rateMul: 1,
          start: 0,
          crush: 0,
          resolution: 0,
          gateDuration: null,
        }) === true;
      } catch (err) {
        console.warn('[repl] raw sample audition failed:', err, { node, name });
        return false;
      }
    }
    async function auditionCommandSample(node, button) {
      const url = absoluteCommandSampleUrl(node && node.url, node && node.baseUrl);
      const rawName = commandSampleRawName(node);
      if (!url && !rawName) {
        showWarning('no directly auditionable URL for this sample');
        return;
      }
      let audioCtx = null;
      let masterBus = null;
      try {
        if (window.StringVoice && typeof window.StringVoice.ensureAudio === 'function') {
          audioCtx = window.StringVoice.ensureAudio();
        }
        if (!audioCtx) {
          const Ctor = window.AudioContext || window.webkitAudioContext;
          if (Ctor) audioCtx = new Ctor();
        }
        if (!audioCtx) {
          showWarning('this browser does not support Web Audio');
          return;
        }
        if (audioCtx.state === 'suspended' && typeof audioCtx.resume === 'function') {
          await audioCtx.resume();
        }
        if (window.StringVoice && typeof window.StringVoice.resume === 'function') {
          try { window.StringVoice.resume(); } catch (_) {}
        }
        if (window.StringVoice && typeof window.StringVoice.getMasterBus === 'function') {
          try { masterBus = window.StringVoice.getMasterBus(); } catch (_) {}
        }
        if (!masterBus || typeof masterBus.connect !== 'function') {
          masterBus = audioCtx.destination;
        }
        if (button) button.classList.add('is-loading');
        if (commandSampleLibraryState.auditionSource) {
          try { commandSampleLibraryState.auditionSource.stop(); } catch (_) {}
          commandSampleLibraryState.auditionSource = null;
        }
        if (!url) {
          const didPlayRaw = await auditionCommandRawSample(node, audioCtx, masterBus);
          if (!didPlayRaw) showWarning(`sample audition failed: ${rawName || 'sample'}`);
          return;
        }
        let buffer = commandSampleLibraryState.auditionBuffers.get(url);
        if (!buffer) {
          const r = await fetch(url, { credentials: 'omit' });
          if (!r.ok) throw new Error(`HTTP ${r.status} for ${url}`);
          const bytes = await r.arrayBuffer();
          buffer = await audioCtx.decodeAudioData(bytes.slice(0));
          commandSampleLibraryState.auditionBuffers.set(url, buffer);
        }
        const src = audioCtx.createBufferSource();
        const gain = audioCtx.createGain();
        src.buffer = buffer;
        gain.gain.value = 0.72;
        src.connect(gain);
        gain.connect(masterBus);
        src.onended = () => {
          if (commandSampleLibraryState.auditionSource === src) {
            commandSampleLibraryState.auditionSource = null;
          }
        };
        commandSampleLibraryState.auditionSource = src;
        src.start(audioCtx.currentTime + 0.01);
      } catch (err) {
        const didPlayRaw = await auditionCommandRawSample(node, audioCtx, masterBus);
        if (didPlayRaw) return;
        console.warn('[repl] sample audition failed:', err, { node, url });
        showWarning(`sample audition failed: ${node && node.label ? node.label : 'sample'}`);
      } finally {
        if (button) button.classList.remove('is-loading');
      }
    }
    function renderCommandSampleBrowser() {
      if (!commandPopoverList) return;
      const libs = commandSampleLibraryState.libraries || [];
      const visible = commandVisibleSampleChildren();
      commandPopoverList.innerHTML = '';
      const shell = document.createElement('div');
      shell.className = 'command-sample-browser';
      const breadcrumb = document.createElement('div');
      breadcrumb.className = 'command-sample-breadcrumb';
      if (commandBrowserState.samplePath.length > 0) {
        const back = document.createElement('button');
        back.type = 'button';
        back.className = 'command-sample-back';
        back.textContent = '← back';
        back.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          commandBrowserState.samplePath.pop();
          activeCommandFocusIndex = 0;
          renderCommandPalette();
        });
        breadcrumb.appendChild(back);
      }
      for (const part of commandSampleBreadcrumbParts()) {
        const crumb = document.createElement('button');
        crumb.type = 'button';
        crumb.className = 'command-sample-crumb';
        crumb.textContent = part.label;
        if (part.path.join('/') === commandBrowserState.samplePath.join('/')) {
          crumb.disabled = true;
        } else {
          crumb.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            commandBrowserState.samplePath = part.path.slice();
            activeCommandFocusIndex = 0;
            renderCommandPalette();
          });
        }
        breadcrumb.appendChild(crumb);
      }
      shell.appendChild(breadcrumb);
      const summary = document.createElement('div');
      summary.className = 'command-sample-summary';
      summary.textContent = commandSampleSummaryText();
      shell.appendChild(summary);
      const info = document.createElement('div');
      info.className = 'reference-section-note';
      info.textContent = commandSampleSurfaceInfoText();
      shell.appendChild(info);
      if (!libs.length && commandSampleLibraryState.loading) {
        const loading = document.createElement('div');
        loading.className = 'example-popover-empty';
        loading.textContent = 'loading sample libraries...';
        shell.appendChild(loading);
        commandPopoverList.appendChild(shell);
        return;
      }
      if (!visible.length) {
        const empty = document.createElement('div');
        empty.className = 'example-popover-empty';
        empty.textContent = commandSearchQuery
          ? `no sample libraries match "${commandSearchQuery}"`
          : 'no sample libraries found';
        shell.appendChild(empty);
        commandPopoverList.appendChild(shell);
        return;
      }
      const grid = document.createElement('div');
      grid.className = 'command-sample-grid';
      visible.forEach((node, idx) => {
        const isFolder = Array.isArray(node.children) && node.children.length > 0;
        const card = document.createElement('div');
        card.setAttribute('role', 'button');
        card.tabIndex = 0;
        card.className = [
          'command-sample-card',
          node.missing ? 'is-missing' : '',
          node.loading ? 'is-loading' : '',
        ].filter(Boolean).join(' ');
        card.dataset.kind = isFolder ? (node.kind === 'library' ? 'library' : 'folder') : 'sample';
        card.dataset.accent = node.accent || 'archive';
        card.dataset.index = String(idx);
        const count = commandSampleCount(node);
        const chips = Array.isArray(node.chips) ? node.chips.slice(0, 7) : [];
        const actionSide = isFolder ? '' : [
          '<span class="command-sample-card-side">',
          '<span class="command-sample-action-stack">',
          `<button
            type="button"
            class="cs-mute-toggle command-sample-audition"
            ${(node.url || commandSampleRawName(node)) ? '' : 'disabled'}
            aria-label="Audition sample"
          >
            <svg class="cs-mute-icon" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
              <path d="M19.114 5.636a9 9 0 0 1 0 12.728M16.463 8.288a5.25 5.25 0 0 1 0 7.424M6.75 8.25l4.72-4.72a.75.75 0 0 1 1.28.53v15.88a.75.75 0 0 1-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 0 1 2.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z"></path>
            </svg>
          </button>`,
          '</span>',
          '</span>',
        ].join('');
        card.innerHTML = [
          '<span class="command-sample-card-main">',
          '<span class="command-sample-card-title">',
          commandEscapeHtml(String(node.label || node.id || 'sample').toLowerCase()),
          '</span>',
          '<span class="command-sample-card-detail">',
          commandEscapeHtml(node.detail || (isFolder ? 'sample folder' : 'exact sample')),
          '</span>',
          '<span class="command-sample-card-count">',
          commandEscapeHtml(`${count} ${count === 1 ? 'sample' : 'samples'}`),
          '</span>',
          chips.length ? '<span class="command-sample-card-chips">' + chips.map((chip) => `<span class="command-sample-chip">${commandEscapeHtml(chip)}</span>`).join('') + '</span>' : '',
          '</span>',
          actionSide,
        ].join('');
        card.addEventListener('click', (e) => {
          if (e.target && e.target.closest && e.target.closest('.command-sample-audition, .command-sample-raw')) return;
          activeCommandFocusIndex = idx;
          if (isFolder) {
            const nextPath = node._path
              ? node._path.slice()
              : commandBrowserState.samplePath.concat(node.id);
            commandBrowserState.samplePath = nextPath;
            renderCommandPalette();
            return;
          }
          if (node.insert) {
            insertCommandSelection({ ...node, group: 'samples' }, node.insert);
            closeCommandPopover();
            if (editorAPI) editorAPI.focus();
          }
        });
        card.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            moveCommandFocus(1);
          }
          if (e.key === 'ArrowUp') {
            e.preventDefault();
            moveCommandFocus(-1);
          }
          if (e.key === 'Home') {
            e.preventDefault();
            focusCommandItem(0);
          }
          if (e.key === 'End') {
            e.preventDefault();
            focusCommandItem(commandItemButtons().length - 1);
          }
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            card.click();
          }
        });
        const audition = card.querySelector('.command-sample-audition');
        if (audition) {
          audition.addEventListener('mousedown', (e) => e.preventDefault());
          audition.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            auditionCommandSample(node, audition);
          });
        }
        grid.appendChild(card);
      });
      shell.appendChild(grid);
      commandPopoverList.appendChild(shell);
    }

    function commandMatchesQuery(entry, query) {
      const q = String(query || '').trim().toLowerCase();
      if (!q) return true;

      const hay = [
        entry.id,
        entry.group,
        entry.kind,
        entry.label,
        entry.detail,
        entry.insert,
        entry.params,
      ].join(' ').toLowerCase();

      return q.split(/\s+/).filter(Boolean).every((part) => hay.includes(part));
    }

    function visibleCommandGroups() {
      const query = commandSearchQuery;
      const entries = commandEntries().filter((entry) => commandMatchesQuery(entry, query));
      const sampleLibraryCount = commandSampleLibraryState.libraries
        ? commandSampleLibraryState.libraries.length
        : 0;
      return COMMAND_GROUPS
        .map((group) => {
          if (group.id === 'samples') {
            return {
              ...group,
              entries: Array.from({ length: sampleLibraryCount }, (_, i) => ({ id: `sample-library-${i}` })),
              sampleLibraryCount,
            };
          }
          return {
            ...group,
            entries: entries
              .filter((entry) => entry.group === group.id)
              .sort((a, b) => contextWeightForCommand(b) - contextWeightForCommand(a)),
          };
        })
        .filter((group) => group.id === 'samples' || group.entries.length > 0 || !query);
    }

    function totalVisibleCommands(groups) {
      return (groups || []).reduce((sum, group) => {
        if (group && group.id === 'samples') {
          return sum + (group.sampleLibraryCount || 0);
        }
        return sum + (group.entries ? group.entries.length : 0);
      }, 0);
    }


    function commandItemButtons() {
      if (!commandPopoverList) return [];
      return Array.from(commandPopoverList.querySelectorAll('.example-popover-item, .command-sample-card'));
    }


    function focusCommandItem(index) {
      const items = commandItemButtons();
      if (!items.length) return;
      const next = Math.max(0, Math.min(items.length - 1, Number(index) || 0));
      activeCommandFocusIndex = next;
      items[next].focus();
    }

    function moveCommandFocus(delta) {
      const items = commandItemButtons();
      if (!items.length) return;

      const current = items.indexOf(document.activeElement);
      const base = current >= 0 ? current : activeCommandFocusIndex;
      const next = (base + delta + items.length) % items.length;
      focusCommandItem(next);
    }

    function commandActionKind(entry) {
      if (!entry) return 'insert';
      if (entry.action) return entry.action;
      if (entry.run) return 'run';
      if (entry.copy) return 'copy';
      return 'insert';
    }

    function executeCommand(entry) {
      if (!entry) return;

      const action = commandActionKind(entry);

      if (entry.run && (action === 'run' || action === 'open')) {
        closeCommandPopover();
        try { entry.run(); } catch (err) { console.warn('[repl] command failed', err); }
        return;
      }

      if (entry.copy) {
        const text = String(entry.copy || '');
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(text).catch(() => {});
        }
        closeCommandPopover();
        if (editorAPI) editorAPI.focus();
        return;
      }

      if (entry.insert) {
        insertCommandSelection(entry, entry.insert);
        closeCommandPopover();
        if (editorAPI) editorAPI.focus();
      }
    }

    function renderCommandPalette() {
      if (!commandPopoverTabs || !commandPopoverList) return;
      ensureCommandPaletteLayoutStyles();

      const groups = visibleCommandGroups();
      const total = totalVisibleCommands(groups);

      if (commandPopoverCount) {
        commandPopoverCount.textContent = `${total} COMMAND${total === 1 ? '' : 'S'}`;
      }

      if (!groups.length) {
        commandPopoverTabs.innerHTML = '';
        commandPopoverList.innerHTML = '<div class="example-popover-empty">No command cards match this filter.</div>';
        return;
      }

      if (!groups.some((group) => group.id === activeCommandGroupId)) {
        activeCommandGroupId = groups[0].id;
        activeCommandFocusIndex = 0;
      }

      commandPopoverTabs.innerHTML = '';

      for (const group of groups) {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = [
          'example-popover-tab',
          `command-kind-${group.id === 'docs' ? 'docs' : group.id.replace(/s$/, '')}`,
          group.id === activeCommandGroupId ? 'is-active' : '',
        ].filter(Boolean).join(' ');
        btn.setAttribute('role', 'tab');
        btn.setAttribute('aria-selected', group.id === activeCommandGroupId ? 'true' : 'false');
        btn.innerHTML = [
          '<span class="example-popover-tab-main">',
          commandEscapeHtml(group.label || group.id),
          '</span>',
          '<span class="example-popover-tab-count">',
          commandEscapeHtml(group.id === 'samples' ? (group.sampleLibraryCount || '...') : group.entries.length),
          '</span>',
        ].join('');

          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            activeCommandGroupId = group.id;
            activeCommandFocusIndex = 0;
            if (group.id === 'samples') {
              commandBrowserState.mode = 'samples';
              ensureCommandSampleLibraries().then(() => {
                if (!commandPopover || commandPopover.hidden) return;
                renderCommandPalette();
              });
            } else {
              commandBrowserState.mode = 'commands';
            }
            renderCommandPalette();
          });


        btn.addEventListener('keydown', (e) => {
          const tabs = Array.from(commandPopoverTabs.querySelectorAll('.example-popover-tab'));
          const idx = tabs.indexOf(document.activeElement);

          if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
            e.preventDefault();
            const next = tabs[(idx + 1 + tabs.length) % tabs.length];
            if (next) next.focus();
          }

          if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
            e.preventDefault();
            const next = tabs[(idx - 1 + tabs.length) % tabs.length];
            if (next) next.focus();
          }

          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            btn.click();
          }
        });

        commandPopoverTabs.appendChild(btn);
      }

      commandPopoverList.innerHTML = '';

      const active = groups.find((group) => group.id === activeCommandGroupId);
      if (!active) return;
        
        if (active.id === 'samples') {
          commandBrowserState.mode = 'samples';
          if (!commandSampleLibraryState.libraries) {
            ensureCommandSampleLibraries().then(() => {
              if (!commandPopover || commandPopover.hidden) return;
              renderCommandPalette();
            });
          }
          renderCommandSampleBrowser();
          return;
        }
        commandBrowserState.mode = 'commands';


      const section = document.createElement('div');
      section.className = `example-popover-section-label command-kind-${active.id === 'docs' ? 'docs' : active.id.replace(/s$/, '')}`;
      section.textContent = active.label || active.id;
      commandPopoverList.appendChild(section);

      const info = document.createElement('div');
      info.className = 'reference-section-note command-surface-note';
      info.textContent = commandSurfaceCopy(active.id);
      commandPopoverList.appendChild(info);

      active.entries.forEach((entry, idx) => {
        const action = commandActionKind(entry);
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = [
          'example-popover-item',
          'command-card-compact',
          `command-card-${active.id}`,
          `command-kind-${entry.kind || 'syntax'}`,
          idx === activeCommandFocusIndex ? 'is-current' : '',
        ].filter(Boolean).join(' ');
        btn.dataset.commandId = entry.id;
        btn.dataset.commandIndex = String(idx);
        btn.dataset.actionKind = action;

        const snippet = entry.insert
          ? `<span class="command-popover-snippet">${commandEscapeHtml(entry.insert)}</span>`
          : '';

        const params = entry.params
          ? `<span class="command-popover-paramline">${commandEscapeHtml(entry.params)}</span>`
          : '';

          btn.innerHTML = [
            '<span class="example-popover-num">',
            '<span class="command-popover-rail-label">',
            commandEscapeHtml(String(entry.kind || 'cmd').toUpperCase()),
            '</span>',
            '</span>',
            '<span class="example-popover-copy">',
            '<span class="example-popover-label">',
          commandEscapeHtml(normalizeCommandText(entry.label).toLowerCase()),
          '</span>',
          '<span class="example-popover-detail">',
          commandEscapeHtml(normalizeCommandText(entry.detail)),
          '</span>',
          snippet,
          params,
          '</span>',
          '<span class="example-popover-stamp" aria-hidden="true"></span>',
        ].join('');

        btn.addEventListener('click', () => {
          activeCommandFocusIndex = idx;
          executeCommand(entry);
        });

        btn.addEventListener('keydown', (e) => {
          if (e.key === 'ArrowDown') {
            e.preventDefault();
            moveCommandFocus(1);
          }

          if (e.key === 'ArrowUp') {
            e.preventDefault();
            moveCommandFocus(-1);
          }

          if (e.key === 'Home') {
            e.preventDefault();
            focusCommandItem(0);
          }

          if (e.key === 'End') {
            e.preventDefault();
            focusCommandItem(commandItemButtons().length - 1);
          }

          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            btn.click();
          }
        });

        commandPopoverList.appendChild(btn);
      });
    }

    function openCommandPopover() {
      if (!commandPopover || !samplesToggleBtn) return;

      if (window.SampleVoice && window.SampleVoice.ready) {
        window.SampleVoice.ready().then(() => {
          samplesGroupsCache = null;
          commandSampleEntriesHydrated = false;
          if (!commandPopover.hidden) renderCommandPalette();
        }).catch(() => {});
      }

      if (commandPopoverSearch) {
        commandSearchQuery = commandPopoverSearch.value || '';
      }
        
        if (activeCommandGroupId !== 'samples') {
          commandBrowserState.mode = 'commands';
        }

      if (commandContextVoice()) {
        const ctx = commandContextVoice();
        if (['marimba', 'vibraphone', 'voice', 'violin', 'cello'].includes(ctx)) {
          activeCommandGroupId = 'params';
        }
      }
        
        ensureCommandSampleLibraries().then(() => {
          if (!commandPopover || commandPopover.hidden) return;
          renderCommandPalette();
        }).catch(() => {});


      renderCommandPalette();

      commandPopover.style.left = '';
      commandPopover.style.top = '';
      commandPopover.hidden = false;
      document.body.classList.add('command-popover-open');
      samplesToggleBtn.setAttribute('aria-expanded', 'true');

      requestAnimationFrame(() => {
        if (commandPopoverSearch) {
          commandPopoverSearch.focus();
          commandPopoverSearch.select();
        }
      });
    }

    function closeCommandPopover() {
      if (!commandPopover || !samplesToggleBtn) return;
      commandPopover.hidden = true;
      document.body.classList.remove('command-popover-open');
      samplesToggleBtn.setAttribute('aria-expanded', 'false');
    }

    function toggleCommandPopover() {
      if (!commandPopover) return;
      if (commandPopover.hidden) openCommandPopover();
      else closeCommandPopover();
    }

  function toggleSamplesPanel(forceState) {
    if (!samplesPanel || !samplesToggleBtn) return;
    const wasHidden = samplesPanel.hasAttribute('hidden');
    const willOpen = typeof forceState === 'boolean' ? forceState : wasHidden;
    if (willOpen) {
      samplesPanel.removeAttribute('hidden');
      samplesToggleBtn.setAttribute('aria-expanded', 'true');
      if (!samplesPanelRendered) {
        // Wait for the manifest to load on first open.
        if (window.SampleVoice && window.SampleVoice.ready) {
          window.SampleVoice.ready().then(() => renderSamplesPanel(samplesFilterInput?.value || ''));
        } else {
          renderSamplesPanel('');
        }
      }
      samplesFilterInput?.focus();
    } else {
      samplesPanel.setAttribute('hidden', '');
      samplesToggleBtn.setAttribute('aria-expanded', 'false');
    }
  }

    if (samplesToggleBtn) {
      samplesToggleBtn.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        toggleCommandPopover();
      });

      samplesToggleBtn.addEventListener('keydown', (e) => {
        if (e.key === 'ArrowDown' || e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          openCommandPopover();
          requestAnimationFrame(() => {
            if (commandPopoverSearch) commandPopoverSearch.focus();
            else focusCommandItem(activeCommandFocusIndex);
          });
        }
      });
    }
    if (commandPopover) {
      commandPopover.addEventListener('click', (e) => {
        e.stopPropagation();
      });
    }

    if (commandPopoverSearch) {
      commandPopoverSearch.addEventListener('click', (e) => {
        e.stopPropagation();
      });

      commandPopoverSearch.addEventListener('input', () => {
          commandSearchQuery = commandPopoverSearch.value || '';
          activeCommandFocusIndex = 0;
          // Query mode flattens sample matches across the hierarchy. Clearing search
          // returns to the current breadcrumb folder rather than blowing away the path.
          renderCommandPalette();
      });

      commandPopoverSearch.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
          e.preventDefault();
          closeCommandPopover();
          if (editorAPI) editorAPI.focus();
        }

        if (e.key === 'ArrowDown') {
          e.preventDefault();
          focusCommandItem(0);
        }

        if (e.key === 'Enter') {
          const first = commandItemButtons()[0];
          if (first) {
            e.preventDefault();
            first.click();
          }
        }

        if (e.key === 'Tab') {
          const tabs = commandPopoverTabs
            ? Array.from(commandPopoverTabs.querySelectorAll('.example-popover-tab'))
            : [];
          if (tabs.length) {
            e.preventDefault();
            tabs[0].focus();
          }
        }
      });
    }

    document.addEventListener('click', (e) => {
      if (!commandPopover || commandPopover.hidden) return;
      if (commandPopover.contains(e.target)) return;
      if (samplesToggleBtn && samplesToggleBtn.contains(e.target)) return;
      closeCommandPopover();
    });

    document.addEventListener('keydown', (e) => {
      const key = String(e.key || '').toLowerCase();

      if ((e.metaKey || e.ctrlKey) && key === 'k') {
        e.preventDefault();
        toggleCommandPopover();
        return;
      }

      if (!commandPopover || commandPopover.hidden) return;

      if (e.key === 'Escape') {
        e.preventDefault();
        closeCommandPopover();
        if (editorAPI) editorAPI.focus();
      }

      if (e.key === 'ArrowDown' && document.activeElement === samplesToggleBtn) {
        e.preventDefault();
        focusCommandItem(activeCommandFocusIndex);
      }
    });
  if (samplesGroupsEl) {
    // Preserve editor caret when clicking sample pills.
    samplesGroupsEl.addEventListener('mousedown', (e) => {
      const target = e.target;
      if (!(target instanceof HTMLElement)) return;
      const pill = target.closest('.samples-pill');
      if (!pill) return;
      e.preventDefault();
    });

    // Event delegation: any click on a .samples-pill inserts its data-name.
    samplesGroupsEl.addEventListener('click', (e) => {
      const target = e.target;
      if (!(target instanceof HTMLElement)) return;
      const pill = target.closest('.samples-pill');
      if (!pill) return;
      e.preventDefault();
      e.stopPropagation();
      const name = pill.getAttribute('data-name');
      if (!name) return;
      insertAtCursor(name);
    });
  }
  if (samplesFilterInput) {
    let filterTimer = null;
    samplesFilterInput.addEventListener('input', () => {
      clearTimeout(filterTimer);
      filterTimer = setTimeout(() => renderSamplesPanel(samplesFilterInput.value), 80);
    });
    samplesFilterInput.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        if (samplesFilterInput.value) {
          samplesFilterInput.value = '';
          renderSamplesPanel('');
        } else {
          toggleSamplesPanel(false);
          if (editorAPI) editorAPI.focus();
        }
      }
    });
  }
  if (samplesLinkBtn) samplesLinkBtn.addEventListener('click', () => { linkLocalSamplesFolder(); });
  if (samplesRelinkBtn) samplesRelinkBtn.addEventListener('click', () => { linkLocalSamplesFolder(); });
  if (samplesUnlinkBtn) samplesUnlinkBtn.addEventListener('click', () => { unlinkLocalSamplesFolder(); });
  window.addEventListener('beforeunload', () => {
    revokeLocalSampleObjectUrls();
  });
  updateLocalSamplesControls();

    applyVideoDebugGate();
    bindInputPanel();
    bindVideoPanel();
    bindFieldReport();

  // ---------------- status ticker ----------------

  statusTimer = setInterval(setStatusLine, 250);
  setStatusLine();

  // ---------------- editor mount ----------------

  function mountEditor() {
    if (!editorMount) return;
    if (typeof window.createReplEditor !== 'function') {
      // Bundle missing — surface a quiet warning and leave the mount empty.
      // The page is still useful (controls/docs); the user just can't type.
      showWarning('editor failed to load (codemirror.bundle.js missing)');
      return;
    }

    editorAPI = window.createReplEditor({
      parent: editorMount,
      initialText: '',
      blockMuteLines: editorMuteLinesSnapshot(),
        onChange: () => {
          // CM linter already runs on doc changes; do not hard-evaluate here.
          const text = editorAPI ? editorAPI.getValue() : '';
          if (findExplicitPatchTitle(text)) loadedExampleLabel = '';
          refreshPatchTitle();
          schedulePatchHashPersist();
        },
      onCommand: {
        play: evaluateAndRun,
        safePlay,
        stop,
        share: shareCurrent,
        toggleIO: toggleInputPanel,
      },
      onToggleBlockMute: ({ lineNumber, lineNumbers, desiredMuted }) => {
        if (Array.isArray(lineNumbers) && lineNumbers.length > 1) {
          setBlockMuteFromEditor(lineNumbers, Boolean(desiredMuted));
          return;
        }
        toggleBlockMuteFromEditor(lineNumber);
      },
      getSampleNames: () => (
        window.SampleVoice && window.SampleVoice.list ? window.SampleVoice.list() : []
      ),
      getSampleGroups: () => (
        window.SampleVoice && window.SampleVoice.groups ? window.SampleVoice.groups() : []
      ),
      getDrumKits: () => (
        window.SampleVoice && window.SampleVoice.kits ? window.SampleVoice.kits() : []
      ),
      getVideoGeneratedIds: () => (
        videoDebugEnabled() && window.VideoVoice && window.VideoVoice.getGeneratedIds ? window.VideoVoice.getGeneratedIds() : []
      ),
      enableVideoDebug: videoDebugEnabled(),
      parseForDiagnostics: (text) => (
        window.ReplDSL && window.ReplDSL.parse ? window.ReplDSL.parse(text) : { ok: true }
      ),
    });
  }

  // ---------------- bootstrap ----------------

    (async function init() {
      initReferencePanel();
      mountEditor();

    // Kick off sample manifest load in parallel; won't block first audio.
    if (window.SampleVoice) {
      window.SampleVoice.loadManifest(SAMPLES_MANIFEST_URL).catch(() => {});
    }
    if (window.PianoVoice && typeof window.PianoVoice.loadManifest === 'function') {
      window.PianoVoice.loadManifest().catch(() => {});
    }
    if (window.ViolinVoice && typeof window.ViolinVoice.loadManifest === 'function') {
      window.ViolinVoice.loadManifest().catch(() => {});
    }
    initLocalSamplesFromSavedHandle();
        const loaded = await loadFromHash();
        if (!loaded) await loadDefaultExample();

        // Treat the boot-loaded patch/default as the current clean state. The URL
        // should not be rewritten until the user actually edits or clicks share.
        patchLinkState.lastSavedCode = editorAPI ? editorAPI.getValue() : '';
        patchLinkState.lastSavedTitle = getPatchTitleForShare();
        refreshPatchTitle();

        // Pre-render the transport panel from a parse of the loaded text so
    // the slot dots are visible before the user hits play.
    const initialText = editorAPI ? editorAPI.getValue() : '';
    const parsed = window.ReplDSL.parse(initialText);
      if (parsed.ok) {
        applyStoredBlockMuteOverrides(parsed.program);
        lastGoodProgram = parsed.program;
        if (window.ReplAttractors && window.ReplAttractors.warm) {
          window.ReplAttractors.warm(parsed.program);
        }
        renderTransportShell(parsed.program);
        syncEditorBlockMuteLines();
      }
        if (editorAPI && shouldAutofocusEditor) editorAPI.focus();
  })();
})();
